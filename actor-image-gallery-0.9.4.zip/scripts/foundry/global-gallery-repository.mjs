import { HOOKS, MODULE_ID } from "../constants.mjs";
import { createGlobalGallery } from "../domain/global-gallery.mjs";
import { deepClone, warn } from "../utils.mjs";

export const GLOBAL_GALLERY_SETTING = "globalGallery";

export class GlobalGalleryRepository {
  #queue = Promise.resolve();

  read() {
    let stored = {};
    try {
      stored = globalThis.game?.settings?.get?.(MODULE_ID, GLOBAL_GALLERY_SETTING) ?? {};
    } catch {
      // Settings can be unavailable during tests and early Foundry startup.
    }
    return createGlobalGallery(stored);
  }

  async write(galleryInput) {
    if (!globalThis.game?.user?.isGM) throw new GlobalGalleryRepositoryError("globalPermissionDenied");
    const gallery = createGlobalGallery(galleryInput);
    await globalThis.game?.settings?.set?.(MODULE_ID, GLOBAL_GALLERY_SETTING, gallery);
    return gallery;
  }

  mutate(mutator) {
    const operation = this.#queue.catch(() => undefined).then(async () => {
      const current = this.read();
      const result = await mutator(current);
      const gallery = createGlobalGallery(result?.gallery ?? result ?? current);
      await this.write(gallery);
      emitGlobalGalleryChanges(current, gallery);
      return { gallery, value: result?.value ?? result?.entry ?? null };
    });
    this.#queue = operation.catch(() => undefined);
    return operation;
  }
}

function emitGlobalGalleryChanges(previous, current) {
  const before = new Map(previous.entries.map((entry) => [entry.id, entry]));
  const after = new Map(current.entries.map((entry) => [entry.id, entry]));
  for (const [id, entry] of after) {
    if (!before.has(id)) callHook(HOOKS.GLOBAL_ENTRY_ADDED, deepClone(entry));
    else if (JSON.stringify(before.get(id)) !== JSON.stringify(entry)) callHook(HOOKS.GLOBAL_ENTRY_UPDATED, deepClone(entry), deepClone(before.get(id)));
  }
  for (const [id, entry] of before) if (!after.has(id)) callHook(HOOKS.GLOBAL_ENTRY_REMOVED, deepClone(entry));
}

function callHook(name, ...args) {
  try {
    globalThis.Hooks?.callAll?.(name, ...args);
  } catch (error) {
    warn(`Integration hook ${name} failed.`, error);
  }
}

export class GlobalGalleryRepositoryError extends Error {
  constructor(code) {
    super(code);
    this.name = "GlobalGalleryRepositoryError";
    this.code = code;
  }
}

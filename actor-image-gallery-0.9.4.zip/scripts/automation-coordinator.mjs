import { CAPABILITIES, MODULE_ID } from "./constants.mjs";
import { warn } from "./utils.mjs";

export class AutomationCoordinator {
  #service;
  #hasCapability;
  #isAuthority;
  #debounceMs;
  #setTimer;
  #clearTimer;
  #debugEnabled;
  #pending = new Map();

  constructor({
    service,
    hasCapability = () => true,
    isAuthority = isAutomationAuthority,
    debounceMs = 140,
    setTimer = (callback, delay) => setTimeout(callback, delay),
    clearTimer = (timer) => clearTimeout(timer),
    debugEnabled = () => false
  }) {
    this.#service = service;
    this.#hasCapability = hasCapability;
    this.#isAuthority = isAuthority;
    this.#debounceMs = debounceMs;
    this.#setTimer = setTimer;
    this.#clearTimer = clearTimer;
    this.#debugEnabled = debugEnabled;
  }

  queue(actor, context = {}) {
    if (!actor || !this.#hasCapability(CAPABILITIES.AUTOMATION_RULES) || !this.#isAuthority()) return false;
    if (isModuleUpdate(context.options) || this.#service.isApplying(actor)) return false;
    const key = actor.uuid ?? actor.id;
    const current = this.#pending.get(key);
    if (current) this.#clearTimer(current.timer);
    const pending = current ?? { actor, contexts: new Map(), timer: null };
    pending.actor = actor;
    pending.contexts.set(contextKey(context), context);
    pending.timer = this.#setTimer(() => {
      this.#pending.delete(key);
      void this.#evaluateMany(pending.actor, pending.contexts.values());
    }, this.#debounceMs);
    this.#pending.set(key, pending);
    return true;
  }

  queueMany(actors, contextFactory = () => ({})) {
    let queued = 0;
    const seen = new Set();
    for (const actor of actors ?? []) {
      const key = actor?.uuid ?? actor?.id;
      if (!key || seen.has(key)) continue;
      seen.add(key);
      if (this.queue(actor, contextFactory(actor))) queued += 1;
    }
    return queued;
  }

  isAuthority() {
    return Boolean(this.#isAuthority());
  }

  async flush(actor = null) {
    const selected = actor
      ? Array.from(this.#pending.entries()).filter(([, pending]) => pending.actor === actor || (pending.actor?.uuid ?? pending.actor?.id) === (actor?.uuid ?? actor?.id))
      : Array.from(this.#pending.entries());
    const results = [];
    for (const [key, pending] of selected) {
      this.#clearTimer(pending.timer);
      this.#pending.delete(key);
      results.push(...await this.#evaluateMany(pending.actor, pending.contexts.values()));
    }
    return results;
  }

  destroy() {
    for (const pending of this.#pending.values()) this.#clearTimer(pending.timer);
    this.#pending.clear();
  }

  async #evaluate(actor, context) {
    try {
      const result = await this.#service.evaluate(actor, context);
      if (this.#debugEnabled()) globalThis.console?.debug?.(`[${MODULE_ID}] automation evaluation`, {
        actorUuid: actor?.uuid ?? actor?.id,
        trigger: context?.trigger?.type,
        winnerRuleId: result?.winner?.id ?? null,
        applied: Boolean(result?.applied),
        suppressed: result?.suppressed?.map?.(({ ruleId, reason }) => ({ ruleId, reason })) ?? []
      });
      return result;
    } catch (error) {
      warn("Automation evaluation failed.", {
        actorUuid: actor?.uuid ?? actor?.id,
        trigger: context?.trigger?.type,
        code: error?.code,
        error
      });
      return { applied: false, error };
    }
  }

  async #evaluateMany(actor, contexts) {
    const results = [];
    for (const context of contexts) results.push(await this.#evaluate(actor, context));
    return results;
  }
}

export function isAutomationAuthority() {
  const current = globalThis.game?.user;
  if (!current?.isGM) return false;
  const activeGms = Array.from(globalThis.game?.users ?? [])
    .filter((user) => user?.isGM && user?.active !== false)
    .sort((left, right) => String(left.id).localeCompare(String(right.id)));
  return !activeGms.length || activeGms[0]?.id === current.id;
}

export function isModuleUpdate(options) {
  return Boolean(options?.[MODULE_ID]);
}

function contextKey(context) {
  return `${String(context?.trigger?.type ?? "unknown")}::${String(context?.trigger?.eventName ?? "")}`;
}

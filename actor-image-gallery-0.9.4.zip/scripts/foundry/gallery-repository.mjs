import { FLAG_KEY, HOOKS, MODULE_ID } from "../constants.mjs";
import { createGallery } from "../domain/gallery.mjs";
import { actorCanUpdate, deepClone, warn } from "../utils.mjs";

export class ActorGalleryRepository {
  #queues = new Map();

  read(actor) {
    if (!actor) throw new GalleryRepositoryError("actorRequired");
    return createGallery(actor.getFlag?.(MODULE_ID, FLAG_KEY) ?? actor.flags?.[MODULE_ID]?.[FLAG_KEY] ?? {});
  }

  async write(actor, galleryInput, { context = null } = {}) {
    if (!actor) throw new GalleryRepositoryError("actorRequired");
    if (!actorCanUpdate(actor)) throw new GalleryRepositoryError("permissionDenied");
    const gallery = createGallery(galleryInput);
    if (context && typeof actor.update === "function") {
      await actor.update({ [`flags.${MODULE_ID}.${FLAG_KEY}`]: gallery }, { [MODULE_ID]: context });
    } else await actor.setFlag(MODULE_ID, FLAG_KEY, gallery);
    return gallery;
  }

  mutate(actor, mutator, options = {}) {
    const key = actor?.uuid ?? actor?.id ?? "unknown";
    const previous = this.#queues.get(key) ?? Promise.resolve();
    const operation = previous.catch(() => undefined).then(async () => {
      const current = this.read(actor);
      const result = await mutator(current);
      const gallery = createGallery(result?.gallery ?? result ?? current);
      await this.write(actor, gallery, options);
      emitGalleryChanges(actor, current, gallery);
      return { gallery, value: result?.value ?? result?.entry ?? null };
    });
    let queued;
    queued = operation.finally(() => {
      if (this.#queues.get(key) === queued) this.#queues.delete(key);
    });
    this.#queues.set(key, queued);
    return operation;
  }
}

function emitGalleryChanges(actor, previous, current) {
  const before = new Map(previous.entries.map((entry) => [entry.id, entry]));
  const after = new Map(current.entries.map((entry) => [entry.id, entry]));
  for (const [id, entry] of after) {
    if (!before.has(id)) callHook(HOOKS.ENTRY_ADDED, actor, deepClone(entry));
  }
  for (const [id, entry] of before) {
    if (!after.has(id)) callHook(HOOKS.ENTRY_REMOVED, actor, deepClone(entry));
  }
}

function callHook(name, ...args) {
  try {
    globalThis.Hooks?.callAll?.(name, ...args);
  } catch (error) {
    warn(`Integration hook ${name} failed.`, error);
  }
}

export class GalleryRepositoryError extends Error {
  constructor(code) {
    super(code);
    this.name = "GalleryRepositoryError";
    this.code = code;
  }
}

export function extractDroppedSource(raw) {
  const value = String(raw ?? "").trim();
  if (!value || value.startsWith("aig-entry:")) return "";
  try {
    const data = JSON.parse(value);
    return String(data.img ?? data.texture?.src ?? data.src ?? "").trim();
  } catch {
    return value.split(/\r?\n/).find((line) => line && !line.startsWith("#"))?.trim() ?? "";
  }
}

export function droppedImageFiles(dataTransfer) {
  const files = [
    ...Array.from(dataTransfer?.files ?? []),
    ...Array.from(dataTransfer?.items ?? [])
      .filter((item) => item.kind === "file")
      .map((item) => item.getAsFile?.())
      .filter(Boolean)
  ];
  const unique = new Map();
  for (const file of files) {
    if (!isImageFile(file)) continue;
    unique.set(`${file.name}:${file.size}:${file.lastModified}`, file);
  }
  return Array.from(unique.values());
}

export function isImageFile(file) {
  if (String(file?.type ?? "").toLowerCase().startsWith("image/")) return true;
  return /\.(?:avif|bmp|gif|jpe?g|png|svg|webp)$/i.test(String(file?.name ?? ""));
}

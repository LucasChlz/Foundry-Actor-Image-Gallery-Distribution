import {
  APPLY_TARGETS,
  AUTOMATION_ACTION_TYPES,
  AUTOMATION_TRIGGER_TYPES,
  CAPABILITIES,
  CONDITION_GROUP_OPERATORS,
  CONDITION_OPERATORS,
  MANUAL_OVERRIDE_POLICIES,
  MODULE_ID
} from "../constants.mjs";
import { normalizeAutomationRules, normalizeAutomationState } from "../domain/automation-rule.mjs";
import { ApplicationV2Class } from "../foundry/compatibility.mjs";
import { applyPalette, DEFAULT_PALETTE } from "../palette.mjs";
import { actorCanUpdate, confirmAction, deepClone, escapeAttribute, escapeHtml, localize, notify, warn } from "../utils.mjs";

export class AutomationRulesApplication extends ApplicationV2Class {
  static DEFAULT_OPTIONS = {
    id: "actor-image-gallery-automation",
    classes: ["actor-image-gallery-window", "actor-image-automation-window"],
    tag: "section",
    window: { frame: true, positioned: true, minimizable: true, resizable: true, icon: "fa-solid fa-wand-magic-sparkles" },
    position: { width: 1220, height: 780 }
  };

  #actor;
  #repository;
  #service;
  #hasCapability;
  #gallery;
  #rules = [];
  #facts = [];
  #editing = null;

  constructor({ actor, repository, service, hasCapability = () => false }) {
    super({ id: `${MODULE_ID}-automation-${actor.id}` });
    this.#actor = actor;
    this.#repository = repository;
    this.#service = service;
    this.#hasCapability = hasCapability;
    this.#reload();
  }

  get title() {
    return localize("automation.windowTitle", { name: this.#actor.name });
  }

  async refresh() {
    this.#reload();
    if (this.rendered) await this.render({ force: true });
  }

  async _renderHTML() {
    const root = document.createElement("div");
    root.className = "aig-shell aig-automation-shell";
    root.dataset.reducedMotion = String(Boolean(getSetting("reducedMotion", false)));
    applyPalette(root, getSetting("customPalette", DEFAULT_PALETTE));
    const available = this.#available();
    root.innerHTML = `
      <header class="aig-hero aig-automation-hero">
        <div class="aig-automation-hero__icon"><i class="fa-solid ${available ? "fa-wand-magic-sparkles" : "fa-lock"}" aria-hidden="true"></i></div>
        <div class="aig-hero__copy"><span class="aig-kicker">${escapeHtml(localize("automation.kicker"))}</span><h1>${escapeHtml(localize("automation.title"))}</h1><p>${escapeHtml(localize("automation.subtitle", { name: this.#actor.name }))}</p></div>
        <div class="aig-hero__actions">${available ? `<button type="button" class="aig-button" data-action="automation-trigger-manual" ${disabledIf(!this.#canEdit())}><i class="fa-solid fa-play"></i><span>${escapeHtml(localize("automation.runManual"))}</span></button><button type="button" class="aig-button aig-button--signal" data-action="automation-new" ${disabledIf(!this.#canEdit())}><i class="fa-solid fa-plus"></i><span>${escapeHtml(localize("automation.new"))}</span></button>` : `<b class="aig-pro-badge">PATREON</b>`}</div>
      </header>
      ${available ? this.#workspaceHtml() : this.#lockedHtml()}
    `;
    return root;
  }

  _replaceHTML(result, content) {
    content.replaceChildren(result);
  }

  async _onRender(context, options) {
    await super._onRender(context, options);
    const shell = this.#shell();
    if (!shell) return;
    shell.addEventListener("click", (event) => void this.#onClick(event));
    shell.addEventListener("change", (event) => void this.#onChange(event));
  }

  #reload() {
    this.#gallery = this.#repository.read(this.#actor);
    if (this.#available()) {
      try {
        this.#rules = this.#service.list(this.#actor);
        this.#facts = this.#service.availableFacts();
      } catch {
        this.#rules = normalizeAutomationRules(this.#gallery.automationRules);
        this.#facts = [];
      }
    } else {
      this.#rules = normalizeAutomationRules(this.#gallery.automationRules);
      this.#facts = [];
    }
  }

  #lockedHtml() {
    return `<main class="aig-automation-locked"><i class="fa-solid fa-lock"></i><h2>${escapeHtml(localize("automation.lockedTitle"))}</h2><p>${escapeHtml(localize("automation.lockedHint"))}</p><strong>${escapeHtml(localize("automation.preservedCount", { count: this.#rules.length }))}</strong></main>`;
  }

  #workspaceHtml() {
    const state = normalizeAutomationState(this.#gallery.automationState, this.#rules);
    return `
      ${this.#overrideHtml(state.manualOverride)}
      <div class="aig-automation-workspace">
        <section class="aig-automation-rules" aria-label="${escapeAttribute(localize("automation.rules"))}">
          <header><div><span class="aig-kicker">${escapeHtml(localize("automation.rules"))}</span><strong>${escapeHtml(localize("automation.ruleCount", { count: this.#rules.length }))}</strong></div></header>
          <div class="aig-automation-rule-list">${this.#rules.length ? this.#rules.map((rule, index) => this.#ruleCardHtml(rule, index)).join("") : `<div class="aig-profiles-empty"><i class="fa-solid fa-diagram-project"></i><span>${escapeHtml(localize("automation.empty"))}</span></div>`}</div>
        </section>
        <section class="aig-automation-editor">${this.#editing ? this.#editorHtml() : this.#diagnosticsHtml(state.lastEvaluation)}</section>
      </div>`;
  }

  #overrideHtml(manualOverride) {
    if (!manualOverride) return `<section class="aig-automation-status"><div><i class="fa-solid fa-circle-play"></i><span><strong>${escapeHtml(localize("automation.enabled"))}</strong>${escapeHtml(localize("automation.noOverride"))}</span></div></section>`;
    return `<section class="aig-automation-status is-override"><div><i class="fa-solid fa-hand"></i><span><strong>${escapeHtml(localize("automation.overrideActive"))}</strong>${escapeHtml(localize(`automation.overrideDurations.${manualOverride.duration}`))}</span></div><button type="button" class="aig-button" data-action="automation-clear-override" ${disabledIf(!this.#canEdit())}><i class="fa-solid fa-unlock"></i>${escapeHtml(localize("automation.clearOverride"))}</button></section>`;
  }

  #ruleCardHtml(rule, index) {
    const broken = !actionReferenceExists(rule.action, this.#gallery);
    return `<article class="aig-automation-rule ${rule.enabled ? "is-enabled" : "is-disabled"} ${broken ? "is-broken" : ""}">
      <div class="aig-automation-rule__priority"><span>${escapeHtml(localize("automation.priority"))}</span><strong>${rule.priority}</strong></div>
      <div class="aig-automation-rule__copy"><strong>${escapeHtml(rule.name)}</strong><span>${escapeHtml(localize(`automation.triggers.${rule.trigger.type}`))} · ${escapeHtml(localize(`automation.actions.${rule.action.type}`))}</span>${broken ? `<b><i class="fa-solid fa-triangle-exclamation"></i>${escapeHtml(localize("automation.referenceMissing"))}</b>` : ""}</div>
      <nav>
        <button type="button" class="aig-icon-button" data-action="automation-toggle" data-rule-id="${escapeAttribute(rule.id)}" title="${escapeAttribute(localize(rule.enabled ? "automation.disable" : "automation.enable"))}" ${disabledIf(!this.#canEdit())}><i class="fa-solid ${rule.enabled ? "fa-toggle-on" : "fa-toggle-off"}"></i></button>
        <button type="button" class="aig-icon-button" data-action="automation-up" data-rule-id="${escapeAttribute(rule.id)}" title="${escapeAttribute(localize("automation.moveUp"))}" ${disabledIf(index === 0 || !this.#canEdit())}><i class="fa-solid fa-arrow-up"></i></button>
        <button type="button" class="aig-icon-button" data-action="automation-down" data-rule-id="${escapeAttribute(rule.id)}" title="${escapeAttribute(localize("automation.moveDown"))}" ${disabledIf(index === this.#rules.length - 1 || !this.#canEdit())}><i class="fa-solid fa-arrow-down"></i></button>
        <button type="button" class="aig-icon-button" data-action="automation-edit" data-rule-id="${escapeAttribute(rule.id)}" title="${escapeAttribute(localize(broken ? "automation.repair" : "actions.edit"))}" ${disabledIf(!this.#canEdit())}><i class="fa-solid ${broken ? "fa-screwdriver-wrench" : "fa-pen"}"></i></button>
        <button type="button" class="aig-icon-button" data-action="automation-duplicate" data-rule-id="${escapeAttribute(rule.id)}" title="${escapeAttribute(localize("actions.duplicate"))}" ${disabledIf(!this.#canEdit())}><i class="fa-solid fa-copy"></i></button>
        <button type="button" class="aig-icon-button" data-action="automation-remove" data-rule-id="${escapeAttribute(rule.id)}" title="${escapeAttribute(localize("actions.remove"))}" ${disabledIf(!this.#canEdit())}><i class="fa-solid fa-trash"></i></button>
      </nav>
    </article>`;
  }

  #diagnosticsHtml(diagnostic) {
    if (!diagnostic) return `<div class="aig-automation-diagnostics aig-profiles-empty"><i class="fa-solid fa-magnifying-glass-chart"></i><strong>${escapeHtml(localize("automation.whyTitle"))}</strong><span>${escapeHtml(localize("automation.noDiagnostics"))}</span></div>`;
    const winner = diagnostic.winnerRuleId
      ? `<div class="aig-automation-winner"><span>${escapeHtml(localize("automation.winner"))}</span><strong>${escapeHtml(diagnostic.winnerName || diagnostic.winnerRuleId)}</strong><b>${escapeHtml(localize(`automation.outcomes.${diagnostic.outcome}`))}</b></div>`
      : `<div class="aig-automation-winner"><span>${escapeHtml(localize("automation.winner"))}</span><strong>${escapeHtml(localize("automation.noWinner"))}</strong><b>${escapeHtml(localize(`automation.outcomes.${diagnostic.outcome}`))}</b></div>`;
    return `<div class="aig-automation-diagnostics"><header><span class="aig-kicker">${escapeHtml(localize("automation.inspectorKicker"))}</span><h2>${escapeHtml(localize("automation.whyTitle"))}</h2><p>${escapeHtml(localize(`automation.triggers.${diagnostic.triggerType}`))}${diagnostic.eventName ? ` · ${escapeHtml(diagnostic.eventName)}` : ""}</p></header>${winner}${diagnostic.errorCode ? `<div class="aig-automation-error"><i class="fa-solid fa-triangle-exclamation"></i>${escapeHtml(diagnostic.errorCode)}</div>` : ""}<section><h3>${escapeHtml(localize("automation.conditions"))}</h3>${diagnostic.conditions.length ? diagnostic.conditions.map(conditionDiagnosticHtml).join("") : `<p>${escapeHtml(localize("automation.noConditions"))}</p>`}</section><section><h3>${escapeHtml(localize("automation.suppressed"))}</h3>${diagnostic.suppressed.length ? diagnostic.suppressed.map((item) => `<div class="aig-automation-suppressed"><strong>${escapeHtml(item.name || item.ruleId)}</strong><span>${escapeHtml(localize(`automation.suppression.${item.reason}`))}</span></div>`).join("") : `<p>${escapeHtml(localize("automation.noneSuppressed"))}</p>`}</section></div>`;
  }

  #editorHtml() {
    const rule = this.#editing;
    return `<form class="aig-automation-rule-editor" data-role="automation-form">
      <header><span class="aig-kicker">${escapeHtml(localize("automation.editorKicker"))}</span><h2>${escapeHtml(localize(rule.__new ? "automation.newTitle" : "automation.editTitle"))}</h2></header>
      <div class="aig-form-grid">
        <label class="aig-field"><span>${escapeHtml(localize("entry.name"))}</span><input name="name" value="${escapeAttribute(rule.name)}" required></label>
        <label class="aig-field"><span>${escapeHtml(localize("automation.priority"))}</span><input name="priority" type="number" min="-1000" max="1000" value="${rule.priority}"></label>
        <label class="aig-field aig-field--wide"><span>${escapeHtml(localize("entry.description"))}</span><textarea name="description">${escapeHtml(rule.description)}</textarea></label>
        <label class="aig-field"><span>${escapeHtml(localize("automation.trigger"))}</span><select name="triggerType" data-role="automation-trigger-type">${options(Object.values(AUTOMATION_TRIGGER_TYPES), rule.trigger.type, "automation.triggers")}</select></label>
        ${rule.trigger.type === AUTOMATION_TRIGGER_TYPES.MANUAL ? `<label class="aig-field"><span>${escapeHtml(localize("automation.manualEvent"))}</span><input name="triggerEvent" value="${escapeAttribute(rule.trigger.event)}" placeholder="change-state"></label>` : ""}
        <label class="aig-field"><span>${escapeHtml(localize("automation.cooldown"))}</span><input name="cooldownSeconds" type="number" min="0" max="86400" step="0.1" value="${rule.cooldownMs / 1000}"></label>
        <label class="aig-field"><span>${escapeHtml(localize("automation.overridePolicy"))}</span><select name="manualOverridePolicy">${options(Object.values(MANUAL_OVERRIDE_POLICIES), rule.manualOverridePolicy, "automation.overridePolicies")}</select></label>
        <label class="aig-checkbox aig-field--wide"><input name="enabled" type="checkbox" ${rule.enabled ? "checked" : ""}><span>${escapeHtml(localize("automation.ruleEnabled"))}</span></label>
      </div>
      <section class="aig-automation-condition-builder"><header><div><span class="aig-kicker">${escapeHtml(localize("automation.conditions"))}</span><strong>${escapeHtml(localize("automation.conditionHint"))}</strong></div></header>${this.#conditionNodeHtml(rule.conditionTree, "", 0)}</section>
      <section class="aig-automation-action-builder"><header><span class="aig-kicker">${escapeHtml(localize("automation.action"))}</span></header><label class="aig-field"><span>${escapeHtml(localize("automation.actionType"))}</span><select data-role="automation-action-type">${options(Object.values(AUTOMATION_ACTION_TYPES), rule.action.type, "automation.actions")}</select></label>${this.#actionFieldsHtml(rule.action)}</section>
      <footer><button type="button" class="aig-button" data-action="automation-cancel">${escapeHtml(localize("common.cancel"))}</button><button type="button" class="aig-button aig-button--signal" data-action="automation-save"><i class="fa-solid fa-floppy-disk"></i>${escapeHtml(localize("common.save"))}</button></footer>
    </form>`;
  }

  #conditionNodeHtml(node, path, depth) {
    if (Array.isArray(node.children)) {
      return `<fieldset class="aig-automation-condition-group" data-condition-group-path="${escapeAttribute(path)}"><legend>${escapeHtml(localize("automation.group"))}</legend><div class="aig-automation-condition-group__tools"><select data-condition-group-operator>${options(Object.values(CONDITION_GROUP_OPERATORS), node.operator, "automation.groupOperators")}</select><button type="button" class="aig-button" data-action="automation-condition-add" data-condition-path="${escapeAttribute(path)}"><i class="fa-solid fa-plus"></i>${escapeHtml(localize("automation.addCondition"))}</button>${depth < 4 ? `<button type="button" class="aig-button" data-action="automation-group-add" data-condition-path="${escapeAttribute(path)}"><i class="fa-solid fa-code-branch"></i>${escapeHtml(localize("automation.addGroup"))}</button>` : ""}${path ? `<button type="button" class="aig-icon-button" data-action="automation-condition-remove" data-condition-path="${escapeAttribute(path)}" title="${escapeAttribute(localize("actions.remove"))}"><i class="fa-solid fa-trash"></i></button>` : ""}</div><div class="aig-automation-condition-children">${node.children.length ? node.children.map((child, index) => this.#conditionNodeHtml(child, childPath(path, index), depth + 1)).join("") : `<p>${escapeHtml(localize("automation.emptyGroup"))}</p>`}</div></fieldset>`;
    }
    return `<div class="aig-automation-condition" data-condition-path="${escapeAttribute(path)}"><label class="aig-field"><span>${escapeHtml(localize("automation.fact"))}</span><select data-condition-fact>${factOptions(this.#facts, node.fact)}</select></label><label class="aig-field"><span>${escapeHtml(localize("automation.operator"))}</span><select data-condition-operator>${options(Object.values(CONDITION_OPERATORS), node.operator, "automation.operators")}</select></label><label class="aig-field"><span>${escapeHtml(localize("automation.value"))}</span><input data-condition-value value="${escapeAttribute(formatValue(node.value))}" ${[CONDITION_OPERATORS.EXISTS, CONDITION_OPERATORS.NOT_EXISTS].includes(node.operator) ? "disabled" : ""}></label><button type="button" class="aig-icon-button" data-action="automation-condition-remove" data-condition-path="${escapeAttribute(path)}" title="${escapeAttribute(localize("actions.remove"))}"><i class="fa-solid fa-trash"></i></button></div>`;
  }

  #actionFieldsHtml(action) {
    if ([AUTOMATION_ACTION_TYPES.APPLY_ENTRY, AUTOMATION_ACTION_TYPES.APPLY_TEMPORARY].includes(action.type)) {
      return `<div class="aig-form-grid"><label class="aig-field"><span>${escapeHtml(localize("automation.entryTarget"))}</span><select data-action-field="entryId">${targetOptions(this.#gallery.entries, action.entryId)}</select></label>${targetField(action.target)}</div>`;
    }
    if (action.type === AUTOMATION_ACTION_TYPES.APPLY_PROFILE) {
      return `<label class="aig-field"><span>${escapeHtml(localize("automation.profileTarget"))}</span><select data-action-field="profileId">${targetOptions(this.#gallery.profiles, action.profileId)}</select></label>`;
    }
    if ([AUTOMATION_ACTION_TYPES.SEQUENCE_NEXT, AUTOMATION_ACTION_TYPES.SEQUENCE_PREVIOUS, AUTOMATION_ACTION_TYPES.SEQUENCE_RESET, AUTOMATION_ACTION_TYPES.SEQUENCE_STEP].includes(action.type)) {
      return `<div class="aig-form-grid"><label class="aig-field"><span>${escapeHtml(localize("automation.sequenceTarget"))}</span><select data-action-field="sequenceId">${targetOptions(this.#gallery.sequences, action.sequenceId)}</select></label>${action.type === AUTOMATION_ACTION_TYPES.SEQUENCE_STEP ? `<label class="aig-field"><span>${escapeHtml(localize("automation.stepIndex"))}</span><input type="number" min="1" data-action-field="stepIndex" value="${Number(action.stepIndex ?? 0) + 1}"></label>` : ""}${targetField(action.target)}</div>`;
    }
    return `<p class="aig-automation-action-note">${escapeHtml(localize("automation.noActionTarget"))}</p>`;
  }

  async #onClick(event) {
    const button = event.target.closest?.("[data-action]");
    if (!button) return;
    const action = button.dataset.action;
    const ruleId = button.dataset.ruleId;
    try {
      if (action === "automation-new") this.#openEditor();
      else if (action === "automation-edit") this.#openEditor(ruleId);
      else if (action === "automation-cancel") { this.#editing = null; await this.render({ force: true }); }
      else if (action === "automation-save") await this.#save();
      else if (action === "automation-toggle") await this.#toggle(ruleId);
      else if (action === "automation-duplicate") await this.#duplicate(ruleId);
      else if (action === "automation-remove") await this.#remove(ruleId);
      else if (action === "automation-up") await this.#move(ruleId, -1);
      else if (action === "automation-down") await this.#move(ruleId, 1);
      else if (action === "automation-condition-add") this.#addCondition(button.dataset.conditionPath);
      else if (action === "automation-group-add") this.#addGroup(button.dataset.conditionPath);
      else if (action === "automation-condition-remove") this.#removeCondition(button.dataset.conditionPath);
      else if (action === "automation-clear-override") await this.#clearOverride();
      else if (action === "automation-trigger-manual") await this.#runManual();
    } catch (error) {
      this.#handleError(error);
    }
  }

  async #onChange(event) {
    if (!this.#editing) return;
    if (event.target.matches("[data-role='automation-trigger-type']")) {
      this.#syncEditor();
      this.#editing.trigger.type = event.target.value;
      await this.render({ force: true });
    } else if (event.target.matches("[data-role='automation-action-type']")) {
      this.#syncEditor();
      this.#editing.action = defaultAction(event.target.value, this.#gallery);
      await this.render({ force: true });
    } else if (event.target.matches("[data-condition-operator]")) {
      this.#syncEditor();
      await this.render({ force: true });
    }
  }

  #openEditor(ruleId = null) {
    const existing = this.#rules.find((rule) => rule.id === ruleId);
    this.#editing = existing ? deepClone(existing) : defaultRule(this.#facts, this.#gallery);
    void this.render({ force: true });
  }

  #syncEditor() {
    const form = this.#shell()?.querySelector("[data-role='automation-form']");
    if (!form || !this.#editing) return;
    const data = new FormData(form);
    this.#editing.name = String(data.get("name") ?? "").trim();
    this.#editing.description = String(data.get("description") ?? "").trim();
    this.#editing.priority = Number(data.get("priority") ?? 0);
    this.#editing.enabled = data.has("enabled");
    this.#editing.cooldownMs = Math.max(0, Number(data.get("cooldownSeconds") ?? 0) * 1000);
    this.#editing.manualOverridePolicy = String(data.get("manualOverridePolicy") ?? MANUAL_OVERRIDE_POLICIES.RESPECT);
    this.#editing.trigger = { type: String(data.get("triggerType") ?? AUTOMATION_TRIGGER_TYPES.ACTOR_UPDATE), event: String(data.get("triggerEvent") ?? "").trim() };
    for (const group of form.querySelectorAll("[data-condition-group-path]")) {
      const node = nodeAt(this.#editing.conditionTree, group.dataset.conditionGroupPath);
      if (node && Array.isArray(node.children)) node.operator = group.querySelector(":scope > .aig-automation-condition-group__tools [data-condition-group-operator]")?.value ?? node.operator;
    }
    for (const row of form.querySelectorAll(".aig-automation-condition[data-condition-path]")) {
      const node = nodeAt(this.#editing.conditionTree, row.dataset.conditionPath);
      if (!node || Array.isArray(node.children)) continue;
      node.fact = row.querySelector("[data-condition-fact]")?.value ?? node.fact;
      node.operator = row.querySelector("[data-condition-operator]")?.value ?? node.operator;
      node.value = parseValue(row.querySelector("[data-condition-value]")?.value ?? "");
    }
    const actionType = form.querySelector("[data-role='automation-action-type']")?.value ?? this.#editing.action.type;
    this.#editing.action.type = actionType;
    for (const field of form.querySelectorAll("[data-action-field]")) {
      const key = field.dataset.actionField;
      this.#editing.action[key] = key === "stepIndex" ? Math.max(0, Number(field.value) - 1) : field.value;
    }
  }

  #addCondition(path) {
    this.#syncEditor();
    const group = nodeAt(this.#editing.conditionTree, path);
    if (!Array.isArray(group?.children)) return;
    group.children.push(defaultCondition(this.#facts));
    void this.render({ force: true });
  }

  #addGroup(path) {
    this.#syncEditor();
    const group = nodeAt(this.#editing.conditionTree, path);
    if (!Array.isArray(group?.children)) return;
    group.children.push({ operator: CONDITION_GROUP_OPERATORS.AND, children: [defaultCondition(this.#facts)] });
    void this.render({ force: true });
  }

  #removeCondition(path) {
    this.#syncEditor();
    const parts = pathParts(path);
    if (!parts.length) return;
    const index = parts.pop();
    const parent = nodeAt(this.#editing.conditionTree, parts.join("."));
    if (Array.isArray(parent?.children)) parent.children.splice(index, 1);
    void this.render({ force: true });
  }

  async #save() {
    this.#syncEditor();
    const input = { ...this.#editing };
    delete input.__new;
    if (this.#editing.__new) await this.#service.create(this.#actor, input);
    else await this.#service.update(this.#actor, this.#editing.id, input);
    this.#editing = null;
    this.#reload();
    await this.render({ force: true });
    notify("info", "notifications.automationRuleSaved");
  }

  async #toggle(ruleId) {
    const rule = this.#rules.find((candidate) => candidate.id === ruleId);
    if (!rule) return;
    await this.#service.update(this.#actor, ruleId, { enabled: !rule.enabled });
    this.#reload();
    await this.render({ force: true });
  }

  async #duplicate(ruleId) {
    await this.#service.duplicate(this.#actor, ruleId, { suffix: localize("automation.copySuffix") });
    this.#reload();
    await this.render({ force: true });
    notify("info", "notifications.automationRuleDuplicated");
  }

  async #remove(ruleId) {
    const rule = this.#rules.find((candidate) => candidate.id === ruleId);
    if (!rule) return;
    const confirmed = await confirmAction({ title: localize("automation.removeTitle"), content: `<p>${escapeHtml(localize("automation.removeContent", { name: rule.name }))}</p>` });
    if (!confirmed) return;
    await this.#service.remove(this.#actor, ruleId);
    if (this.#editing?.id === ruleId) this.#editing = null;
    this.#reload();
    await this.render({ force: true });
    notify("info", "notifications.automationRuleRemoved");
  }

  async #move(ruleId, delta) {
    const ids = this.#rules.map((rule) => rule.id);
    const index = ids.indexOf(ruleId);
    const target = index + delta;
    if (index < 0 || target < 0 || target >= ids.length) return;
    [ids[index], ids[target]] = [ids[target], ids[index]];
    await this.#service.reorder(this.#actor, ids);
    this.#reload();
    await this.render({ force: true });
    notify("info", "notifications.automationRulesReordered");
  }

  async #clearOverride() {
    await this.#service.clearManualOverride(this.#actor);
    this.#reload();
    await this.render({ force: true });
    notify("info", "notifications.automationOverrideCleared");
  }

  async #runManual() {
    const result = await this.#service.evaluate(this.#actor, { trigger: { type: AUTOMATION_TRIGGER_TYPES.MANUAL, eventName: "ui" }, force: true });
    this.#reload();
    await this.render({ force: true });
    notify("info", result.applied ? "notifications.automationApplied" : "notifications.automationNoMatch");
  }

  #available() {
    return Boolean(this.#service && this.#hasCapability?.(CAPABILITIES.AUTOMATION_RULES));
  }

  #canEdit() {
    return actorCanUpdate(this.#actor);
  }

  #shell() {
    return this.element?.querySelector?.(".aig-automation-shell") ?? null;
  }

  #handleError(error) {
    warn("Automation UI action failed.", error);
    const known = new Set([
      "automationRuleNameRequired", "automationConditionInvalid", "automationConditionTooDeep", "automationActionInvalid",
      "automationTriggerInvalid", "automationOverridePolicyInvalid", "automationRuleIdConflict",
      "automationActionTargetRequired", "automationActionReferenceMissing", "automationRuleNotFound", "automationRuleOrderInvalid",
      "temporaryNotActive", "sequenceStepInvalid", "permissionDenied", "capabilityRequired"
    ]);
    notify("error", known.has(error?.code) ? `errors.${error.code}` : "errors.actionFailed");
  }
}

function defaultRule(facts, gallery) {
  return {
    __new: true,
    id: null,
    name: "",
    description: "",
    enabled: true,
    priority: 0,
    trigger: { type: AUTOMATION_TRIGGER_TYPES.ACTOR_UPDATE, event: "" },
    conditionTree: { operator: CONDITION_GROUP_OPERATORS.AND, children: [defaultCondition(facts)] },
    action: defaultAction(AUTOMATION_ACTION_TYPES.APPLY_ENTRY, gallery),
    cooldownMs: 1000,
    manualOverridePolicy: MANUAL_OVERRIDE_POLICIES.RESPECT
  };
}

function defaultCondition(facts) {
  return { fact: facts[0]?.key ?? "actor.id", operator: CONDITION_OPERATORS.EXISTS };
}

function defaultAction(type, gallery) {
  if ([AUTOMATION_ACTION_TYPES.APPLY_ENTRY, AUTOMATION_ACTION_TYPES.APPLY_TEMPORARY].includes(type)) return { type, entryId: gallery.entries[0]?.id ?? "", target: APPLY_TARGETS.PORTRAIT_CURRENT };
  if (type === AUTOMATION_ACTION_TYPES.APPLY_PROFILE) return { type, profileId: gallery.profiles[0]?.id ?? "" };
  if ([AUTOMATION_ACTION_TYPES.SEQUENCE_NEXT, AUTOMATION_ACTION_TYPES.SEQUENCE_PREVIOUS, AUTOMATION_ACTION_TYPES.SEQUENCE_RESET, AUTOMATION_ACTION_TYPES.SEQUENCE_STEP].includes(type)) return { type, sequenceId: gallery.sequences[0]?.id ?? "", stepIndex: 0, target: APPLY_TARGETS.PORTRAIT_CURRENT };
  return { type };
}

function actionReferenceExists(action, gallery) {
  if ([AUTOMATION_ACTION_TYPES.APPLY_ENTRY, AUTOMATION_ACTION_TYPES.APPLY_TEMPORARY].includes(action.type)) return gallery.entries.some((entry) => entry.id === action.entryId);
  if (action.type === AUTOMATION_ACTION_TYPES.APPLY_PROFILE) return gallery.profiles.some((profile) => profile.id === action.profileId);
  if ([AUTOMATION_ACTION_TYPES.SEQUENCE_NEXT, AUTOMATION_ACTION_TYPES.SEQUENCE_PREVIOUS, AUTOMATION_ACTION_TYPES.SEQUENCE_RESET, AUTOMATION_ACTION_TYPES.SEQUENCE_STEP].includes(action.type)) return gallery.sequences.some((sequence) => sequence.id === action.sequenceId);
  return true;
}

function conditionDiagnosticHtml(item) {
  return `<div class="aig-automation-condition-result ${item.matched ? "is-match" : "is-miss"}"><i class="fa-solid ${item.matched ? "fa-check" : "fa-xmark"}"></i><strong>${escapeHtml(item.fact)}</strong><span>${escapeHtml(item.operator)}</span><code>${escapeHtml(formatValue(item.actual))} / ${escapeHtml(formatValue(item.expected))}</code></div>`;
}

function factOptions(facts, selected) {
  const list = facts.some((fact) => fact.key === selected) || !selected ? facts : [{ key: selected, label: selected, source: "missing" }, ...facts];
  return list.map((fact) => `<option value="${escapeAttribute(fact.key)}" ${fact.key === selected ? "selected" : ""}>${escapeHtml(localizeFact(fact))}${fact.source === "missing" ? ` — ${escapeHtml(localize("automation.unavailable"))}` : ""}</option>`).join("");
}

function localizeFact(fact) {
  const localized = globalThis.game?.i18n?.localize?.(fact.label);
  return localized && localized !== fact.label ? localized : fact.key;
}

function options(values, selected, prefix) {
  return values.map((value) => `<option value="${escapeAttribute(value)}" ${value === selected ? "selected" : ""}>${escapeHtml(localize(`${prefix}.${value}`))}</option>`).join("");
}

function targetOptions(items, selected) {
  const list = items.some((item) => item.id === selected) || !selected ? items : [{ id: selected, name: `${selected} — ${localize("automation.referenceMissing")}` }, ...items];
  if (!list.length) return `<option value="">${escapeHtml(localize("automation.noTargets"))}</option>`;
  return list.map((item) => `<option value="${escapeAttribute(item.id)}" ${item.id === selected ? "selected" : ""}>${escapeHtml(item.name)}</option>`).join("");
}

function targetField(selected) {
  const targets = [APPLY_TARGETS.PORTRAIT, APPLY_TARGETS.PROTOTYPE, APPLY_TARGETS.CURRENT_TOKEN, APPLY_TARGETS.SCENE_TOKENS, APPLY_TARGETS.PORTRAIT_PROTOTYPE, APPLY_TARGETS.PORTRAIT_CURRENT, APPLY_TARGETS.EVERYTHING];
  return `<label class="aig-field"><span>${escapeHtml(localize("automation.applyTarget"))}</span><select data-action-field="target">${targets.map((target) => `<option value="${target}" ${target === selected ? "selected" : ""}>${escapeHtml(localize(`targets.${target.replace(/-([a-z])/g, (_match, character) => character.toUpperCase())}`))}</option>`).join("")}</select></label>`;
}

function nodeAt(root, path) {
  let node = root;
  for (const index of pathParts(path)) node = node?.children?.[index];
  return node;
}

function pathParts(path) {
  return String(path ?? "").split(".").filter((part) => part !== "").map(Number);
}

function childPath(parent, index) {
  return parent ? `${parent}.${index}` : String(index);
}

function parseValue(value) {
  const trimmed = String(value ?? "").trim();
  if (!trimmed) return "";
  try { return JSON.parse(trimmed); } catch { return trimmed; }
}

function formatValue(value) {
  if (value === undefined) return "";
  if (typeof value === "string") return value;
  try { return JSON.stringify(value); } catch { return String(value); }
}

function disabledIf(condition) {
  return condition ? "disabled" : "";
}

function getSetting(key, fallback) {
  try { return globalThis.game?.settings?.get?.(MODULE_ID, key) ?? fallback; } catch { return fallback; }
}

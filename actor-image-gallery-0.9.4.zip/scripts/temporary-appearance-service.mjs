import { APPLY_TARGETS, HOOKS, MODULE_ID } from "./constants.mjs";
import { buildApplyPlan, resolveGalleryTarget } from "./foundry/image-application.mjs";
import { actorCanUpdate, deepClone, getActiveTokenForActor, warn } from "./utils.mjs";

export class TemporaryAppearanceService {
  #repository;
  #applicator;

  constructor({ repository, applicator }) {
    this.#repository = repository;
    this.#applicator = applicator;
  }

  getState(actor) {
    return this.#repository.read(actor).temporaryState;
  }

  async apply(actor, entryId, target = APPLY_TARGETS.PORTRAIT_CURRENT, { token = null, applicationContext = null } = {}) {
    if (!actor) throw new TemporaryAppearanceError("actorRequired");
    if (!actorCanUpdate(actor)) throw new TemporaryAppearanceError("permissionDenied");
    const gallery = this.#repository.read(actor);
    const entry = gallery.entries.find((candidate) => candidate.id === entryId);
    if (!entry) throw new TemporaryAppearanceError("entryNotFound");
    const resolvedTarget = resolveGalleryTarget(
      target === APPLY_TARGETS.ASK ? APPLY_TARGETS.PORTRAIT_CURRENT : target,
      { ignoreTokenChanges: gallery.ignoreTokenChanges }
    );
    const plan = buildApplyPlan(resolvedTarget);
    const activeToken = getActiveTokenForActor(actor, token);
    const sceneTokens = getSceneActorTokens(actor);
    if (plan.currentToken && !activeToken) throw new TemporaryAppearanceError("tokenRequired");
    if (plan.sceneTokens && !sceneTokens.length) throw new TemporaryAppearanceError("sceneTokensRequired");

    const existing = normalizeTemporaryState(gallery.temporaryState, actor);
    const state = {
      actorUuid: actor.uuid ?? `Actor.${actor.id}`,
      startedAt: existing?.startedAt ?? Date.now(),
      source: "manual",
      restorationSnapshot: extendSnapshot(existing?.restorationSnapshot, {
        actor,
        plan,
        activeToken,
        sceneTokens
      }),
      activeEntryId: entry.id,
      activeProfileId: existing?.activeProfileId ?? gallery.activeProfileId ?? null,
      target: resolvedTarget
    };

    await this.#repository.mutate(actor, (current) => ({ ...current, temporaryState: state }), applicationContext ? { context: applicationContext } : {});
    await this.#applicator.apply(actor, entry.id, resolvedTarget, { token: activeToken, preserveTemporary: true, preserveActiveProfile: true, preserveActiveSequence: true, applicationContext });
    const persisted = this.#repository.read(actor).temporaryState;
    callHook(HOOKS.TEMPORARY_STARTED, { actor, entry: deepClone(entry), state: deepClone(persisted), replaced: Boolean(existing) });
    return { actor, entry, state: persisted, target: resolvedTarget, replaced: Boolean(existing) };
  }

  async revert(actor, { applicationContext = null } = {}) {
    if (!actor) throw new TemporaryAppearanceError("actorRequired");
    if (!actorCanUpdate(actor)) throw new TemporaryAppearanceError("permissionDenied");
    const gallery = this.#repository.read(actor);
    const state = normalizeTemporaryState(gallery.temporaryState, actor);
    if (!state) throw new TemporaryAppearanceError("temporaryNotActive");
    const snapshot = state.restorationSnapshot;
    const actorUpdate = {};
    if (snapshot.portrait) actorUpdate.img = snapshot.portrait.source;
    if (snapshot.prototype) actorUpdate["prototypeToken.texture.src"] = snapshot.prototype.source;

    const tokenBatches = restorationTokenBatches(snapshot.tokens);
    const updateOptions = { [MODULE_ID]: applicationContext ?? { origin: "manual", source: "temporary-revert" } };
    if (Object.keys(actorUpdate).length) await actor.update(actorUpdate, updateOptions);
    for (const { scene, updates } of tokenBatches) {
      if (updates.length) await scene.updateEmbeddedDocuments("Token", updates, updateOptions);
    }

    const mutation = await this.#repository.mutate(actor, (current) => ({
      ...current,
      temporaryState: null,
      activeProfileId: state.activeProfileId && current.profiles.some((profile) => profile.id === state.activeProfileId)
        ? state.activeProfileId
        : current.activeProfileId
    }), applicationContext ? { context: applicationContext } : {});
    callHook(HOOKS.TEMPORARY_REVERTED, { actor, state: deepClone(state), origin: applicationContext?.origin ?? "manual", applicationContext: applicationContext ? deepClone(applicationContext) : null });
    return { actor, state, gallery: mutation.gallery };
  }
}

export function normalizeTemporaryState(value, actor = null) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  const snapshot = value.restorationSnapshot;
  if (!snapshot || typeof snapshot !== "object" || Array.isArray(snapshot)) return null;
  return {
    actorUuid: String(value.actorUuid ?? actor?.uuid ?? (actor?.id ? `Actor.${actor.id}` : "")),
    startedAt: Number.isFinite(Number(value.startedAt)) ? Number(value.startedAt) : Date.now(),
    source: "manual",
    restorationSnapshot: {
      portrait: normalizeSourceSnapshot(snapshot.portrait),
      prototype: normalizeSourceSnapshot(snapshot.prototype),
      tokens: normalizeTokenSnapshots(snapshot.tokens)
    },
    activeEntryId: value.activeEntryId ? String(value.activeEntryId) : null,
    activeProfileId: value.activeProfileId ? String(value.activeProfileId) : null,
    target: String(value.target ?? APPLY_TARGETS.PORTRAIT_CURRENT)
  };
}

function extendSnapshot(input, { actor, plan, activeToken, sceneTokens }) {
  const snapshot = normalizeTemporaryState({ restorationSnapshot: input }, actor)?.restorationSnapshot ?? {
    portrait: null,
    prototype: null,
    tokens: []
  };
  if (plan.portrait && !snapshot.portrait) snapshot.portrait = { source: String(actor.img ?? "") };
  if (plan.prototype && !snapshot.prototype) snapshot.prototype = { source: String(actor.prototypeToken?.texture?.src ?? "") };
  const documents = [];
  if (plan.currentToken && activeToken?.document) documents.push(activeToken.document);
  if (plan.sceneTokens) documents.push(...sceneTokens);
  const existing = new Set(snapshot.tokens.map((item) => `${item.sceneId}:${item.tokenId}`));
  for (const document of documents) {
    const item = tokenSnapshot(document);
    const key = `${item.sceneId}:${item.tokenId}`;
    if (!item.tokenId || existing.has(key)) continue;
    existing.add(key);
    snapshot.tokens.push(item);
  }
  return snapshot;
}

function tokenSnapshot(document) {
  return {
    sceneId: String(document.parent?.id ?? globalThis.canvas?.scene?.id ?? ""),
    tokenId: String(document.id ?? ""),
    source: String(document.texture?.src ?? "")
  };
}

function normalizeSourceSnapshot(value) {
  return value && typeof value === "object" && !Array.isArray(value)
    ? { source: String(value.source ?? "") }
    : null;
}

function normalizeTokenSnapshots(value) {
  if (!Array.isArray(value)) return [];
  const seen = new Set();
  return value.map((item) => ({
    sceneId: String(item?.sceneId ?? ""),
    tokenId: String(item?.tokenId ?? item?.id ?? ""),
    source: String(item?.source ?? "")
  })).filter((item) => {
    const key = `${item.sceneId}:${item.tokenId}`;
    if (!item.tokenId || seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function getSceneActorTokens(actor) {
  return Array.from(globalThis.canvas?.scene?.tokens ?? [])
    .filter((document) => document.actorId === actor.id || document.actor?.id === actor.id);
}

function restorationTokenBatches(tokens) {
  const batches = new Map();
  for (const item of tokens ?? []) {
    const scene = resolveScene(item.sceneId);
    if (!scene) continue;
    const token = scene.tokens?.get?.(item.tokenId)
      ?? Array.from(scene.tokens ?? []).find((candidate) => candidate.id === item.tokenId);
    if (!token) continue;
    if (!batches.has(scene.id)) batches.set(scene.id, { scene, updates: [] });
    batches.get(scene.id).updates.push({ _id: item.tokenId, "texture.src": item.source });
  }
  return Array.from(batches.values());
}

function resolveScene(sceneId) {
  if (globalThis.canvas?.scene?.id === sceneId) return globalThis.canvas.scene;
  return globalThis.game?.scenes?.get?.(sceneId) ?? null;
}

function callHook(name, ...args) {
  try {
    globalThis.Hooks?.callAll?.(name, ...args);
  } catch (error) {
    warn(`Integration hook ${name} failed.`, error);
  }
}

export class TemporaryAppearanceError extends Error {
  constructor(code) {
    super(code);
    this.name = "TemporaryAppearanceError";
    this.code = code;
  }
}

import {
  APPEARANCE_SEQUENCE_SCHEMA_VERSION,
  SEQUENCE_MODES,
  SEQUENCE_TARGET_TYPES
} from "../constants.mjs";
import { deepClone, randomId } from "../utils.mjs";

const VALID_MODES = new Set(Object.values(SEQUENCE_MODES));
const VALID_TARGETS = new Set(Object.values(SEQUENCE_TARGET_TYPES));

export function createAppearanceSequence(input = {}, { now = new Date().toISOString(), id = randomId(), stepIdFactory = randomId } = {}) {
  const source = input && typeof input === "object" && !Array.isArray(input) ? deepClone(input) : {};
  const createdAt = validDate(source.createdAt) ?? now;
  const stableId = String(source.id ?? id).trim() || String(id);
  return {
    ...source,
    schemaVersion: APPEARANCE_SEQUENCE_SCHEMA_VERSION,
    id: stableId,
    name: String(source.name ?? "").trim(),
    description: String(source.description ?? "").trim(),
    mode: VALID_MODES.has(source.mode) ? source.mode : SEQUENCE_MODES.CLAMP,
    steps: normalizeSequenceSteps(source.steps, { idFactory: stepIdFactory }),
    createdAt,
    updatedAt: validDate(source.updatedAt) ?? createdAt
  };
}

export function addAppearanceSequence(galleryInput, sequenceInput, options = {}) {
  const gallery = normalizeSequenceGallery(galleryInput);
  const sequence = createAppearanceSequence(sequenceInput, options);
  validateSequence(sequence);
  if (gallery.sequences.some((candidate) => candidate.id === sequence.id)) throw new AppearanceSequenceError("sequenceIdConflict");
  gallery.sequences.push(sequence);
  return { gallery, sequence };
}

export function updateAppearanceSequence(galleryInput, sequenceId, patch, { now = new Date().toISOString(), stepIdFactory = randomId } = {}) {
  const gallery = normalizeSequenceGallery(galleryInput);
  const index = gallery.sequences.findIndex((candidate) => candidate.id === String(sequenceId));
  if (index < 0) throw new AppearanceSequenceError("sequenceNotFound");
  const current = gallery.sequences[index];
  const edits = patch && typeof patch === "object" && !Array.isArray(patch) ? patch : {};
  const sequence = createAppearanceSequence({
    ...current,
    ...deepClone(edits),
    id: current.id,
    createdAt: current.createdAt,
    updatedAt: now,
    steps: Object.hasOwn(edits, "steps") ? edits.steps : current.steps
  }, { now, id: current.id, stepIdFactory });
  validateSequence(sequence);
  gallery.sequences[index] = sequence;
  const state = gallery.sequenceState[sequence.id];
  if (state && !sequence.steps.some((step) => step.id === state.currentStepId)) delete gallery.sequenceState[sequence.id];
  return { gallery, sequence };
}

export function duplicateAppearanceSequence(galleryInput, sequenceId, { suffix, now = new Date().toISOString(), id, stepIdFactory = randomId } = {}) {
  const gallery = normalizeSequenceGallery(galleryInput);
  const source = gallery.sequences.find((candidate) => candidate.id === String(sequenceId));
  if (!source) throw new AppearanceSequenceError("sequenceNotFound");
  return addAppearanceSequence(gallery, {
    ...deepClone(source),
    id: undefined,
    name: `${source.name}${suffix ?? " copy"}`,
    steps: source.steps.map((step) => ({ ...step, id: undefined })),
    createdAt: now,
    updatedAt: now
  }, { now, id, stepIdFactory });
}

export function removeAppearanceSequence(galleryInput, sequenceId) {
  const gallery = normalizeSequenceGallery(galleryInput);
  const index = gallery.sequences.findIndex((candidate) => candidate.id === String(sequenceId));
  if (index < 0) throw new AppearanceSequenceError("sequenceNotFound");
  const [sequence] = gallery.sequences.splice(index, 1);
  delete gallery.sequenceState[sequence.id];
  if (gallery.activeSequenceId === sequence.id) gallery.activeSequenceId = null;
  return { gallery, sequence };
}

export function reorderAppearanceSequences(galleryInput, orderedIds) {
  const gallery = normalizeSequenceGallery(galleryInput);
  const allIds = gallery.sequences.map((sequence) => sequence.id);
  const normalized = Array.from(new Set((Array.isArray(orderedIds) ? orderedIds : []).map(String)));
  if (normalized.length !== allIds.length || allIds.some((id) => !normalized.includes(id))) {
    throw new AppearanceSequenceError("sequenceOrderInvalid");
  }
  const byId = new Map(gallery.sequences.map((sequence) => [sequence.id, sequence]));
  gallery.sequences = normalized.map((id) => byId.get(id));
  return gallery;
}

export function normalizeAppearanceSequences(value) {
  const ids = new Set();
  const sequences = [];
  for (const item of Array.isArray(value) ? value : []) {
    const sequence = createAppearanceSequence(item);
    if (!sequence.id || ids.has(sequence.id)) continue;
    ids.add(sequence.id);
    sequences.push(sequence);
  }
  return sequences;
}

export function normalizeSequenceState(value, sequences) {
  const result = {};
  const byId = new Map(sequences.map((sequence) => [sequence.id, sequence]));
  if (!value || typeof value !== "object" || Array.isArray(value)) return result;
  for (const [sequenceId, input] of Object.entries(value)) {
    const sequence = byId.get(sequenceId);
    if (!sequence || !input || typeof input !== "object" || Array.isArray(input)) continue;
    const stepIndex = sequence.steps.findIndex((step) => step.id === String(input.currentStepId ?? ""));
    const numericIndex = clampIndex(input.index, sequence.steps.length);
    const index = stepIndex >= 0 ? stepIndex : numericIndex;
    if (index < 0) continue;
    result[sequenceId] = {
      index,
      cursor: Number.isInteger(Number(input.cursor)) ? Number(input.cursor) : index,
      currentStepId: sequence.steps[index].id,
      updatedAt: validDate(input.updatedAt)
    };
  }
  return result;
}

export function computeSequenceNavigation(sequenceInput, stateInput, action, { stepIndex = null } = {}) {
  const sequence = createAppearanceSequence(sequenceInput);
  validateSequence(sequence);
  const count = sequence.steps.length;
  const state = normalizeSingleState(stateInput, sequence);
  const hasState = Boolean(state);
  let index = state?.index ?? 0;
  let cursor = state?.cursor ?? index;

  if (action === "reset") {
    index = 0;
    cursor = 0;
  } else if (action === "step") {
    const requested = Number(stepIndex);
    if (!Number.isInteger(requested) || requested < 0 || requested >= count) throw new AppearanceSequenceError("sequenceStepInvalid");
    index = requested;
    cursor = requested;
  } else if (!hasState) {
    index = 0;
    cursor = 0;
  } else if (action === "next" || action === "previous") {
    const delta = action === "next" ? 1 : -1;
    if (sequence.mode === SEQUENCE_MODES.CLAMP) {
      index = Math.min(count - 1, Math.max(0, index + delta));
      cursor = index;
    } else if (sequence.mode === SEQUENCE_MODES.LOOP) {
      index = modulo(index + delta, count);
      cursor = index;
    } else {
      const period = count <= 1 ? 1 : 2 * (count - 1);
      cursor = modulo(cursor + delta, period);
      index = cursor <= count - 1 ? cursor : period - cursor;
    }
  } else throw new AppearanceSequenceError("sequenceActionInvalid");

  const step = sequence.steps[index];
  return {
    index,
    cursor,
    step,
    changed: !hasState || state.index !== index || action === "reset" || action === "step",
    atBoundary: hasState && state.index === index && ["next", "previous"].includes(action)
  };
}

export function normalizeSequenceSteps(value, { idFactory = randomId } = {}) {
  const result = [];
  const ids = new Set();
  for (const input of Array.isArray(value) ? value : []) {
    if (!input || typeof input !== "object" || Array.isArray(input)) continue;
    let id = String(input.id ?? idFactory()).trim() || String(idFactory());
    while (ids.has(id)) id = String(idFactory());
    const targetType = VALID_TARGETS.has(input.targetType) ? input.targetType : null;
    const targetId = String(input.targetId ?? "").trim();
    if (!targetType || !targetId) continue;
    ids.add(id);
    result.push({
      ...deepClone(input),
      id,
      label: String(input.label ?? "").trim(),
      targetType,
      targetId
    });
  }
  return result;
}

export class AppearanceSequenceError extends Error {
  constructor(code) {
    super(code);
    this.name = "AppearanceSequenceError";
    this.code = code;
  }
}

function normalizeSequenceGallery(input) {
  const gallery = deepClone(input && typeof input === "object" ? input : {});
  gallery.sequences = normalizeAppearanceSequences(gallery.sequences);
  gallery.sequenceState = normalizeSequenceState(gallery.sequenceState, gallery.sequences);
  gallery.activeSequenceId = gallery.sequences.some((sequence) => sequence.id === String(gallery.activeSequenceId ?? ""))
    ? String(gallery.activeSequenceId)
    : null;
  return gallery;
}

function normalizeSingleState(value, sequence) {
  return normalizeSequenceState({ [sequence.id]: value }, [sequence])[sequence.id] ?? null;
}

function validateSequence(sequence) {
  if (!sequence.name) throw new AppearanceSequenceError("sequenceNameRequired");
  if (!sequence.steps.length) throw new AppearanceSequenceError("sequenceStepsRequired");
}

function clampIndex(value, count) {
  const index = Number(value);
  return Number.isInteger(index) && index >= 0 && index < count ? index : -1;
}

function modulo(value, modulus) {
  return ((value % modulus) + modulus) % modulus;
}

function validDate(value) {
  if (!value) return null;
  const time = Date.parse(value);
  return Number.isFinite(time) ? new Date(time).toISOString() : null;
}

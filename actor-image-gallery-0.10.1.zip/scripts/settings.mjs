import { APPLY_TARGETS, MODULE_ID } from "./constants.mjs";
import { DEFAULT_PALETTE, serializePalette } from "./palette.mjs";

export function registerSettings(handlers = {}) {
  register("enablePortraitFeatures", {
    name: "AIG.settings.enablePortraitFeatures.name",
    hint: "AIG.settings.enablePortraitFeatures.hint",
    scope: "user",
    config: true,
    type: Boolean,
    default: true
  });
  register("enableTokenFeatures", {
    name: "AIG.settings.enableTokenFeatures.name",
    hint: "AIG.settings.enableTokenFeatures.hint",
    scope: "user",
    config: true,
    type: Boolean,
    default: true
  });
  register("portraitClickQuickSwitch", {
    name: "AIG.settings.portraitClickQuickSwitch.name",
    hint: "AIG.settings.portraitClickQuickSwitch.hint",
    scope: "user",
    config: true,
    type: Boolean,
    default: true
  });
  register("defaultApplyTarget", {
    name: "AIG.settings.defaultApplyTarget.name",
    hint: "AIG.settings.defaultApplyTarget.hint",
    scope: "user",
    config: true,
    type: String,
    choices: targetChoices(true),
    default: APPLY_TARGETS.PORTRAIT_CURRENT
  });
  register("quickApplyTarget", {
    name: "AIG.settings.quickApplyTarget.name",
    hint: "AIG.settings.quickApplyTarget.hint",
    scope: "user",
    config: true,
    type: String,
    choices: targetChoices(false),
    default: APPLY_TARGETS.PORTRAIT_CURRENT
  });
  register("quickConfirmMode", {
    name: "AIG.settings.quickConfirmMode.name",
    hint: "AIG.settings.quickConfirmMode.hint",
    scope: "user",
    config: true,
    type: String,
    choices: {
      confirm: "AIG.settings.quickConfirmMode.confirm",
      instant: "AIG.settings.quickConfirmMode.instant"
    },
    default: "confirm"
  });
  register("quickFavoritesOnly", {
    name: "AIG.settings.quickFavoritesOnly.name",
    hint: "AIG.settings.quickFavoritesOnly.hint",
    scope: "user",
    config: true,
    type: Boolean,
    default: false
  });
  register("preloadFavorites", {
    name: "AIG.settings.preloadFavorites.name",
    hint: "AIG.settings.preloadFavorites.hint",
    scope: "user",
    config: true,
    type: Boolean,
    default: true
  });
  register("reducedMotion", {
    name: "AIG.settings.reducedMotion.name",
    hint: "AIG.settings.reducedMotion.hint",
    scope: "client",
    config: true,
    type: Boolean,
    default: globalThis.matchMedia?.("(prefers-reduced-motion: reduce)")?.matches ?? false
  });
  register("notificationLevel", {
    name: "AIG.settings.notificationLevel.name",
    hint: "AIG.settings.notificationLevel.hint",
    scope: "user",
    config: true,
    type: String,
    choices: {
      errors: "AIG.settings.notificationLevel.errors",
      warnings: "AIG.settings.notificationLevel.warnings",
      all: "AIG.settings.notificationLevel.all"
    },
    default: "errors"
  });
  register("customPalette", {
    scope: "user",
    config: false,
    type: String,
    default: serializePalette(DEFAULT_PALETTE)
  });
  register("globalGallery", {
    scope: "world",
    config: false,
    restricted: true,
    type: Object,
    default: { schemaVersion: 1, entries: [] },
    onChange: () => handlers.globalGalleryChanged?.()
  });
  register("galleryView", { scope: "user", config: false, type: String, default: "grid" });
  register("gallerySort", { scope: "user", config: false, type: String, default: "manual" });
  register("sidebarWidth", { scope: "user", config: false, type: Number, default: 168 });
  register("inspectorWidth", { scope: "user", config: false, type: Number, default: 312 });
  register("inspectorSide", { scope: "user", config: false, type: String, default: "right" });
}

export function registerKeybindings(handlers) {
  for (let slot = 1; slot <= 4; slot += 1) {
    game.keybindings.register(MODULE_ID, `quick-slot-${slot}`, {
      name: `AIG.keybindings.slot${slot}.name`,
      hint: "AIG.keybindings.slot.hint",
      editable: [{ key: `Digit${slot}`, modifiers: ["ALT"] }],
      onDown: () => handlers.quickSlot(slot),
      restricted: false,
      repeat: false
    });
  }
  game.keybindings.register(MODULE_ID, "previous-image", {
    name: "AIG.keybindings.previous.name",
    hint: "AIG.keybindings.previous.hint",
    editable: [{ key: "Backquote", modifiers: ["ALT"] }],
    onDown: () => handlers.previous(),
    restricted: false,
    repeat: false
  });
  game.keybindings.register(MODULE_ID, "open-gallery", {
    name: "AIG.keybindings.open.name",
    hint: "AIG.keybindings.open.hint",
    editable: [],
    onDown: () => handlers.open(),
    restricted: false,
    repeat: false
  });
}

function register(key, data) {
  game.settings.register(MODULE_ID, key, data);
}

function targetChoices(includeAsk) {
  const choices = {
    [APPLY_TARGETS.PORTRAIT]: "AIG.targets.portrait",
    [APPLY_TARGETS.PROTOTYPE]: "AIG.targets.prototypeToken",
    [APPLY_TARGETS.CURRENT_TOKEN]: "AIG.targets.currentToken",
    [APPLY_TARGETS.SCENE_TOKENS]: "AIG.targets.sceneTokens",
    [APPLY_TARGETS.PORTRAIT_PROTOTYPE]: "AIG.targets.portraitPrototype",
    [APPLY_TARGETS.PORTRAIT_CURRENT]: "AIG.targets.portraitCurrent",
    [APPLY_TARGETS.EVERYTHING]: "AIG.targets.everything"
  };
  if (includeAsk) choices[APPLY_TARGETS.ASK] = "AIG.targets.ask";
  return choices;
}

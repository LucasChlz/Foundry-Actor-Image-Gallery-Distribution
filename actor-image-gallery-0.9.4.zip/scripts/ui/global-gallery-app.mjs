import { MODULE_ID, SORT_MODES } from "../constants.mjs";
import {
  addGlobalEntry,
  createGlobalEntry,
  getGlobalCategories,
  queryGlobalEntries,
  removeGlobalEntry,
  toggleGlobalFavorite,
  updateGlobalEntry
} from "../domain/global-gallery.mjs";
import { droppedImageFiles, extractDroppedSource } from "../domain/drop.mjs";
import { ApplicationV2Class, getFilePickerClass } from "../foundry/compatibility.mjs";
import { ThumbnailService } from "../foundry/image-application.mjs";
import { applyPalette, DEFAULT_PALETTE } from "../palette.mjs";
import { downloadBackup, importStrategyLabel, importStrategyOptions, readBackupFile } from "./backup-ui.mjs";
import {
  actorCanUpdate,
  confirmAction,
  deepClone,
  escapeAttribute,
  escapeHtml,
  localize,
  notify,
  slugifyFilename,
  sourceName,
  warn
} from "../utils.mjs";

export class GlobalGalleryApplication extends ApplicationV2Class {
  static DEFAULT_OPTIONS = {
    id: "actor-image-global-gallery",
    classes: ["actor-image-gallery-window", "actor-image-global-gallery-window"],
    tag: "section",
    window: {
      frame: true,
      positioned: true,
      minimizable: true,
      resizable: true,
      icon: "fa-solid fa-earth-americas"
    },
    position: { width: 1100, height: 740 }
  };

  #repository;
  #service;
  #thumbnails;
  #backupService;
  #gallery;
  #state;
  #editing = null;
  #observer = null;
  #backupImportScope = "global";

  constructor({ repository, service, backupService = null, thumbnails = new ThumbnailService(), actor = null }) {
    super({ id: `${MODULE_ID}-global-gallery` });
    this.#repository = repository;
    this.#service = service;
    this.#thumbnails = thumbnails;
    this.#backupService = backupService;
    this.#gallery = repository.read();
    this.#state = {
      query: "",
      category: "",
      favoritesOnly: false,
      sort: SORT_MODES.MANUAL,
      selectedIds: new Set(),
      actorId: actor?.id ?? ""
    };
  }

  get title() {
    return localize("global.title");
  }

  setTargetActor(actor) {
    if (actor?.id) this.#state.actorId = actor.id;
    if (this.rendered) this.#renderTargetPanel();
  }

  async refresh() {
    this.#gallery = this.#repository.read();
    const ids = new Set(this.#gallery.entries.map((entry) => entry.id));
    this.#state.selectedIds = new Set(Array.from(this.#state.selectedIds).filter((id) => ids.has(id)));
    if (this.rendered) await this.render({ force: true });
  }

  async _renderHTML() {
    const root = document.createElement("div");
    root.className = "aig-shell aig-global-shell";
    root.dataset.reducedMotion = String(Boolean(getSetting("reducedMotion", false)));
    applyPalette(root, getSetting("customPalette", DEFAULT_PALETTE));
    root.innerHTML = `
      <header class="aig-hero aig-global-hero">
        <div class="aig-global-hero__icon"><i class="fa-solid fa-earth-americas" aria-hidden="true"></i></div>
        <div class="aig-hero__copy">
          <span class="aig-kicker">${escapeHtml(localize("global.kicker"))}</span>
          <h1>${escapeHtml(localize("global.title"))}</h1>
          <p data-role="global-count"></p>
        </div>
        <div class="aig-hero__actions">
          <button type="button" class="aig-button" data-action="global-backup-open" title="${escapeAttribute(localize("backup.openHint"))}"><i class="fa-solid fa-box-archive"></i><span>${escapeHtml(localize("backup.open"))}</span></button>
          <button type="button" class="aig-button aig-button--signal" data-action="new-global-entry" ${disabledIf(!this.#canManage())}>
            <i class="fa-solid fa-plus" aria-hidden="true"></i><span>${escapeHtml(localize("global.add"))}</span>
          </button>
        </div>
      </header>
      <section class="aig-toolbar" aria-label="${escapeAttribute(localize("global.tools"))}">
        <label class="aig-search">
          <i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i>
          <span class="sr-only">${escapeHtml(localize("actions.search"))}</span>
          <input type="search" data-role="global-search" value="${escapeAttribute(this.#state.query)}" placeholder="${escapeAttribute(localize("global.searchPlaceholder"))}">
        </label>
        <label class="aig-select-label"><span>${escapeHtml(localize("global.category"))}</span>
          <select data-role="global-category">${categoryOptions(this.#gallery, this.#state.category)}</select>
        </label>
        <button type="button" class="aig-icon-button ${this.#state.favoritesOnly ? "is-active" : ""}" data-action="global-favorites" title="${escapeAttribute(localize("actions.favoritesOnly"))}" aria-pressed="${this.#state.favoritesOnly}"><i class="fa-solid fa-star"></i></button>
        <label class="aig-select-label"><span>${escapeHtml(localize("actions.sort"))}</span>
          <select data-role="global-sort">${sortOptions(this.#state.sort)}</select>
        </label>
      </section>
      ${globalBackupPanelHtml(this.#canManage())}
      <div class="aig-global-workspace">
        <main class="aig-gallery aig-global-gallery" data-role="global-drop-zone">
          <div class="aig-gallery__empty" data-role="global-empty" hidden></div>
          <div class="aig-items aig-global-items" data-role="global-items" role="list"></div>
          <div class="aig-drop-overlay" aria-hidden="true"><i class="fa-solid fa-cloud-arrow-up"></i><span>${escapeHtml(localize("global.dropImages"))}</span></div>
        </main>
        <aside class="aig-global-panel" data-role="global-panel"></aside>
      </div>
      <input type="file" accept="image/*" multiple data-role="global-local-files" hidden>
      <input type="file" accept="application/json,.json" data-role="global-backup-file" hidden>
    `;
    return root;
  }

  _replaceHTML(result, content) {
    content.replaceChildren(result);
  }

  async _onRender(context, options) {
    await super._onRender(context, options);
    const shell = this.#shell();
    if (!shell) return;
    shell.addEventListener("click", (event) => void this.#onClick(event));
    shell.addEventListener("input", (event) => this.#onInput(event));
    shell.addEventListener("change", (event) => void this.#onChange(event));
    shell.addEventListener("dragover", (event) => this.#onDragOver(event));
    shell.addEventListener("dragleave", (event) => this.#onDragLeave(event));
    shell.addEventListener("drop", (event) => void this.#onDrop(event));
    this.#renderContent();
  }

  async _onClose(options) {
    this.#observer?.disconnect();
    await super._onClose(options);
  }

  #renderContent() {
    this.#renderEntries();
    this.#renderTargetPanel();
  }

  #renderEntries() {
    const container = this.#shell()?.querySelector("[data-role='global-items']");
    const empty = this.#shell()?.querySelector("[data-role='global-empty']");
    const count = this.#shell()?.querySelector("[data-role='global-count']");
    if (!container || !empty) return;
    const entries = queryGlobalEntries(this.#gallery, this.#state);
    if (count) count.textContent = localize("global.count", { count: this.#gallery.entries.length });
    empty.hidden = entries.length > 0;
    empty.innerHTML = `<i class="fa-regular fa-images" aria-hidden="true"></i><strong>${escapeHtml(localize(this.#gallery.entries.length ? "global.noResults" : "global.empty"))}</strong><span>${escapeHtml(localize(this.#gallery.entries.length ? "global.noResultsHint" : "global.emptyHint"))}</span>`;
    container.innerHTML = entries.map((entry) => this.#entryHtml(entry)).join("");
    this.#hydrateThumbnails(container);
  }

  #entryHtml(entry) {
    const selected = this.#state.selectedIds.has(entry.id);
    return `
      <article class="aig-card aig-global-card ${selected ? "is-selected" : ""}" data-global-entry-id="${escapeAttribute(entry.id)}" role="listitem" tabindex="0">
        <div class="aig-card__image">
          <img src="icons/svg/mystery-man.svg" data-thumb-source="${escapeAttribute(entry.source)}" loading="lazy" alt="${escapeAttribute(entry.name)}" draggable="false">
          <label class="aig-global-card__select" title="${escapeAttribute(localize("global.select"))}"><input type="checkbox" data-role="global-selection" data-entry-id="${escapeAttribute(entry.id)}" ${selected ? "checked" : ""}><span><i class="fa-solid fa-check"></i></span></label>
          <button type="button" class="aig-card__favorite ${entry.favorite ? "is-active" : ""}" data-action="global-favorite" data-entry-id="${escapeAttribute(entry.id)}" title="${escapeAttribute(localize("actions.favorite"))}" ${disabledIf(!this.#canManage())}><i class="fa-${entry.favorite ? "solid" : "regular"} fa-star"></i></button>
        </div>
        <div class="aig-card__body">
          <div class="aig-card__heading"><strong>${escapeHtml(entry.name)}</strong></div>
          ${entry.category ? `<span class="aig-card__collection">${escapeHtml(entry.category)}</span>` : ""}
          <div class="aig-card__tags">${entry.tags.slice(0, 4).map((tag) => `<span>${escapeHtml(tag)}</span>`).join("")}</div>
          <p>${escapeHtml(entry.description)}</p>
          ${this.#canManage() ? `<div class="aig-global-card__actions"><button type="button" data-action="edit-global-entry" data-entry-id="${escapeAttribute(entry.id)}" title="${escapeAttribute(localize("actions.edit"))}"><i class="fa-solid fa-pen"></i></button><button type="button" data-action="remove-global-entry" data-entry-id="${escapeAttribute(entry.id)}" title="${escapeAttribute(localize("actions.remove"))}"><i class="fa-solid fa-trash"></i></button></div>` : ""}
        </div>
      </article>`;
  }

  #renderTargetPanel() {
    const panel = this.#shell()?.querySelector("[data-role='global-panel']");
    if (!panel) return;
    if (this.#editing) {
      panel.innerHTML = this.#editorHtml();
      return;
    }
    const selectedCount = this.#state.selectedIds.size;
    const actors = availableActors();
    if (!actors.some((actor) => actor.id === this.#state.actorId)) this.#state.actorId = actors[0]?.id ?? "";
    panel.innerHTML = `
      <div class="aig-global-panel__heading"><span class="aig-kicker">${escapeHtml(localize("global.reuseKicker"))}</span><h2>${escapeHtml(localize("global.reuseTitle"))}</h2></div>
      <p>${escapeHtml(localize("global.reuseHint"))}</p>
      <div class="aig-global-selection-summary"><strong>${selectedCount}</strong><span>${escapeHtml(localize("global.selected", { count: selectedCount }))}</span></div>
      <label class="aig-field"><span>${escapeHtml(localize("global.targetActor"))}</span><select data-role="global-actor">${actorOptions(actors, this.#state.actorId)}</select></label>
      <button type="button" class="aig-button aig-button--signal aig-button--wide" data-action="add-global-to-actor" ${disabledIf(!selectedCount || !this.#state.actorId)}><i class="fa-solid fa-arrow-right-to-bracket"></i><span>${escapeHtml(localize("global.addSelected"))}</span></button>
      <div class="aig-global-info"><i class="fa-solid fa-shield-heart"></i><p>${escapeHtml(localize("global.independentHint"))}</p></div>
      ${this.#canManage() ? `<button type="button" class="aig-button aig-button--wide" data-action="pick-global-local"><i class="fa-solid fa-upload"></i><span>${escapeHtml(localize("global.uploadMany"))}</span></button>` : `<div class="aig-global-info"><i class="fa-solid fa-lock"></i><p>${escapeHtml(localize("global.gmManaged"))}</p></div>`}
    `;
  }

  #editorHtml() {
    const entry = this.#editing;
    return `
      <form data-role="global-editor" class="aig-global-editor">
        <div class="aig-global-panel__heading"><span class="aig-kicker">${escapeHtml(localize("global.manageKicker"))}</span><h2>${escapeHtml(localize(entry.__new ? "global.add" : "global.edit"))}</h2></div>
        <div class="aig-global-editor__preview"><img data-role="global-editor-image" src="${escapeAttribute(entry.source || "icons/svg/mystery-man.svg")}" alt=""></div>
        <label class="aig-field"><span>${escapeHtml(localize("entry.source"))}</span><span class="aig-field__with-button"><input type="text" name="source" value="${escapeAttribute(entry.source)}" required><button type="button" data-action="browse-global-source" title="${escapeAttribute(localize("actions.browse"))}"><i class="fa-solid fa-folder-open"></i></button><button type="button" data-action="pick-global-local" title="${escapeAttribute(localize("actions.localFile"))}"><i class="fa-solid fa-upload"></i></button></span></label>
        <label class="aig-field"><span>${escapeHtml(localize("entry.name"))}</span><input type="text" name="name" value="${escapeAttribute(entry.name)}"></label>
        <label class="aig-field"><span>${escapeHtml(localize("entry.tags"))}</span><input type="text" name="tags" value="${escapeAttribute(entry.tags.join(", "))}" placeholder="${escapeAttribute(localize("entry.tagsPlaceholder"))}"></label>
        <label class="aig-field"><span>${escapeHtml(localize("global.category"))}</span><input type="text" name="category" value="${escapeAttribute(entry.category)}"></label>
        <label class="aig-field"><span>${escapeHtml(localize("entry.description"))}</span><textarea name="description" rows="4">${escapeHtml(entry.description)}</textarea></label>
        <div class="aig-editor__footer"><button type="button" class="aig-button" data-action="cancel-global-edit">${escapeHtml(localize("common.cancel"))}</button><button type="button" class="aig-button aig-button--signal" data-action="save-global-entry"><i class="fa-solid fa-floppy-disk"></i>${escapeHtml(localize("common.save"))}</button></div>
      </form>`;
  }

  async #onClick(event) {
    const actionTarget = event.target.closest?.("[data-action]");
    const card = event.target.closest?.("[data-global-entry-id]");
    try {
      if (!actionTarget) {
        if (card && !event.target.closest("input, button, label, a")) this.#toggleSelection(card.dataset.globalEntryId);
        return;
      }
      const action = actionTarget.dataset.action;
      const entryId = actionTarget.dataset.entryId ?? card?.dataset.globalEntryId;
      if (action === "new-global-entry") this.#openEditor();
      else if (action === "global-backup-open") this.#toggleBackupPanel(true);
      else if (action === "global-backup-close") this.#toggleBackupPanel(false);
      else if (action === "backup-export-global") this.#exportGlobalBackup();
      else if (action === "backup-export-world") this.#exportWorldBackup();
      else if (action === "backup-import-global" || action === "backup-import-world") {
        this.#backupImportScope = action === "backup-import-world" ? "world" : "global";
        this.#shell()?.querySelector("[data-role='global-backup-file']")?.click();
      }
      else if (action === "edit-global-entry") this.#openEditor(entryId);
      else if (action === "cancel-global-edit") { this.#editing = null; this.#renderTargetPanel(); }
      else if (action === "save-global-entry") await this.#saveEditor();
      else if (action === "global-favorite") await this.#mutate((gallery) => toggleGlobalFavorite(gallery, entryId));
      else if (action === "remove-global-entry") await this.#remove(entryId);
      else if (action === "global-favorites") {
        this.#state.favoritesOnly = !this.#state.favoritesOnly;
        actionTarget.classList.toggle("is-active", this.#state.favoritesOnly);
        actionTarget.setAttribute("aria-pressed", String(this.#state.favoritesOnly));
        this.#renderEntries();
      } else if (action === "add-global-to-actor") await this.#addSelectedToActor();
      else if (action === "browse-global-source") await this.#browseSource(actionTarget);
      else if (action === "pick-global-local") this.#shell()?.querySelector("[data-role='global-local-files']")?.click();
    } catch (error) {
      this.#handleError(error);
    }
  }

  #onInput(event) {
    if (event.target.dataset.role === "global-search") {
      this.#state.query = event.target.value;
      this.#renderEntries();
      return;
    }
    if (event.target.name === "source" && this.#editing) {
      this.#editing.source = event.target.value.trim();
      const preview = this.#shell()?.querySelector("[data-role='global-editor-image']");
      if (preview) preview.src = this.#editing.source || "icons/svg/mystery-man.svg";
    }
  }

  async #onChange(event) {
    try {
      if (event.target.dataset.role === "global-category") {
        this.#state.category = event.target.value;
        this.#renderEntries();
      } else if (event.target.dataset.role === "global-sort") {
        this.#state.sort = event.target.value;
        this.#renderEntries();
      } else if (event.target.dataset.role === "global-actor") {
        this.#state.actorId = event.target.value;
      } else if (event.target.dataset.role === "global-selection") {
        this.#setSelection(event.target.dataset.entryId, event.target.checked);
      } else if (event.target.dataset.role === "global-local-files" && event.target.files?.length) {
        const files = Array.from(event.target.files);
        if (this.#editing) await this.#useLocalFileInEditor(files[0]);
        else await this.#addLocalFiles(files);
        event.target.value = "";
      } else if (event.target.dataset.role === "global-backup-file" && event.target.files?.[0]) {
        await this.#importBackup(event.target.files[0], this.#backupImportScope);
        event.target.value = "";
      }
    } catch (error) {
      this.#handleError(error);
    }
  }

  #onDragOver(event) {
    if (!this.#canManage() || !event.dataTransfer) return;
    event.preventDefault();
    event.dataTransfer.dropEffect = "copy";
    this.#shell()?.querySelector("[data-role='global-drop-zone']")?.classList.add("is-external-drop");
  }

  #onDragLeave(event) {
    const shell = this.#shell();
    if (shell && (!event.relatedTarget || !shell.contains(event.relatedTarget))) shell.querySelector("[data-role='global-drop-zone']")?.classList.remove("is-external-drop");
  }

  async #onDrop(event) {
    if (!this.#canManage() || !event.dataTransfer) return;
    event.preventDefault();
    event.stopPropagation();
    try {
      const files = droppedImageFiles(event.dataTransfer);
      if (files.length) return await this.#addLocalFiles(files);
      const source = extractDroppedSource(event.dataTransfer.getData("text/uri-list") || event.dataTransfer.getData("text/plain"));
      if (source) await this.#addSource(source);
    } catch (error) {
      this.#handleError(error);
    } finally {
      this.#shell()?.querySelector("[data-role='global-drop-zone']")?.classList.remove("is-external-drop");
    }
  }

  #openEditor(entryId = null) {
    if (!this.#canManage()) return;
    const existing = this.#gallery.entries.find((entry) => entry.id === entryId);
    this.#editing = existing ? deepClone(existing) : { ...createGlobalEntry(), source: "", name: "", __new: true };
    this.#renderTargetPanel();
  }

  async #saveEditor() {
    if (!this.#canManage() || !this.#editing) return;
    const form = this.#shell()?.querySelector("[data-role='global-editor']");
    if (!form) return;
    const data = new FormData(form);
    const patch = {
      source: String(data.get("source") ?? "").trim(),
      name: String(data.get("name") ?? "").trim(),
      tags: String(data.get("tags") ?? ""),
      category: String(data.get("category") ?? "").trim(),
      description: String(data.get("description") ?? "").trim()
    };
    if (!patch.source) throw Object.assign(new Error("sourceRequired"), { code: "sourceRequired" });
    const editing = this.#editing;
    const result = await this.#repository.mutate((gallery) => editing.__new
      ? addGlobalEntry(gallery, patch)
      : updateGlobalEntry(gallery, editing.id, patch));
    this.#gallery = result.gallery;
    this.#editing = null;
    this.#refreshFilters();
    this.#renderContent();
    notify("info", editing.__new ? "notifications.globalAdded" : "notifications.globalSaved");
  }

  async #remove(entryId) {
    if (!this.#canManage()) return;
    const entry = this.#gallery.entries.find((candidate) => candidate.id === entryId);
    if (!entry) throw Object.assign(new Error("globalEntryNotFound"), { code: "globalEntryNotFound" });
    const confirmed = await confirmAction({
      title: localize("global.removeTitle"),
      content: `<p>${escapeHtml(localize("global.removeContent", { name: entry.name }))}</p>`
    });
    if (!confirmed) return;
    await this.#mutate((gallery) => removeGlobalEntry(gallery, entryId));
    this.#state.selectedIds.delete(entryId);
    this.#renderTargetPanel();
    notify("info", "notifications.globalRemoved");
  }

  async #addSelectedToActor() {
    const actor = globalThis.game?.actors?.get?.(this.#state.actorId);
    if (!actor) throw Object.assign(new Error("actorRequired"), { code: "actorRequired" });
    const result = await this.#service.addToActor(actor, Array.from(this.#state.selectedIds));
    notify("info", "notifications.globalAddedToActor", { count: result.entries.length, name: actor.name });
  }

  #toggleBackupPanel(open) {
    const panel = this.#shell()?.querySelector("[data-role='global-backup-panel']");
    if (!panel) return;
    panel.hidden = !open;
    if (open) panel.querySelector("button, select")?.focus();
  }

  #exportGlobalBackup() {
    if (!this.#backupService) throw Object.assign(new Error("backupUnavailable"), { code: "backupUnavailable" });
    downloadBackup(this.#backupService.exportGlobal(), "actor-image-gallery-global");
    notify("info", "notifications.backupExported");
  }

  #exportWorldBackup() {
    if (!this.#backupService) throw Object.assign(new Error("backupUnavailable"), { code: "backupUnavailable" });
    downloadBackup(this.#backupService.exportWorld(), "actor-image-gallery-world");
    notify("info", "notifications.backupExported");
  }

  async #importBackup(file, scope) {
    if (!this.#backupService) throw Object.assign(new Error("backupUnavailable"), { code: "backupUnavailable" });
    const strategy = this.#shell()?.querySelector("[data-role='global-backup-strategy']")?.value ?? "skip";
    const confirmed = await confirmAction({
      title: localize("backup.importTitle"),
      content: `<p>${escapeHtml(localize("backup.importConfirm", { strategy: importStrategyLabel(strategy) }))}</p>`
    });
    if (!confirmed) return;
    const content = await readBackupFile(file);
    const result = scope === "world"
      ? await this.#backupService.importWorld(content, { strategy })
      : await this.#backupService.importGlobal(content, { strategy });
    this.#gallery = this.#repository.read();
    this.#toggleBackupPanel(false);
    this.#renderContent();
    if (scope === "world") {
      const imported = result.actors.filter((actor) => actor.status === "imported").length;
      notify("info", "notifications.worldBackupImported", { count: imported });
    } else notify("info", "notifications.backupImported", result.report);
  }

  async #browseSource(button) {
    const input = this.#shell()?.querySelector("input[name='source']");
    const FilePicker = getFilePickerClass();
    if (!FilePicker || !input) throw Object.assign(new Error("filePickerUnavailable"), { code: "filePickerUnavailable" });
    const picker = new FilePicker({
      type: "image",
      current: input.value,
      field: input,
      button,
      callback: (path) => {
        input.value = path;
        input.dispatchEvent(new Event("input", { bubbles: true }));
      }
    });
    await picker.browse();
  }

  async #addLocalFiles(files) {
    for (const file of files) {
      const source = await uploadGlobalFile(file);
      await this.#addSource(source, sourceName(file.name), { notifyUser: false });
    }
    notify("info", "notifications.globalAddedMany", { count: files.length });
  }

  async #useLocalFileInEditor(file) {
    const source = await uploadGlobalFile(file);
    const sourceInput = this.#shell()?.querySelector("input[name='source']");
    const nameInput = this.#shell()?.querySelector("input[name='name']");
    if (!sourceInput || !this.#editing) return;
    sourceInput.value = source;
    this.#editing.source = source;
    if (nameInput && !nameInput.value) nameInput.value = sourceName(file.name);
    const preview = this.#shell()?.querySelector("[data-role='global-editor-image']");
    if (preview) preview.src = source;
  }

  async #addSource(source, name = sourceName(source), { notifyUser = true } = {}) {
    const result = await this.#repository.mutate((gallery) => addGlobalEntry(gallery, { source, name }));
    this.#gallery = result.gallery;
    this.#refreshFilters();
    this.#renderContent();
    if (notifyUser) notify("info", "notifications.globalAdded");
  }

  async #mutate(mutator) {
    const result = await this.#repository.mutate(mutator);
    this.#gallery = result.gallery;
    this.#refreshFilters();
    this.#renderContent();
    return result;
  }

  #refreshFilters() {
    const category = this.#shell()?.querySelector("[data-role='global-category']");
    if (category) category.innerHTML = categoryOptions(this.#gallery, this.#state.category);
  }

  #toggleSelection(entryId) {
    this.#setSelection(entryId, !this.#state.selectedIds.has(entryId));
    this.#renderEntries();
  }

  #setSelection(entryId, selected) {
    if (selected) this.#state.selectedIds.add(entryId);
    else this.#state.selectedIds.delete(entryId);
    const card = this.#shell()?.querySelector(`[data-global-entry-id="${cssEscape(entryId)}"]`);
    card?.classList.toggle("is-selected", selected);
    const checkbox = card?.querySelector("[data-role='global-selection']");
    if (checkbox) checkbox.checked = selected;
    this.#renderTargetPanel();
  }

  #hydrateThumbnails(container) {
    this.#observer?.disconnect();
    const load = (image) => {
      const source = image.dataset.thumbSource;
      if (!source) return;
      delete image.dataset.thumbSource;
      void this.#thumbnails.get(source).then((thumbnail) => { if (image.isConnected) image.src = thumbnail; });
    };
    if (!globalThis.IntersectionObserver) return container.querySelectorAll("img[data-thumb-source]").forEach(load);
    this.#observer = new IntersectionObserver((entries, observer) => {
      for (const observed of entries) if (observed.isIntersecting) {
        observer.unobserve(observed.target);
        load(observed.target);
      }
    }, { root: container.closest(".aig-global-gallery"), rootMargin: "240px" });
    container.querySelectorAll("img[data-thumb-source]").forEach((image) => this.#observer.observe(image));
  }

  #canManage() {
    return Boolean(globalThis.game?.user?.isGM);
  }

  #shell() {
    return this.element?.querySelector?.(".aig-global-shell") ?? null;
  }

  #handleError(error) {
    warn("Global gallery action failed.", error);
    const key = {
      actorRequired: "errors.actorRequired",
      permissionDenied: "errors.permissionDenied",
      globalPermissionDenied: "errors.globalPermissionDenied",
      globalSelectionRequired: "errors.globalSelectionRequired",
      globalEntryNotFound: "errors.globalEntryNotFound",
      sourceRequired: "errors.sourceRequired",
      filePickerUnavailable: "errors.filePickerUnavailable",
      uploadUnavailable: "errors.uploadUnavailable",
      backupInvalid: "errors.backupInvalid",
      backupJsonInvalid: "errors.backupJsonInvalid",
      backupFormatInvalid: "errors.backupFormatInvalid",
      backupVersionUnsupported: "errors.backupVersionUnsupported",
      backupScopeInvalid: "errors.backupScopeInvalid",
      backupPayloadInvalid: "errors.backupPayloadInvalid",
      backupStrategyInvalid: "errors.backupStrategyInvalid",
      backupFileInvalid: "errors.backupFileInvalid",
      backupFileTooLarge: "errors.backupFileTooLarge",
      backupDownloadUnavailable: "errors.backupDownloadUnavailable",
      backupUnavailable: "errors.backupUnavailable"
    }[error?.code] ?? "errors.actionFailed";
    notify("error", key);
  }
}

function globalBackupPanelHtml(canManage) {
  return `<section class="aig-backup-panel aig-global-backup-panel" data-role="global-backup-panel" hidden>
    <header><div><span class="aig-kicker">${escapeHtml(localize("backup.kicker"))}</span><h2>${escapeHtml(localize("backup.globalTitle"))}</h2></div><button type="button" class="aig-icon-button" data-action="global-backup-close" title="${escapeAttribute(localize("common.close"))}"><i class="fa-solid fa-xmark"></i></button></header>
    <p>${escapeHtml(localize("backup.metadataOnlyHint"))}</p>
    <div class="aig-backup-panel__grid">
      <button type="button" class="aig-button" data-action="backup-export-global"><i class="fa-solid fa-file-export"></i><span>${escapeHtml(localize("backup.exportGlobal"))}</span></button>
      <button type="button" class="aig-button" data-action="backup-export-world" ${disabledIf(!canManage)}><i class="fa-solid fa-earth-americas"></i><span>${escapeHtml(localize("backup.exportWorld"))}</span></button>
    </div>
    <label class="aig-field"><span>${escapeHtml(localize("backup.conflictStrategy"))}</span><select data-role="global-backup-strategy">${importStrategyOptions()}</select></label>
    <div class="aig-backup-panel__grid">
      <button type="button" class="aig-button aig-button--signal" data-action="backup-import-global" ${disabledIf(!canManage)}><i class="fa-solid fa-file-import"></i><span>${escapeHtml(localize("backup.importGlobal"))}</span></button>
      <button type="button" class="aig-button aig-button--signal" data-action="backup-import-world" ${disabledIf(!canManage)}><i class="fa-solid fa-globe"></i><span>${escapeHtml(localize("backup.importWorld"))}</span></button>
    </div>
    <p class="aig-backup-panel__safety"><i class="fa-solid fa-shield-halved"></i>${escapeHtml(localize("backup.nonDestructiveHint"))}</p>
  </section>`;
}

function availableActors() {
  const collection = globalThis.game?.actors;
  const actors = collection?.contents ?? Array.from(collection?.values?.() ?? []);
  return actors
    .filter((actor) => actorCanUpdate(actor))
    .sort((left, right) => left.name.localeCompare(right.name, undefined, { sensitivity: "base" }));
}

function actorOptions(actors, selected) {
  if (!actors.length) return `<option value="">${escapeHtml(localize("global.noActors"))}</option>`;
  return actors.map((actor) => `<option value="${escapeAttribute(actor.id)}" ${actor.id === selected ? "selected" : ""}>${escapeHtml(actor.name)}</option>`).join("");
}

function categoryOptions(gallery, selected) {
  return [
    `<option value="">${escapeHtml(localize("common.all"))}</option>`,
    ...getGlobalCategories(gallery).map((category) => `<option value="${escapeAttribute(category)}" ${category === selected ? "selected" : ""}>${escapeHtml(category)}</option>`)
  ].join("");
}

function sortOptions(selected) {
  return [SORT_MODES.MANUAL, SORT_MODES.NAME, SORT_MODES.RECENT, SORT_MODES.FAVORITES]
    .map((mode) => `<option value="${mode}" ${mode === selected ? "selected" : ""}>${escapeHtml(localize(`sort.${mode}`))}</option>`)
    .join("");
}

function disabledIf(value) {
  return value ? "disabled aria-disabled=\"true\"" : "";
}

function cssEscape(value) {
  return globalThis.CSS?.escape?.(String(value)) ?? String(value).replace(/["\\]/g, "\\$&");
}

function getSetting(key, fallback) {
  try {
    return globalThis.game?.settings?.get?.(MODULE_ID, key) ?? fallback;
  } catch {
    return fallback;
  }
}

async function uploadGlobalFile(file) {
  const FilePicker = getFilePickerClass();
  if (!FilePicker) throw Object.assign(new Error("uploadUnavailable"), { code: "uploadUnavailable" });
  const filename = slugifyFilename(file.name);
  let response;
  if (typeof FilePicker.uploadPersistent === "function") {
    response = await FilePicker.uploadPersistent(MODULE_ID, `global/${filename}`, file, {}, { notify: true });
  } else if (typeof FilePicker.upload === "function") {
    response = await FilePicker.upload("data", `${MODULE_ID}/global`, file, {}, { notify: true });
  } else throw Object.assign(new Error("uploadUnavailable"), { code: "uploadUnavailable" });
  const source = response?.path ?? response?.src ?? response?.url;
  if (!source) throw Object.assign(new Error("uploadUnavailable"), { code: "uploadUnavailable" });
  return source;
}

import { APPLY_TARGETS, EXTENSION_API_VERSION, PUBLIC_API_VERSION } from "./constants.mjs";

export function createPublicApi(runtime) {
  const api = {
    apiVersion: PUBLIC_API_VERSION,
    extensionApiVersion: EXTENSION_API_VERSION,

    getActorGallery: (actorOrUuid) => runtime.getGallery(actorOrUuid),
    getGlobalGallery: () => runtime.getGlobalGallery(),
    openActorGallery: (actorOrUuid, options = {}) => runtime.openGallery(actorOrUuid, options),
    openGlobalGallery: (options = {}) => runtime.openGlobalGallery(options),
    addGlobalEntryToActor: (entryIds, actorOrUuid) => runtime.addGlobalEntryToActor(entryIds, actorOrUuid),
    openQuickGallery: (actorOrToken, options = {}) => runtime.openQuickSwitch(actorOrToken, options),
    applyGalleryEntry: (actorOrToken, entryId, target, options = {}) => runtime.apply(actorOrToken, entryId, target, options),
    applyTemporaryAppearance: (actorOrToken, entryId, options = {}) => runtime.applyTemporary(actorOrToken, entryId, options),
    revertTemporaryAppearance: (actorOrToken) => runtime.revertTemporary(actorOrToken),
    exportActorMetadata: (actorOrUuid) => runtime.exportActorMetadata(actorOrUuid),
    exportGlobalMetadata: () => runtime.exportGlobalMetadata(),
    exportWorldMetadata: () => runtime.exportWorldMetadata(),
    importActorMetadata: (actorOrUuid, envelope, options = {}) => runtime.importActorMetadata(actorOrUuid, envelope, options),
    importGlobalMetadata: (envelope, options = {}) => runtime.importGlobalMetadata(envelope, options),
    importWorldMetadata: (envelope, options = {}) => runtime.importWorldMetadata(envelope, options),
    previousGalleryEntry: () => runtime.applyPrevious(),

    hasCapability: (capability) => runtime.hasCapability(capability),
    getCapabilities: () => runtime.getCapabilities(),
    getEntitlementStatus: () => runtime.getEntitlementStatus(),
    registerExtension: (descriptor) => runtime.registerExtension(descriptor),
    getExtensions: () => runtime.getExtensions(),

    // Backwards-compatible aliases shipped before API versioning.
    open: (actorOrUuid, options = {}) => runtime.openGallery(actorOrUuid, options),
    openQuickSwitch: (actorOrToken, options = {}) => runtime.openQuickSwitch(actorOrToken, options),
    apply: (actorOrToken, entryId, target, options = {}) => runtime.apply(actorOrToken, entryId, target, options),
    previous: () => runtime.applyPrevious(),
    quickSlot: (slot) => runtime.applyQuickSlot(slot),
    getGallery: (actorOrUuid) => runtime.getGallery(actorOrUuid),

    targets: APPLY_TARGETS,
    edition: "free"
  };
  return Object.freeze(api);
}

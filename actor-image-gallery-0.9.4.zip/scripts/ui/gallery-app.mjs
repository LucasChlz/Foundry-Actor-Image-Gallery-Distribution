import { APPLY_TARGETS, CAPABILITIES, IMAGE_FITS, MODULE_ID, PRESET_KINDS, SEQUENCE_MODES, SORT_MODES } from "../constants.mjs";
import {
  addEntry,
  createEntry,
  createPreset,
  duplicateEntry,
  getCollections,
  getTags,
  mergeVisibleEntryOrder,
  presetCss,
  queryEntries,
  removeEntry,
  reorderEntryIds,
  reorderEntries,
  setDefault,
  toggleFavorite,
  updateEntry
} from "../domain/gallery.mjs";
import { droppedImageFiles, extractDroppedSource } from "../domain/drop.mjs";
import { ApplicationV2Class, getFilePickerClass } from "../foundry/compatibility.mjs";
import { ThumbnailService } from "../foundry/image-application.mjs";
import { applyPalette, DEFAULT_PALETTE, normalizePalette, PALETTE_FIELDS, serializePalette } from "../palette.mjs";
import { downloadBackup, importStrategyLabel, importStrategyOptions, readBackupFile } from "./backup-ui.mjs";
import {
  actorCanUpdate,
  clamp,
  confirmAction,
  deepClone,
  escapeAttribute,
  escapeHtml,
  getActiveTokenForActor,
  localize,
  notify,
  slugifyFilename,
  sourceName,
  warn
} from "../utils.mjs";

const ENTRY_DRAG_TYPE = "application/x-actor-image-gallery-entry";

export class ActorGalleryApplication extends ApplicationV2Class {
  static DEFAULT_OPTIONS = {
    id: "actor-image-gallery",
    classes: ["actor-image-gallery-window"],
    tag: "section",
    window: {
      frame: true,
      positioned: true,
      minimizable: true,
      resizable: true,
      icon: "fa-solid fa-images"
    },
    position: {
      width: 1180,
      height: 760
    }
  };

  #actor;
  #token;
  #repository;
  #applicator;
  #preloader;
  #thumbnails;
  #temporaryService;
  #backupService;
  #profileService;
  #sequenceService;
  #hasCapability;
  #gallery;
  #state;
  #editing = null;
  #editingKind = PRESET_KINDS.PORTRAIT;
  #pointerState = null;
  #panelResize = null;
  #cardDrag = null;
  #suppressCardClick = false;
  #touches = new Map();
  #observer = null;
  #openGlobalGallery;
  #openAutomationManager;
  #profileEditingId = null;
  #sequenceEditing = null;

  constructor({ actor, token = null, repository, applicator, preloader, thumbnails = new ThumbnailService(), temporaryService = null, backupService = null, profileService = null, sequenceService = null, hasCapability = () => false, openGlobalGallery = null, openAutomationManager = null }) {
    super({ id: `${MODULE_ID}-${actor.id}` });
    this.#actor = actor;
    this.#token = token;
    this.#repository = repository;
    this.#applicator = applicator;
    this.#preloader = preloader;
    this.#thumbnails = thumbnails;
    this.#temporaryService = temporaryService;
    this.#backupService = backupService;
    this.#profileService = profileService;
    this.#sequenceService = sequenceService;
    this.#hasCapability = hasCapability;
    this.#openGlobalGallery = openGlobalGallery;
    this.#openAutomationManager = openAutomationManager;
    this.#gallery = repository.read(actor);
    this.#state = {
      query: "",
      tag: "",
      collection: "",
      favoritesOnly: false,
      selectedId: this.#gallery.entries[0]?.id ?? null,
      view: getSetting("galleryView", "grid"),
      sort: getSetting("gallerySort", SORT_MODES.MANUAL),
      applyTarget: getSetting("defaultApplyTarget", APPLY_TARGETS.PORTRAIT_CURRENT),
      sidebarWidth: clamp(getSetting("sidebarWidth", 168), 120, 360),
      inspectorWidth: clamp(getSetting("inspectorWidth", 312), 260, 720),
      inspectorSide: getSetting("inspectorSide", "right") === "left" ? "left" : "right",
      editorExpanded: false
    };
  }

  get title() {
    return localize("gallery.title", { name: this.#actor.name });
  }

  get actor() {
    return this.#actor;
  }

  async refresh() {
    this.#gallery = this.#repository.read(this.#actor);
    if (this.#state.selectedId && !this.#gallery.entries.some((entry) => entry.id === this.#state.selectedId)) {
      this.#state.selectedId = this.#gallery.entries[0]?.id ?? null;
      this.#editing = null;
    }
    if (this.rendered) await this.render({ force: true });
  }

  async _renderHTML() {
    const root = document.createElement("div");
    root.className = "aig-shell";
    root.dataset.view = this.#state.view;
    root.dataset.reducedMotion = String(Boolean(getSetting("reducedMotion", false)));
    root.dataset.inspectorSide = this.#state.inspectorSide;
    applyPalette(root, getSetting("customPalette", DEFAULT_PALETTE));
    root.classList.toggle("is-editor-expanded", this.#state.editorExpanded);
    root.style.setProperty("--aig-sidebar-width", `${this.#state.sidebarWidth}px`);
    root.style.setProperty("--aig-inspector-width", `${this.#state.inspectorWidth}px`);
    root.innerHTML = `
      <header class="aig-hero">
        <div class="aig-hero__portrait"><img src="${escapeAttribute(this.#actor.img)}" alt=""></div>
        <div class="aig-hero__copy">
          <span class="aig-kicker">${escapeHtml(localize("gallery.kicker"))}</span>
          <h1>${escapeHtml(this.#actor.name)}</h1>
          <p data-role="gallery-count"></p>
        </div>
        <div class="aig-hero__actions">
          <button type="button" class="aig-button" data-action="backup-open" title="${escapeAttribute(localize("backup.openHint"))}">
            <i class="fa-solid fa-box-archive" aria-hidden="true"></i><span>${escapeHtml(localize("backup.open"))}</span>
          </button>
          <button type="button" class="aig-button ${this.#profilesAvailable() ? "" : "is-locked"}" data-action="profiles-open" title="${escapeAttribute(localize(this.#profilesAvailable() ? "profiles.openHint" : "profiles.lockedHint"))}">
            <i class="fa-solid ${this.#profilesAvailable() ? "fa-masks-theater" : "fa-lock"}" aria-hidden="true"></i><span>${escapeHtml(localize("profiles.open"))}</span><b class="aig-pro-badge">PATREON</b>
          </button>
          <button type="button" class="aig-button ${this.#sequencesAvailable() ? "" : "is-locked"}" data-action="sequences-open" title="${escapeAttribute(localize(this.#sequencesAvailable() ? "sequences.openHint" : "sequences.lockedHint"))}">
            <i class="fa-solid ${this.#sequencesAvailable() ? "fa-list-ol" : "fa-lock"}" aria-hidden="true"></i><span>${escapeHtml(localize("sequences.open"))}</span><b class="aig-pro-badge">PATREON</b>
          </button>
          <button type="button" class="aig-button ${this.#automationAvailable() ? "" : "is-locked"}" data-action="automation-open" title="${escapeAttribute(localize(this.#automationAvailable() ? "automation.openHint" : "automation.lockedHint"))}">
            <i class="fa-solid ${this.#automationAvailable() ? "fa-wand-magic-sparkles" : "fa-lock"}" aria-hidden="true"></i><span>${escapeHtml(localize("automation.open"))}</span><b class="aig-pro-badge">PATREON</b>
          </button>
          <button type="button" class="aig-button" data-action="open-global-gallery" title="${escapeAttribute(localize("global.openHint"))}">
            <i class="fa-solid fa-earth-americas" aria-hidden="true"></i><span>${escapeHtml(localize("global.open"))}</span>
          </button>
          <button type="button" class="aig-button" data-action="palette-open" title="${escapeAttribute(localize("palette.openHint"))}">
            <i class="fa-solid fa-palette" aria-hidden="true"></i><span>${escapeHtml(localize("palette.open"))}</span>
          </button>
          <button type="button" class="aig-button aig-button--signal" data-action="new-entry" ${disabledIf(!this.#canEdit())}>
            <i class="fa-solid fa-plus" aria-hidden="true"></i><span>${escapeHtml(localize("actions.add"))}</span>
          </button>
        </div>
      </header>
      <section class="aig-toolbar" aria-label="${escapeAttribute(localize("gallery.tools"))}">
        <label class="aig-search">
          <i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i>
          <span class="sr-only">${escapeHtml(localize("actions.search"))}</span>
          <input type="search" data-role="search" value="${escapeAttribute(this.#state.query)}" placeholder="${escapeAttribute(localize("gallery.searchPlaceholder"))}">
        </label>
        <label class="aig-token-guard" title="${escapeAttribute(localize("gallery.ignoreTokenHint"))}">
          <input type="checkbox" data-role="ignore-token-changes" ${this.#gallery.ignoreTokenChanges ? "checked" : ""} ${disabledIf(!this.#canEdit())}>
          <i class="fa-solid fa-shield-halved" aria-hidden="true"></i><span>${escapeHtml(localize("gallery.ignoreToken"))}</span>
        </label>
        <button type="button" class="aig-icon-button ${this.#state.favoritesOnly ? "is-active" : ""}" data-action="toggle-favorites" title="${escapeAttribute(localize("actions.favoritesOnly"))}" aria-pressed="${this.#state.favoritesOnly}">
          <i class="fa-solid fa-star" aria-hidden="true"></i><span class="sr-only">${escapeHtml(localize("actions.favoritesOnly"))}</span>
        </button>
        <label class="aig-select-label"><span>${escapeHtml(localize("actions.sort"))}</span>
          <select data-role="sort">${sortOptions(this.#state.sort)}</select>
        </label>
        <div class="aig-view-toggle" role="group" aria-label="${escapeAttribute(localize("actions.view"))}">
          <button type="button" data-action="view-grid" class="aig-icon-button ${this.#state.view === "grid" ? "is-active" : ""}" title="${escapeAttribute(localize("actions.grid"))}" aria-pressed="${this.#state.view === "grid"}"><i class="fa-solid fa-grid-2" aria-hidden="true"></i></button>
          <button type="button" data-action="view-list" class="aig-icon-button ${this.#state.view === "list" ? "is-active" : ""}" title="${escapeAttribute(localize("actions.list"))}" aria-pressed="${this.#state.view === "list"}"><i class="fa-solid fa-list" aria-hidden="true"></i></button>
        </div>
      </section>
      <section class="aig-temporary-state" data-role="temporary-state" hidden></section>
      <section class="aig-profile-state" data-role="profile-state" hidden></section>
      <section class="aig-sequence-state" data-role="sequence-state" hidden></section>
      <section class="aig-automation-state" data-role="automation-state" hidden></section>
      <div class="aig-tags" data-role="tags" aria-label="${escapeAttribute(localize("entry.tags"))}"></div>
      ${paletteEditorHtml(getSetting("customPalette", DEFAULT_PALETTE))}
      ${backupPanelHtml(this.#canEdit())}
      <section class="aig-profiles-panel" data-role="profiles-panel" hidden></section>
      <section class="aig-sequences-panel" data-role="sequences-panel" hidden></section>
      <div class="aig-workspace">
        <aside class="aig-sidebar">
          <section>
            <h2>${escapeHtml(localize("entry.collections"))}</h2>
            <nav data-role="collections"></nav>
          </section>
          <section class="aig-history">
            <h2>${escapeHtml(localize("gallery.recent"))}</h2>
            <ol data-role="history"></ol>
          </section>
          <p class="aig-sidebar__tip"><i class="fa-solid fa-computer-mouse" aria-hidden="true"></i>${escapeHtml(localize("gallery.dragTip"))}</p>
        </aside>
        <div class="aig-resizer aig-resizer--sidebar" data-resize-panel="sidebar" role="separator" tabindex="0" aria-orientation="vertical" aria-label="${escapeAttribute(localize("layout.resizeSidebar"))}" aria-valuemin="120" aria-valuemax="360" aria-valuenow="${Math.round(this.#state.sidebarWidth)}"><span aria-hidden="true"></span></div>
        <main class="aig-gallery" data-role="drop-zone">
          <div class="aig-gallery__empty" data-role="empty" hidden></div>
          <div class="aig-items" data-role="items" role="list"></div>
          <div class="aig-drop-overlay" aria-hidden="true"><i class="fa-solid fa-cloud-arrow-up"></i><span>${escapeHtml(localize("gallery.dropImages"))}</span></div>
        </main>
        <div class="aig-resizer aig-resizer--inspector" data-resize-panel="inspector" role="separator" tabindex="0" aria-orientation="vertical" aria-label="${escapeAttribute(localize("layout.resizeInspector"))}" aria-valuemin="260" aria-valuemax="720" aria-valuenow="${Math.round(this.#state.inspectorWidth)}"><span aria-hidden="true"></span></div>
        <aside class="aig-inspector" data-role="inspector"></aside>
      </div>
      <input type="file" accept="image/*" multiple data-role="local-files" hidden>
      <input type="file" accept="application/json,.json" data-role="backup-file" hidden>
    `;
    return root;
  }

  _replaceHTML(result, content) {
    content.replaceChildren(result);
  }

  async _onRender(context, options) {
    await super._onRender(context, options);
    const shell = this.#shell();
    if (!shell) return;
    shell.addEventListener("click", (event) => void this.#onClick(event));
    shell.addEventListener("input", (event) => this.#onInput(event));
    shell.addEventListener("change", (event) => void this.#onChange(event).catch((error) => this.#handleError(error)));
    shell.addEventListener("dblclick", (event) => void this.#onDoubleClick(event).catch((error) => this.#handleError(error)));
    shell.addEventListener("keydown", (event) => void this.#onKeyDown(event));
    shell.addEventListener("wheel", (event) => this.#onWheel(event), { passive: false });
    shell.addEventListener("pointerdown", (event) => this.#onPointerDown(event));
    shell.addEventListener("pointermove", (event) => this.#onPointerMove(event));
    shell.addEventListener("pointerup", (event) => this.#onPointerUp(event));
    shell.addEventListener("pointercancel", (event) => this.#onPointerUp(event));
    shell.addEventListener("dragstart", (event) => this.#onCardDragStart(event));
    shell.addEventListener("dragend", () => this.#onCardDragEnd());
    shell.addEventListener("dragover", (event) => this.#onDragOver(event), true);
    shell.addEventListener("dragleave", (event) => this.#onDragLeave(event));
    shell.addEventListener("drop", (event) => void this.#onDrop(event).catch((error) => this.#handleError(error)), true);
    this.#applyPanelLayout();
    this.#renderAll();
    if (getSetting("preloadFavorites", true)) {
      void this.#preloader.preload(this.#gallery.entries, { favoritesOnly: true });
    }
  }

  async _onClose(options) {
    this.#observer?.disconnect();
    this.#stopPointerGesture();
    this.#panelResize = null;
    this.#cardDrag = null;
    await super._onClose(options);
  }

  #renderAll() {
    this.#renderTemporaryState();
    this.#renderProfileState();
    this.#renderSequenceState();
    this.#renderAutomationState();
    this.#renderProfilesPanel();
    this.#renderSequencesPanel();
    this.#renderFacets();
    this.#renderEntries();
    this.#renderHistory();
    this.#renderInspector();
  }

  #renderSequenceState() {
    const target = this.#shell()?.querySelector("[data-role='sequence-state']");
    if (!target) return;
    const sequence = this.#gallery.sequences.find((candidate) => candidate.id === this.#gallery.activeSequenceId);
    const state = sequence ? this.#gallery.sequenceState?.[sequence.id] : null;
    const step = state ? sequence?.steps[state.index] : null;
    target.hidden = !sequence;
    if (!sequence) {
      target.replaceChildren();
      return;
    }
    const label = sequenceStepLabel(step, this.#gallery) || localize("sequences.notStarted");
    const progress = state ? `${state.index + 1}/${sequence.steps.length}` : `0/${sequence.steps.length}`;
    target.innerHTML = `<div><i class="fa-solid fa-list-ol"></i><span><strong>${escapeHtml(sequence.name)}</strong><b>${escapeHtml(progress)}</b>${escapeHtml(label)}</span></div>${this.#sequencesAvailable() ? `<nav><button type="button" class="aig-icon-button" data-action="sequence-previous" data-sequence-id="${escapeAttribute(sequence.id)}" title="${escapeAttribute(localize("sequences.previous"))}"><i class="fa-solid fa-chevron-left"></i></button><button type="button" class="aig-icon-button" data-action="sequence-reset" data-sequence-id="${escapeAttribute(sequence.id)}" title="${escapeAttribute(localize("sequences.reset"))}"><i class="fa-solid fa-rotate-left"></i></button><button type="button" class="aig-icon-button" data-action="sequence-next" data-sequence-id="${escapeAttribute(sequence.id)}" title="${escapeAttribute(localize("sequences.next"))}"><i class="fa-solid fa-chevron-right"></i></button><button type="button" class="aig-button" data-action="sequences-open">${escapeHtml(localize("sequences.manage"))}</button></nav>` : `<span class="aig-profile-state__locked"><i class="fa-solid fa-lock"></i>${escapeHtml(localize("sequences.preservedLocked"))}</span>`}`;
  }

  #renderAutomationState() {
    const target = this.#shell()?.querySelector("[data-role='automation-state']");
    if (!target) return;
    const state = this.#gallery.automationState;
    const rule = this.#gallery.automationRules.find((candidate) => candidate.id === state?.lastAppliedRuleId);
    const override = state?.manualOverride;
    target.hidden = !rule && !override;
    if (!rule && !override) {
      target.replaceChildren();
      return;
    }
    const icon = override ? "fa-hand" : "fa-wand-magic-sparkles";
    const heading = override ? localize("automation.overrideActive") : localize("automation.winningRule");
    const detail = override ? localize(`automation.overrideDurations.${override.duration}`) : rule?.name ?? localize("automation.noWinner");
    target.innerHTML = `<div><i class="fa-solid ${icon}"></i><span><strong>${escapeHtml(heading)}</strong>${escapeHtml(detail)}</span></div><button type="button" class="aig-button" data-action="automation-open">${escapeHtml(localize("automation.whyTitle"))}</button>`;
  }

  #renderSequencesPanel() {
    const panel = this.#shell()?.querySelector("[data-role='sequences-panel']");
    if (!panel || panel.hidden) return;
    if (!this.#sequencesAvailable()) {
      panel.innerHTML = sequencePanelHeader() + `<div class="aig-profiles-panel__locked"><i class="fa-solid fa-lock"></i><h3>${escapeHtml(localize("sequences.lockedTitle"))}</h3><p>${escapeHtml(localize("sequences.preservedLocked"))}</p></div>`;
      return;
    }
    panel.innerHTML = `${sequencePanelHeader()}
      <div class="aig-sequences-layout">
        <div class="aig-sequences-list">
          <div class="aig-profiles-list__heading"><p>${escapeHtml(localize("sequences.hint"))}</p><button type="button" class="aig-button aig-button--signal" data-action="sequence-new" ${disabledIf(!this.#canEdit())}><i class="fa-solid fa-plus"></i>${escapeHtml(localize("sequences.new"))}</button></div>
          ${this.#gallery.sequences.length ? this.#gallery.sequences.map((sequence, index) => this.#sequenceCardHtml(sequence, index)).join("") : `<div class="aig-profiles-empty"><i class="fa-solid fa-list-ol"></i><span>${escapeHtml(localize("sequences.empty"))}</span></div>`}
        </div>
        <div class="aig-sequence-editor">${this.#sequenceEditing ? this.#sequenceEditorHtml(this.#sequenceEditing) : `<div class="aig-profiles-empty"><i class="fa-solid fa-arrow-left"></i><span>${escapeHtml(localize("sequences.selectHint"))}</span></div>`}</div>
      </div>`;
  }

  #sequenceCardHtml(sequence, index) {
    const state = this.#gallery.sequenceState?.[sequence.id];
    const active = sequence.id === this.#gallery.activeSequenceId;
    const label = state ? sequenceStepLabel(sequence.steps[state.index], this.#gallery) : localize("sequences.notStarted");
    return `<article class="aig-sequence-card ${active ? "is-active" : ""}">
      <div><strong>${escapeHtml(sequence.name)}</strong><span>${escapeHtml(localize(`sequences.modes.${sequence.mode}`))} · ${escapeHtml(localize("sequences.stepCount", { count: sequence.steps.length }))}</span><b>${escapeHtml(state ? `${state.index + 1}/${sequence.steps.length} · ${label}` : label)}</b></div>
      <nav><button type="button" class="aig-icon-button" data-action="sequence-order-up" data-sequence-id="${escapeAttribute(sequence.id)}" title="${escapeAttribute(localize("sequences.moveUp"))}" ${disabledIf(index === 0 || !this.#canEdit())}><i class="fa-solid fa-arrow-up"></i></button><button type="button" class="aig-icon-button" data-action="sequence-order-down" data-sequence-id="${escapeAttribute(sequence.id)}" title="${escapeAttribute(localize("sequences.moveDown"))}" ${disabledIf(index === this.#gallery.sequences.length - 1 || !this.#canEdit())}><i class="fa-solid fa-arrow-down"></i></button><button type="button" class="aig-icon-button" data-action="sequence-previous" data-sequence-id="${escapeAttribute(sequence.id)}" title="${escapeAttribute(localize("sequences.previous"))}"><i class="fa-solid fa-chevron-left"></i></button><button type="button" class="aig-icon-button" data-action="sequence-reset" data-sequence-id="${escapeAttribute(sequence.id)}" title="${escapeAttribute(localize("sequences.reset"))}"><i class="fa-solid fa-rotate-left"></i></button><button type="button" class="aig-icon-button" data-action="sequence-next" data-sequence-id="${escapeAttribute(sequence.id)}" title="${escapeAttribute(localize("sequences.next"))}"><i class="fa-solid fa-chevron-right"></i></button><button type="button" class="aig-icon-button" data-action="sequence-edit" data-sequence-id="${escapeAttribute(sequence.id)}" title="${escapeAttribute(localize("actions.edit"))}"><i class="fa-solid fa-pen"></i></button><button type="button" class="aig-icon-button" data-action="sequence-duplicate" data-sequence-id="${escapeAttribute(sequence.id)}" title="${escapeAttribute(localize("actions.duplicate"))}"><i class="fa-solid fa-copy"></i></button><button type="button" class="aig-icon-button" data-action="sequence-remove" data-sequence-id="${escapeAttribute(sequence.id)}" title="${escapeAttribute(localize("actions.remove"))}"><i class="fa-solid fa-trash"></i></button></nav>
    </article>`;
  }

  #sequenceEditorHtml(sequence) {
    return `<form data-role="sequence-form">
      <span class="aig-kicker">${escapeHtml(localize("sequences.editorKicker"))}</span><h2>${escapeHtml(sequence.__new ? localize("sequences.newTitle") : localize("sequences.editTitle"))}</h2>
      <div class="aig-form-grid"><label class="aig-field"><span>${escapeHtml(localize("entry.name"))}</span><input name="name" value="${escapeAttribute(sequence.name)}" required></label><label class="aig-field"><span>${escapeHtml(localize("sequences.mode"))}</span><select name="mode">${sequenceModeOptions(sequence.mode)}</select></label><label class="aig-field aig-field--wide"><span>${escapeHtml(localize("entry.description"))}</span><textarea name="description">${escapeHtml(sequence.description)}</textarea></label></div>
      <section class="aig-sequence-steps"><header><div><span class="aig-kicker">${escapeHtml(localize("sequences.steps"))}</span><strong>${escapeHtml(localize("sequences.stepCount", { count: sequence.steps.length }))}</strong></div><button type="button" class="aig-button" data-action="sequence-step-add"><i class="fa-solid fa-plus"></i>${escapeHtml(localize("sequences.addStep"))}</button></header>${sequence.steps.map((step, index) => this.#sequenceStepHtml(step, index, sequence.steps.length)).join("")}</section>
      <footer><button type="button" class="aig-button" data-action="sequence-cancel">${escapeHtml(localize("common.cancel"))}</button><button type="button" class="aig-button aig-button--signal" data-action="sequence-save"><i class="fa-solid fa-floppy-disk"></i>${escapeHtml(localize("common.save"))}</button></footer>
    </form>`;
  }

  #sequenceStepHtml(step, index, count) {
    return `<div class="aig-sequence-step" data-step-index="${index}"><b>${index + 1}</b><label class="aig-field"><span>${escapeHtml(localize("sequences.stepLabel"))}</span><input data-sequence-field="label" value="${escapeAttribute(step.label)}"></label><label class="aig-field"><span>${escapeHtml(localize("sequences.targetType"))}</span><select data-sequence-field="targetType" data-role="sequence-step-type"><option value="entry" ${step.targetType === "entry" ? "selected" : ""}>${escapeHtml(localize("sequences.entry"))}</option><option value="profile" ${step.targetType === "profile" ? "selected" : ""}>${escapeHtml(localize("sequences.profile"))}</option></select></label><label class="aig-field"><span>${escapeHtml(localize("sequences.target"))}</span><select data-sequence-field="targetId">${sequenceTargetOptions(step, this.#gallery)}</select></label><nav><button type="button" class="aig-icon-button" data-action="sequence-step-up" data-step-index="${index}" ${disabledIf(index === 0)}><i class="fa-solid fa-arrow-up"></i></button><button type="button" class="aig-icon-button" data-action="sequence-step-down" data-step-index="${index}" ${disabledIf(index === count - 1)}><i class="fa-solid fa-arrow-down"></i></button><button type="button" class="aig-icon-button" data-action="sequence-step-remove" data-step-index="${index}"><i class="fa-solid fa-trash"></i></button></nav></div>`;
  }

  #renderProfileState() {
    const target = this.#shell()?.querySelector("[data-role='profile-state']");
    if (!target) return;
    const profile = this.#gallery.profiles.find((candidate) => candidate.id === this.#gallery.activeProfileId);
    target.hidden = !profile;
    if (!profile) {
      target.replaceChildren();
      return;
    }
    target.innerHTML = `<div><i class="fa-solid fa-masks-theater" aria-hidden="true"></i><span><strong>${escapeHtml(localize("profiles.active"))}</strong>${escapeHtml(profile.name)}</span></div>${this.#profilesAvailable() ? `<button type="button" class="aig-button" data-action="profiles-open">${escapeHtml(localize("profiles.manage"))}</button>` : `<span class="aig-profile-state__locked"><i class="fa-solid fa-lock"></i>${escapeHtml(localize("profiles.preservedLocked"))}</span>`}`;
  }

  #renderProfilesPanel() {
    const panel = this.#shell()?.querySelector("[data-role='profiles-panel']");
    if (!panel || panel.hidden) return;
    if (!this.#profilesAvailable()) {
      panel.innerHTML = profilePanelHeader() + `<div class="aig-profiles-panel__locked"><i class="fa-solid fa-lock"></i><h3>${escapeHtml(localize("profiles.lockedTitle"))}</h3><p>${escapeHtml(localize("profiles.preservedLocked"))}</p></div>`;
      return;
    }
    const editing = this.#profileEditingId === "__new"
      ? { name: "", description: "", tags: [], category: "", portrait: null, token: null, prototypeToken: true, sceneTokens: false, tokenVisual: {} }
      : this.#gallery.profiles.find((profile) => profile.id === this.#profileEditingId) ?? null;
    panel.innerHTML = `${profilePanelHeader()}
      <div class="aig-profiles-layout">
        <div class="aig-profiles-list">
          <div class="aig-profiles-list__heading"><p>${escapeHtml(localize("profiles.hint"))}</p><button type="button" class="aig-button aig-button--signal" data-action="profile-new" ${disabledIf(!this.#canEdit())}><i class="fa-solid fa-plus"></i>${escapeHtml(localize("profiles.new"))}</button></div>
          ${this.#gallery.profiles.length ? this.#gallery.profiles.map((profile) => this.#profileCardHtml(profile)).join("") : `<div class="aig-profiles-empty"><i class="fa-regular fa-masks-theater"></i><span>${escapeHtml(localize("profiles.empty"))}</span></div>`}
        </div>
        <div class="aig-profile-editor">${editing ? this.#profileEditorHtml(editing) : `<div class="aig-profiles-empty"><i class="fa-solid fa-arrow-left"></i><span>${escapeHtml(localize("profiles.selectHint"))}</span></div>`}</div>
      </div>`;
  }

  #profileCardHtml(profile) {
    const active = profile.id === this.#gallery.activeProfileId;
    const image = profileThumbnail(profile, this.#gallery.entries);
    return `<article class="aig-profile-card ${active ? "is-active" : ""}">
      ${image ? `<img src="${escapeAttribute(image)}" alt="">` : `<span class="aig-profile-card__placeholder"><i class="fa-solid fa-masks-theater"></i></span>`}
      <div><strong>${escapeHtml(profile.name)}</strong><span>${escapeHtml(profile.category || localize("profiles.uncategorized"))}</span>${active ? `<b><i class="fa-solid fa-check"></i>${escapeHtml(localize("profiles.active"))}</b>` : ""}</div>
      <div class="aig-profile-card__actions"><button type="button" class="aig-icon-button" data-action="profile-apply" data-profile-id="${escapeAttribute(profile.id)}" title="${escapeAttribute(localize("profiles.apply"))}" ${disabledIf(!this.#canEdit())}><i class="fa-solid fa-wand-magic-sparkles"></i></button><button type="button" class="aig-icon-button" data-action="profile-edit" data-profile-id="${escapeAttribute(profile.id)}" title="${escapeAttribute(localize("actions.edit"))}" ${disabledIf(!this.#canEdit())}><i class="fa-solid fa-pen"></i></button><button type="button" class="aig-icon-button" data-action="profile-remove" data-profile-id="${escapeAttribute(profile.id)}" title="${escapeAttribute(localize("actions.remove"))}" ${disabledIf(!this.#canEdit())}><i class="fa-solid fa-trash"></i></button></div>
    </article>`;
  }

  #profileEditorHtml(profile) {
    const visual = profile.tokenVisual ?? {};
    return `<form data-role="profile-form" data-profile-id="${escapeAttribute(profile.id ?? "")}">
      <span class="aig-kicker">${escapeHtml(localize("profiles.editorKicker"))}</span><h2>${escapeHtml(profile.id ? localize("profiles.editTitle") : localize("profiles.newTitle"))}</h2>
      <div class="aig-form-grid">
        <label class="aig-field"><span>${escapeHtml(localize("entry.name"))}</span><input name="name" value="${escapeAttribute(profile.name)}" required></label>
        <label class="aig-field"><span>${escapeHtml(localize("profiles.category"))}</span><input name="category" value="${escapeAttribute(profile.category)}"></label>
        <label class="aig-field aig-field--wide"><span>${escapeHtml(localize("entry.tags"))}</span><input name="tags" value="${escapeAttribute(profile.tags.join(", "))}"></label>
        <label class="aig-field aig-field--wide"><span>${escapeHtml(localize("entry.description"))}</span><textarea name="description">${escapeHtml(profile.description)}</textarea></label>
        <label class="aig-field"><span>${escapeHtml(localize("profiles.portraitSource"))}</span><select name="portrait">${profileSourceOptions(profile.portrait, this.#gallery.entries, true)}</select></label>
        <label class="aig-field"><span>${escapeHtml(localize("profiles.tokenSource"))}</span><select name="token">${profileSourceOptions(profile.token, this.#gallery.entries, true)}</select></label>
      </div>
      <fieldset class="aig-profile-targets"><legend>${escapeHtml(localize("profiles.tokenTargets"))}</legend><label><input type="checkbox" name="prototypeToken" ${profile.prototypeToken ? "checked" : ""}>${escapeHtml(localize("profiles.prototype"))}</label><label><input type="checkbox" name="sceneTokens" ${profile.sceneTokens ? "checked" : ""}>${escapeHtml(localize("profiles.scene"))}</label></fieldset>
      <fieldset class="aig-profile-visual"><legend>${escapeHtml(localize("profiles.tokenVisual"))}</legend>
        ${profileNumberField("scale", "profiles.scale", visual.scale, 0.1, 4, 0.1)}
        ${profileNumberField("width", "profiles.width", visual.width, 0.1, 20, 0.1)}
        ${profileNumberField("height", "profiles.height", visual.height, 0.1, 20, 0.1)}
        ${profileNumberField("alpha", "profiles.alpha", visual.alpha, 0, 1, 0.05)}
        <label class="aig-field"><span>${escapeHtml(localize("profiles.tint"))}</span><input name="tint" placeholder="#FFFFFF" value="${escapeAttribute(visual.tint ?? "")}"></label>
      </fieldset>
      ${this.#gallery.ignoreTokenChanges ? `<p class="aig-profile-guard"><i class="fa-solid fa-shield-halved"></i>${escapeHtml(localize("profiles.tokenGuardHint"))}</p>` : ""}
      <footer><button type="button" class="aig-button" data-action="profile-cancel">${escapeHtml(localize("common.cancel"))}</button><button type="button" class="aig-button aig-button--signal" data-action="profile-save"><i class="fa-solid fa-floppy-disk"></i>${escapeHtml(localize("common.save"))}</button></footer>
    </form>`;
  }

  #renderTemporaryState() {
    const target = this.#shell()?.querySelector("[data-role='temporary-state']");
    if (!target) return;
    const state = this.#gallery.temporaryState;
    this.#shell()?.classList.toggle("has-temporary", Boolean(state));
    target.hidden = !state;
    if (!state) {
      target.replaceChildren();
      return;
    }
    const entry = this.#gallery.entries.find((candidate) => candidate.id === state.activeEntryId);
    target.innerHTML = `<div><i class="fa-solid fa-hourglass-half" aria-hidden="true"></i><span><strong>${escapeHtml(localize("temporary.active"))}</strong>${escapeHtml(localize("temporary.activeHint", { name: entry?.name ?? localize("entry.untitled") }))}</span></div><button type="button" class="aig-button aig-button--signal" data-action="revert-temporary"><i class="fa-solid fa-clock-rotate-left"></i><span>${escapeHtml(localize("temporary.revert"))}</span></button>`;
  }

  #renderFacets() {
    const tags = this.#shell()?.querySelector("[data-role='tags']");
    const collections = this.#shell()?.querySelector("[data-role='collections']");
    if (tags) {
      tags.innerHTML = [
        chipHtml("tag", "", localize("common.all"), !this.#state.tag),
        ...getTags(this.#gallery).map((tag) => chipHtml("tag", tag, tag, this.#state.tag === tag))
      ].join("");
    }
    if (collections) {
      collections.innerHTML = [
        navButtonHtml("collection", "", localize("common.all"), !this.#state.collection, this.#gallery.entries.length),
        ...getCollections(this.#gallery).map((collection) => navButtonHtml(
          "collection",
          collection,
          collection,
          this.#state.collection === collection,
          this.#gallery.entries.filter((entry) => entry.collection === collection).length
        ))
      ].join("");
    }
  }

  #renderEntries() {
    const entries = this.#visibleEntries();
    const items = this.#shell()?.querySelector("[data-role='items']");
    const empty = this.#shell()?.querySelector("[data-role='empty']");
    const count = this.#shell()?.querySelector("[data-role='gallery-count']");
    if (count) count.textContent = localize("gallery.count", { count: this.#gallery.entries.length });
    if (!items || !empty) return;
    empty.hidden = entries.length > 0;
    empty.innerHTML = `<i class="fa-regular fa-images" aria-hidden="true"></i><strong>${escapeHtml(localize(this.#gallery.entries.length ? "gallery.noResults" : "gallery.empty"))}</strong><span>${escapeHtml(localize(this.#gallery.entries.length ? "gallery.noResultsHint" : "gallery.emptyHint"))}</span>`;
    items.innerHTML = entries.map((entry) => this.#entryHtml(entry)).join("");
    this.#hydrateThumbnails(items);
  }

  #entryHtml(entry) {
    const selected = entry.id === this.#state.selectedId;
    const current = this.#currentStates(entry);
    return `
      <article class="aig-card ${selected ? "is-selected" : ""}" data-entry-id="${escapeAttribute(entry.id)}" role="listitem" tabindex="0" draggable="${this.#canEdit() ? "true" : "false"}">
        <div class="aig-card__image">
          <img src="icons/svg/mystery-man.svg" data-thumb-source="${escapeAttribute(entry.source)}" loading="lazy" alt="${escapeAttribute(entry.name)}" draggable="false">
          <div class="aig-card__badges">
            ${entry.isDefault ? `<span title="${escapeAttribute(localize("entry.default"))}"><i class="fa-solid fa-bookmark"></i></span>` : ""}
            ${entry.quickSlot ? `<span title="${escapeAttribute(localize("entry.quickSlot"))}">ALT+${entry.quickSlot}</span>` : ""}
          </div>
          <button type="button" class="aig-card__favorite ${entry.favorite ? "is-active" : ""}" data-action="favorite" data-entry-id="${escapeAttribute(entry.id)}" title="${escapeAttribute(localize("actions.favorite"))}" ${disabledIf(!this.#canEdit())}><i class="fa-${entry.favorite ? "solid" : "regular"} fa-star"></i></button>
          ${current.length ? `<div class="aig-card__current">${current.map((item) => `<span><i class="fa-solid fa-check"></i>${escapeHtml(item)}</span>`).join("")}</div>` : ""}
        </div>
        <div class="aig-card__body">
          <div class="aig-card__heading"><strong>${escapeHtml(entry.name)}</strong><span>${formatDate(entry.createdAt)}</span></div>
          ${entry.collection ? `<span class="aig-card__collection">${escapeHtml(entry.collection)}</span>` : ""}
          <div class="aig-card__tags">${entry.tags.slice(0, 4).map((tag) => `<span>${escapeHtml(tag)}</span>`).join("")}</div>
          <p>${escapeHtml(entry.description)}</p>
          <div class="aig-card__usage"><i class="fa-solid fa-bolt"></i>${escapeHtml(localize("entry.used", { count: entry.usageCount }))}</div>
        </div>
      </article>
    `;
  }

  #renderHistory() {
    const target = this.#shell()?.querySelector("[data-role='history']");
    if (!target) return;
    const byId = new Map(this.#gallery.entries.map((entry) => [entry.id, entry]));
    const entries = this.#gallery.history.map((id) => byId.get(id)).filter(Boolean).slice(0, 6);
    target.innerHTML = entries.length
      ? entries.map((entry) => `<li><button type="button" data-action="select-entry" data-entry-id="${escapeAttribute(entry.id)}" draggable="${this.#canEdit() ? "true" : "false"}"><img src="${escapeAttribute(entry.source)}" alt="" draggable="false"><span>${escapeHtml(entry.name)}</span></button></li>`).join("")
      : `<li class="aig-muted">${escapeHtml(localize("gallery.noRecent"))}</li>`;
  }

  #renderInspector() {
    const target = this.#shell()?.querySelector("[data-role='inspector']");
    if (!target) return;
    if (this.#editing) {
      target.innerHTML = this.#editorHtml();
      this.#refreshEditorPreview();
      return;
    }
    const entry = this.#selectedEntry();
    if (!entry) {
      target.innerHTML = `<div class="aig-inspector__blank"><i class="fa-solid fa-arrow-pointer"></i><p>${escapeHtml(localize("gallery.selectHint"))}</p></div>`;
      return;
    }
    const current = this.#currentStates(entry);
    const features = featureFlags(this.#gallery);
    const configuredTarget = this.#state.applyTarget;
    const defaultTarget = configuredTarget === APPLY_TARGETS.ASK ? "" : configuredTarget;
    const hasApplyTarget = features.portrait || features.token;
    const layoutActions = this.#layoutActionsHtml();
    target.innerHTML = `
      <div class="aig-inspector__preview"><img src="${escapeAttribute(entry.source)}" alt="${escapeAttribute(entry.name)}"></div>
      <div class="aig-inspector__header">
        <div><span class="aig-kicker">${escapeHtml(entry.collection || localize("entry.uncategorized"))}</span><h2>${escapeHtml(entry.name)}</h2></div>
        <div class="aig-inspector__header-actions">${layoutActions}<button type="button" class="aig-icon-button ${entry.favorite ? "is-active" : ""}" data-action="favorite" data-entry-id="${escapeAttribute(entry.id)}" title="${escapeAttribute(localize("actions.favorite"))}" ${disabledIf(!this.#canEdit())}><i class="fa-${entry.favorite ? "solid" : "regular"} fa-star"></i></button></div>
      </div>
      ${current.length ? `<div class="aig-current-banner"><i class="fa-solid fa-circle-check"></i><span>${escapeHtml(current.join(" · "))}</span></div>` : ""}
      <p class="aig-inspector__description">${escapeHtml(entry.description || localize("entry.noDescription"))}</p>
      <div class="aig-inspector__tags">${entry.tags.map((tag) => `<button type="button" data-action="tag" data-value="${escapeAttribute(tag)}">#${escapeHtml(tag)}</button>`).join("")}</div>
      <dl class="aig-stats"><div><dt>${escapeHtml(localize("entry.added"))}</dt><dd>${escapeHtml(formatDate(entry.createdAt))}</dd></div><div><dt>${escapeHtml(localize("entry.usage"))}</dt><dd>${entry.usageCount}</dd></div></dl>
      <label class="aig-field"><span>${escapeHtml(localize("actions.applyTo"))}</span><select data-role="apply-target" ${disabledIf(!hasApplyTarget)}>${applyTargetOptions(defaultTarget, features)}</select></label>
      <button type="button" class="aig-button aig-button--signal aig-button--wide" data-action="apply" data-entry-id="${escapeAttribute(entry.id)}" ${disabledIf(!this.#canEdit() || !hasApplyTarget)}><i class="fa-solid fa-wand-magic-sparkles"></i><span>${escapeHtml(localize("actions.apply"))}</span></button>
      <button type="button" class="aig-button aig-button--temporary aig-button--wide" data-action="apply-temporary" data-entry-id="${escapeAttribute(entry.id)}" ${disabledIf(!this.#canEdit() || !hasApplyTarget || !this.#temporaryService)}><i class="fa-solid fa-hourglass-start"></i><span>${escapeHtml(localize("temporary.apply"))}</span></button>
      <div class="aig-inspector__actions">
        <button type="button" class="aig-button" data-action="edit-entry" data-entry-id="${escapeAttribute(entry.id)}" ${disabledIf(!this.#canEdit())}><i class="fa-solid fa-sliders"></i><span>${escapeHtml(localize("actions.edit"))}</span></button>
        <button type="button" class="aig-button" data-action="duplicate" data-entry-id="${escapeAttribute(entry.id)}" ${disabledIf(!this.#canEdit())}><i class="fa-solid fa-copy"></i><span>${escapeHtml(localize("actions.duplicate"))}</span></button>
        <button type="button" class="aig-button" data-action="default" data-entry-id="${escapeAttribute(entry.id)}" ${disabledIf(!this.#canEdit() || entry.isDefault)}><i class="fa-solid fa-bookmark"></i><span>${escapeHtml(localize("actions.setDefault"))}</span></button>
        <button type="button" class="aig-button aig-button--danger" data-action="remove" data-entry-id="${escapeAttribute(entry.id)}" ${disabledIf(!this.#canEdit())}><i class="fa-solid fa-trash"></i><span>${escapeHtml(localize("actions.remove"))}</span></button>
      </div>
    `;
  }

  #editorHtml() {
    const entry = this.#editing;
    const features = featureFlags(this.#gallery);
    if (!features[this.#editingKind]) this.#editingKind = features.portrait ? PRESET_KINDS.PORTRAIT : PRESET_KINDS.TOKEN;
    const preset = entry[this.#editingKind];
    const adjustment = preset.adjustments;
    const existing = this.#gallery.entries.filter((candidate) => candidate.id !== entry.id);
    const presetTabs = [
      features.portrait ? `<button type="button" role="tab" data-action="preset-portrait" aria-selected="${this.#editingKind === PRESET_KINDS.PORTRAIT}" class="${this.#editingKind === PRESET_KINDS.PORTRAIT ? "is-active" : ""}"><i class="fa-solid fa-id-card"></i>${escapeHtml(localize("editor.portraitPreset"))}</button>` : "",
      features.token ? `<button type="button" role="tab" data-action="preset-token" aria-selected="${this.#editingKind === PRESET_KINDS.TOKEN}" class="${this.#editingKind === PRESET_KINDS.TOKEN ? "is-active" : ""}"><i class="fa-solid fa-chess-pawn"></i>${escapeHtml(localize("editor.tokenPreset"))}</button>` : ""
    ].filter(Boolean);
    return `
      <form class="aig-editor" data-role="editor-form">
        <div class="aig-editor__title"><div><span class="aig-kicker">${escapeHtml(localize("editor.kicker"))}</span><h2>${escapeHtml(entry.__new ? localize("editor.addTitle") : localize("editor.editTitle"))}</h2></div><div class="aig-inspector__header-actions">${this.#layoutActionsHtml({ includeExpand: true })}<button type="button" class="aig-icon-button" data-action="cancel-edit" title="${escapeAttribute(localize("common.close"))}"><i class="fa-solid fa-xmark"></i></button></div></div>
        <div class="aig-editor__canvas" data-role="editor-canvas" tabindex="0" aria-label="${escapeAttribute(localize("editor.preview"))}">
          <div class="aig-editor__safe-area"></div>
          <img src="${escapeAttribute(entry.source)}" data-role="editor-image" alt="${escapeAttribute(entry.name)}" draggable="false">
          <span class="aig-editor__drag-hint"><i class="fa-solid fa-up-down-left-right"></i>${escapeHtml(localize("editor.dragHint"))}</span>
        </div>
        <div class="aig-editor__controls">
        <div class="aig-preset-tabs ${presetTabs.length === 1 ? "is-single" : ""}" role="tablist">${presetTabs.join("")}</div>
        <div class="aig-fit-toggle" role="group" aria-label="${escapeAttribute(localize("editor.fitMode"))}">
          <button type="button" data-action="fit-contain" class="${preset.fit === IMAGE_FITS.CONTAIN ? "is-active" : ""}" aria-pressed="${preset.fit === IMAGE_FITS.CONTAIN}" title="${escapeAttribute(localize("editor.fitContainHint"))}"><i class="fa-solid fa-image"></i><span>${escapeHtml(localize("editor.fitContain"))}</span></button>
          <button type="button" data-action="fit-cover" class="${preset.fit === IMAGE_FITS.COVER ? "is-active" : ""}" aria-pressed="${preset.fit === IMAGE_FITS.COVER}" title="${escapeAttribute(localize("editor.fitCoverHint"))}"><i class="fa-solid fa-crop-simple"></i><span>${escapeHtml(localize("editor.fitCover"))}</span></button>
        </div>
        <div class="aig-editor__quick-controls">
          <button type="button" data-action="zoom-out" title="${escapeAttribute(localize("editor.zoomOut"))}"><i class="fa-solid fa-minus"></i></button>
          <input type="range" min="50" max="400" step="1" value="${Math.round(preset.zoom * 100)}" data-editor-control="zoom" aria-label="${escapeAttribute(localize("editor.zoom"))}">
          <button type="button" data-action="zoom-in" title="${escapeAttribute(localize("editor.zoomIn"))}"><i class="fa-solid fa-plus"></i></button>
          <button type="button" data-action="rotate-left" title="${escapeAttribute(localize("editor.rotateLeft"))}"><i class="fa-solid fa-rotate-left"></i><span>90°</span></button>
          <button type="button" data-action="rotate-right" title="${escapeAttribute(localize("editor.rotateRight"))}"><i class="fa-solid fa-rotate-right"></i><span>90°</span></button>
          <button type="button" data-action="flip-horizontal" class="${preset.flipX ? "is-active" : ""}" title="${escapeAttribute(localize("editor.flipHorizontal"))}"><i class="fa-solid fa-left-right"></i></button>
          <button type="button" data-action="flip-vertical" class="${preset.flipY ? "is-active" : ""}" title="${escapeAttribute(localize("editor.flipVertical"))}"><i class="fa-solid fa-up-down"></i></button>
          <button type="button" data-action="reset-preset" title="${escapeAttribute(localize("editor.reset"))}"><i class="fa-solid fa-arrow-rotate-left"></i></button>
        </div>
        <details class="aig-adjustments" open>
          <summary>${escapeHtml(localize("editor.adjustments"))}</summary>
          ${rangeHtml("brightness", localize("editor.brightness"), adjustment.brightness, 0, 200, "%")}
          ${rangeHtml("contrast", localize("editor.contrast"), adjustment.contrast, 0, 200, "%")}
          ${rangeHtml("saturation", localize("editor.saturation"), adjustment.saturation, 0, 200, "%")}
          ${rangeHtml("temperature", localize("editor.temperature"), adjustment.temperature, -100, 100, "")}
          ${rangeHtml("exposure", localize("editor.exposure"), adjustment.exposure, -100, 100, "")}
          ${rangeHtml("shadows", localize("editor.shadows"), adjustment.shadows, -100, 100, "")}
          ${rangeHtml("highlights", localize("editor.highlights"), adjustment.highlights, -100, 100, "")}
          ${rangeHtml("grayscale", localize("editor.grayscale"), adjustment.grayscale, 0, 100, "%")}
          ${rangeHtml("blur", localize("editor.blur"), adjustment.blur, 0, 12, "px", 0.25)}
        </details>
        <div class="aig-editor__metadata">
          <label class="aig-field aig-field--wide"><span>${escapeHtml(localize("entry.source"))}</span><span class="aig-field__with-button"><input type="text" name="source" value="${escapeAttribute(entry.source)}" required><button type="button" data-action="browse-source" title="${escapeAttribute(localize("actions.browse"))}"><i class="fa-solid fa-folder-open"></i></button><button type="button" data-action="pick-local" title="${escapeAttribute(localize("actions.localFile"))}"><i class="fa-solid fa-upload"></i></button></span></label>
          ${existing.length ? `<label class="aig-field aig-field--wide"><span>${escapeHtml(localize("editor.reuse"))}</span><span class="aig-field__with-button"><select data-role="reuse-source"><option value="">${escapeHtml(localize("editor.chooseExisting"))}</option>${existing.map((candidate) => `<option value="${escapeAttribute(candidate.source)}">${escapeHtml(candidate.name)}</option>`).join("")}</select><button type="button" data-action="reuse-source" title="${escapeAttribute(localize("editor.reuse"))}"><i class="fa-solid fa-link"></i></button></span></label>` : ""}
          <label class="aig-field aig-field--wide"><span>${escapeHtml(localize("entry.name"))}</span><input type="text" name="name" maxlength="120" value="${escapeAttribute(entry.name)}" required></label>
          <label class="aig-field aig-field--wide"><span>${escapeHtml(localize("entry.tags"))}</span><input type="text" name="tags" maxlength="500" value="${escapeAttribute(entry.tags.join(", "))}" placeholder="${escapeAttribute(localize("entry.tagsPlaceholder"))}"></label>
          <label class="aig-field"><span>${escapeHtml(localize("entry.collection"))}</span><input type="text" name="collection" list="aig-collections" maxlength="80" value="${escapeAttribute(entry.collection)}"><datalist id="aig-collections">${getCollections(this.#gallery).map((value) => `<option value="${escapeAttribute(value)}"></option>`).join("")}</datalist></label>
          <label class="aig-field"><span>${escapeHtml(localize("entry.quickSlot"))}</span><select name="quickSlot"><option value="">—</option>${[1, 2, 3, 4].map((slot) => `<option value="${slot}" ${entry.quickSlot === slot ? "selected" : ""}>ALT + ${slot}</option>`).join("")}</select></label>
          <label class="aig-field aig-field--wide"><span>${escapeHtml(localize("entry.description"))}</span><textarea name="description" maxlength="1000">${escapeHtml(entry.description)}</textarea></label>
        </div>
        <div class="aig-editor__footer"><button type="button" class="aig-button" data-action="cancel-edit">${escapeHtml(localize("common.cancel"))}</button><button type="button" class="aig-button aig-button--signal" data-action="save-entry"><i class="fa-solid fa-floppy-disk"></i>${escapeHtml(localize("common.save"))}</button></div>
        </div>
      </form>
    `;
  }

  async #onClick(event) {
    if (this.#suppressCardClick && event.target.closest?.(".aig-card")) {
      event.preventDefault();
      event.stopPropagation();
      this.#suppressCardClick = false;
      return;
    }
    const actionTarget = event.target.closest?.("[data-action]");
    const card = event.target.closest?.("[data-entry-id]");
    if (!actionTarget) {
      if (card?.classList.contains("aig-card")) this.#select(card.dataset.entryId);
      return;
    }
    const action = actionTarget.dataset.action;
    const entryId = actionTarget.dataset.entryId ?? card?.dataset.entryId;
    try {
      if (action === "new-entry") this.#openEditor();
      else if (action === "profiles-open") { this.#togglePaletteEditor(false); this.#toggleBackupPanel(false); this.#toggleSequencesPanel(false); this.#toggleProfilesPanel(true); }
      else if (action === "profiles-close") this.#toggleProfilesPanel(false);
      else if (action === "profile-new") { this.#profileEditingId = "__new"; this.#renderProfilesPanel(); }
      else if (action === "profile-edit") { this.#profileEditingId = actionTarget.dataset.profileId; this.#renderProfilesPanel(); }
      else if (action === "profile-cancel") { this.#profileEditingId = null; this.#renderProfilesPanel(); }
      else if (action === "profile-save") await this.#saveProfile();
      else if (action === "profile-apply") await this.#applyProfile(actionTarget.dataset.profileId);
      else if (action === "profile-remove") await this.#removeProfile(actionTarget.dataset.profileId);
      else if (action === "sequences-open") { this.#togglePaletteEditor(false); this.#toggleBackupPanel(false); this.#toggleProfilesPanel(false); this.#toggleSequencesPanel(true); }
      else if (action === "sequences-close") this.#toggleSequencesPanel(false);
      else if (action === "sequence-new") this.#openSequenceEditor();
      else if (action === "sequence-edit") this.#openSequenceEditor(actionTarget.dataset.sequenceId);
      else if (action === "sequence-cancel") { this.#sequenceEditing = null; this.#renderSequencesPanel(); }
      else if (action === "sequence-save") await this.#saveSequence();
      else if (action === "sequence-order-up") await this.#moveSequence(actionTarget.dataset.sequenceId, -1);
      else if (action === "sequence-order-down") await this.#moveSequence(actionTarget.dataset.sequenceId, 1);
      else if (action === "sequence-duplicate") await this.#duplicateSequence(actionTarget.dataset.sequenceId);
      else if (action === "sequence-remove") await this.#removeSequence(actionTarget.dataset.sequenceId);
      else if (["sequence-next", "sequence-previous", "sequence-reset"].includes(action)) await this.#navigateSequence(actionTarget.dataset.sequenceId, action.replace("sequence-", ""));
      else if (action === "sequence-step-add") this.#addSequenceStep();
      else if (action === "sequence-step-remove") this.#moveSequenceStep(Number(actionTarget.dataset.stepIndex), "remove");
      else if (action === "sequence-step-up") this.#moveSequenceStep(Number(actionTarget.dataset.stepIndex), "up");
      else if (action === "sequence-step-down") this.#moveSequenceStep(Number(actionTarget.dataset.stepIndex), "down");
      else if (action === "automation-open") await this.#openAutomationManager?.();
      else if (action === "backup-open") { this.#togglePaletteEditor(false); this.#toggleProfilesPanel(false); this.#toggleSequencesPanel(false); this.#toggleBackupPanel(true); }
      else if (action === "backup-close") this.#toggleBackupPanel(false);
      else if (action === "backup-export-actor") this.#exportActorBackup();
      else if (action === "backup-import-actor") this.#shell()?.querySelector("[data-role='backup-file']")?.click();
      else if (action === "open-global-gallery") await this.#openGlobalGallery?.();
      else if (action === "palette-open") { this.#toggleBackupPanel(false); this.#toggleProfilesPanel(false); this.#toggleSequencesPanel(false); this.#togglePaletteEditor(true); }
      else if (action === "palette-cancel") {
        this.#applyPalette(getSetting("customPalette", DEFAULT_PALETTE));
        this.#togglePaletteEditor(false);
      } else if (action === "palette-reset") {
        this.#setPaletteInputs(DEFAULT_PALETTE);
        this.#applyPalette(DEFAULT_PALETTE);
      } else if (action === "palette-save") await this.#savePalette();
      else if (action === "select-entry") this.#select(entryId);
      else if (action === "edit-entry") this.#openEditor(entryId);
      else if (action === "cancel-edit") this.#closeEditor();
      else if (action === "save-entry") await this.#saveEditor();
      else if (action === "favorite") await this.#mutate((gallery) => toggleFavorite(gallery, entryId));
      else if (action === "default") await this.#mutate((gallery) => setDefault(gallery, entryId));
      else if (action === "duplicate") await this.#duplicate(entryId);
      else if (action === "remove") await this.#remove(entryId);
      else if (action === "apply") await this.#apply(entryId);
      else if (action === "apply-temporary") await this.#applyTemporary(entryId);
      else if (action === "revert-temporary") await this.#revertTemporary();
      else if (action === "toggle-inspector-side") {
        this.#state.inspectorSide = this.#state.inspectorSide === "right" ? "left" : "right";
        await setSetting("inspectorSide", this.#state.inspectorSide);
        this.#applyPanelLayout();
        this.#renderInspector();
      } else if (action === "toggle-editor-expand") {
        this.#state.editorExpanded = !this.#state.editorExpanded;
        this.#applyPanelLayout();
        this.#renderInspector();
      }
      else if (action === "toggle-favorites") {
        this.#state.favoritesOnly = !this.#state.favoritesOnly;
        this.#rerenderContent();
      } else if (action === "view-grid" || action === "view-list") {
        this.#state.view = action === "view-grid" ? "grid" : "list";
        void setSetting("galleryView", this.#state.view);
        await this.render({ force: true });
      } else if (action === "tag") {
        this.#state.tag = actionTarget.dataset.value ?? "";
        this.#rerenderContent();
      } else if (action === "collection") {
        this.#state.collection = actionTarget.dataset.value ?? "";
        this.#rerenderContent();
      } else if (action === "browse-source") await this.#browseSource(actionTarget);
      else if (action === "pick-local") this.#shell()?.querySelector("[data-role='local-files']")?.click();
      else if (action === "reuse-source") this.#reuseSource();
      else if (action === "preset-portrait" || action === "preset-token") {
        const requestedKind = action === "preset-portrait" ? PRESET_KINDS.PORTRAIT : PRESET_KINDS.TOKEN;
        if (!featureFlags(this.#gallery)[requestedKind]) return;
        this.#editingKind = requestedKind;
        this.#renderInspector();
      } else if (["fit-contain", "fit-cover", "zoom-in", "zoom-out", "rotate-left", "rotate-right", "flip-horizontal", "flip-vertical", "reset-preset"].includes(action)) {
        this.#editorAction(action);
      }
    } catch (error) {
      this.#handleError(error);
    }
  }

  #onInput(event) {
    if (event.target.dataset.paletteKey) {
      const code = event.target.closest("label")?.querySelector("code");
      if (code) code.textContent = event.target.value;
      this.#applyPalette(this.#paletteFromInputs());
      return;
    }
    if (event.target.dataset.role === "search") {
      this.#state.query = event.target.value;
      this.#renderEntries();
      return;
    }
    const control = event.target.dataset.editorControl;
    if (!control || !this.#editing) return;
    const preset = this.#editing[this.#editingKind];
    const value = Number(event.target.value);
    if (control === "zoom") preset.zoom = clamp(value / 100, 0.5, 4);
    else preset.adjustments[control] = value;
    const output = event.target.closest("label")?.querySelector("output");
    if (output) output.textContent = `${event.target.value}${event.target.dataset.unit ?? ""}`;
    this.#refreshEditorPreview();
  }

  async #onChange(event) {
    if (event.target.dataset.role === "apply-target") {
      this.#state.applyTarget = event.target.value;
      await setSetting("defaultApplyTarget", this.#state.applyTarget);
      return;
    }
    if (event.target.dataset.role === "ignore-token-changes") {
      const ignoreTokenChanges = Boolean(event.target.checked);
      await this.#mutate((gallery) => ({ ...gallery, ignoreTokenChanges }));
      notify("info", ignoreTokenChanges ? "notifications.tokenGuardEnabled" : "notifications.tokenGuardDisabled");
      return;
    }
    if (event.target.dataset.role === "sort") {
      this.#state.sort = event.target.value;
      await setSetting("gallerySort", this.#state.sort);
      this.#renderEntries();
      return;
    }
    if (event.target.dataset.role === "sequence-step-type" && this.#sequenceEditing) {
      this.#syncSequenceEditor();
      const index = Number(event.target.closest("[data-step-index]")?.dataset.stepIndex);
      const step = this.#sequenceEditing.steps[index];
      const targets = step?.targetType === "profile" ? this.#gallery.profiles : this.#gallery.entries;
      if (step && !targets.some((item) => item.id === step.targetId)) step.targetId = targets[0]?.id ?? "";
      this.#renderSequencesPanel();
      return;
    }
    if (event.target.dataset.role === "local-files" && event.target.files?.length) {
      const files = Array.from(event.target.files);
      if (this.#editing) await this.#useLocalFileInEditor(files[0]);
      else await this.#addLocalFiles(files);
      event.target.value = "";
      return;
    }
    if (event.target.dataset.role === "backup-file" && event.target.files?.[0]) {
      await this.#importActorBackup(event.target.files[0]);
      event.target.value = "";
      return;
    }
    if (event.target.name === "source" && this.#editing) {
      this.#editing.source = event.target.value.trim();
      const image = this.#shell()?.querySelector("[data-role='editor-image']");
      if (image) image.src = this.#editing.source;
    }
  }

  async #onDoubleClick(event) {
    const resizer = event.target.closest?.("[data-resize-panel]");
    if (resizer) {
      event.preventDefault();
      const panel = resizer.dataset.resizePanel;
      this.#state[`${panel}Width`] = panel === "sidebar" ? 168 : 312;
      await setSetting(`${panel}Width`, this.#state[`${panel}Width`]);
      this.#applyPanelLayout();
      return;
    }
    const card = event.target.closest?.(".aig-card[data-entry-id]");
    if (!card) return;
    await this.#apply(card.dataset.entryId);
  }

  async #onKeyDown(event) {
    const resizer = event.target.closest?.("[data-resize-panel]");
    if (resizer && ["ArrowLeft", "ArrowRight", "Home"].includes(event.key)) {
      event.preventDefault();
      const panel = resizer.dataset.resizePanel;
      if (event.key === "Home") this.#state[`${panel}Width`] = panel === "sidebar" ? 168 : 312;
      else this.#resizePanel(panel, this.#state[`${panel}Width`], event.key === "ArrowRight" ? 16 : -16);
      await setSetting(`${panel}Width`, this.#state[`${panel}Width`]);
      this.#applyPanelLayout();
      return;
    }
    const card = event.target.closest?.(".aig-card[data-entry-id]");
    if (card && ["Enter", " "].includes(event.key)) {
      event.preventDefault();
      this.#select(card.dataset.entryId);
      if (event.key === "Enter") await this.#apply(card.dataset.entryId);
      return;
    }
    if (event.key === "Escape" && this.#editing) {
      event.preventDefault();
      this.#closeEditor();
      return;
    }
    if (event.key === "Escape" && !this.#shell()?.querySelector("[data-role='sequences-panel']")?.hidden) this.#toggleSequencesPanel(false);
  }

  #onWheel(event) {
    if (!event.target.closest?.("[data-role='editor-canvas']") || !this.#editing) return;
    event.preventDefault();
    const preset = this.#editing[this.#editingKind];
    preset.zoom = clamp(preset.zoom * Math.exp(-event.deltaY * 0.0015), 0.5, 4);
    const input = this.#shell()?.querySelector("[data-editor-control='zoom']");
    if (input) input.value = String(Math.round(preset.zoom * 100));
    this.#refreshEditorPreview();
  }

  #onPointerDown(event) {
    const resizer = event.target.closest?.("[data-resize-panel]");
    if (resizer) {
      const panel = resizer.dataset.resizePanel;
      this.#panelResize = {
        panel,
        pointerId: event.pointerId,
        startX: event.clientX,
        startWidth: this.#state[`${panel}Width`]
      };
      resizer.setPointerCapture?.(event.pointerId);
      this.#shell()?.classList.add("is-resizing-panels");
      resizer.classList.add("is-active");
      event.preventDefault();
      return;
    }
    const canvas = event.target.closest?.("[data-role='editor-canvas']");
    if (!canvas || !this.#editing) {
      const card = event.target.closest?.(".aig-card[data-entry-id]");
      if (!card || event.target.closest?.("button, input, select, textarea, a") || !this.#canEdit()) return;
      if (event.pointerType === "mouse") return;
      this.#cardDrag = {
        pointerId: event.pointerId,
        draggedId: card.dataset.entryId,
        targetId: card.dataset.entryId,
        placement: "before",
        baseIds: mergeVisibleEntryOrder(
          this.#gallery.entries.slice().sort((left, right) => left.manualOrder - right.manualOrder).map((entry) => entry.id),
          this.#visibleEntries().map((entry) => entry.id)
        ),
        startX: event.clientX,
        startY: event.clientY,
        dragging: false,
        card
      };
      card.setPointerCapture?.(event.pointerId);
      return;
    }
    canvas.setPointerCapture?.(event.pointerId);
    this.#touches.set(event.pointerId, { x: event.clientX, y: event.clientY });
    if (this.#touches.size === 1) {
      const preset = this.#editing[this.#editingKind];
      this.#pointerState = {
        startX: event.clientX,
        startY: event.clientY,
        positionX: preset.positionX,
        positionY: preset.positionY,
        width: canvas.clientWidth,
        height: canvas.clientHeight,
        pinchDistance: null,
        pinchZoom: preset.zoom
      };
    } else if (this.#touches.size === 2) {
      this.#pointerState.pinchDistance = touchDistance(this.#touches);
      this.#pointerState.pinchZoom = this.#editing[this.#editingKind].zoom;
    }
    event.preventDefault();
  }

  #onPointerMove(event) {
    if (this.#panelResize?.pointerId === event.pointerId) {
      this.#resizePanel(this.#panelResize.panel, this.#panelResize.startWidth, event.clientX - this.#panelResize.startX);
      this.#applyPanelLayout();
      event.preventDefault();
      return;
    }
    if (this.#cardDrag?.pointerId === event.pointerId) {
      const drag = this.#cardDrag;
      const distance = Math.hypot(event.clientX - drag.startX, event.clientY - drag.startY);
      if (!drag.dragging && distance < 6) return;
      if (!drag.dragging) {
        drag.dragging = true;
        drag.card.classList.add("is-dragging");
        this.#state.sort = SORT_MODES.MANUAL;
        const sort = this.#shell()?.querySelector("[data-role='sort']");
        if (sort) sort.value = SORT_MODES.MANUAL;
      }
      const pointed = globalThis.document?.elementFromPoint?.(event.clientX, event.clientY);
      const target = pointed?.closest?.(".aig-card[data-entry-id]");
      const items = pointed?.closest?.("[data-role='items']");
      if (target && target.dataset.entryId !== drag.draggedId) {
        const rect = target.getBoundingClientRect();
        const listView = this.#state.view === "list";
        drag.targetId = target.dataset.entryId;
        drag.placement = (listView ? event.clientY > rect.top + rect.height / 2 : event.clientX > rect.left + rect.width / 2)
          ? "after"
          : "before";
      } else if (items) {
        drag.targetId = null;
        drag.placement = "after";
      }
      this.#shell()?.querySelectorAll(".aig-card.is-drop-target, .aig-card.is-drop-before, .aig-card.is-drop-after").forEach((card) => {
        const active = card === target && target?.dataset.entryId !== drag.draggedId;
        card.classList.toggle("is-drop-target", active);
        card.classList.toggle("is-drop-before", active && drag.placement === "before");
        card.classList.toggle("is-drop-after", active && drag.placement === "after");
      });
      event.preventDefault();
      return;
    }
    if (!this.#touches.has(event.pointerId) || !this.#pointerState || !this.#editing) return;
    this.#touches.set(event.pointerId, { x: event.clientX, y: event.clientY });
    const preset = this.#editing[this.#editingKind];
    if (this.#touches.size >= 2 && this.#pointerState.pinchDistance) {
      const distance = touchDistance(this.#touches);
      preset.zoom = clamp(this.#pointerState.pinchZoom * distance / this.#pointerState.pinchDistance, 0.5, 4);
    } else {
      preset.positionX = clamp(this.#pointerState.positionX + (event.clientX - this.#pointerState.startX) / this.#pointerState.width * 100, -100, 100);
      preset.positionY = clamp(this.#pointerState.positionY + (event.clientY - this.#pointerState.startY) / this.#pointerState.height * 100, -100, 100);
    }
    this.#refreshEditorPreview();
  }

  #onPointerUp(event) {
    if (this.#panelResize?.pointerId === event.pointerId) {
      const panel = this.#panelResize.panel;
      this.#panelResize = null;
      this.#shell()?.classList.remove("is-resizing-panels");
      this.#shell()?.querySelectorAll(".aig-resizer.is-active").forEach((element) => element.classList.remove("is-active"));
      void setSetting(`${panel}Width`, this.#state[`${panel}Width`]);
      return;
    }
    if (this.#cardDrag?.pointerId === event.pointerId) {
      const drag = this.#cardDrag;
      this.#cardDrag = null;
      drag.card.releasePointerCapture?.(event.pointerId);
      this.#clearDragState();
      if (drag.dragging && event.type !== "pointercancel") {
        this.#suppressCardClick = true;
        setTimeout(() => { this.#suppressCardClick = false; }, 150);
        void this.#reorder(drag.draggedId, drag.targetId, drag.placement, drag.baseIds).catch((error) => this.#handleError(error));
        event.preventDefault();
      }
      return;
    }
    this.#touches.delete(event.pointerId);
    if (!this.#touches.size) this.#stopPointerGesture();
  }

  #stopPointerGesture() {
    this.#touches.clear();
    this.#pointerState = null;
  }

  #onCardDragStart(event) {
    const source = event.target.closest?.(".aig-card[data-entry-id], .aig-history [data-entry-id]");
    if (!source || !event.dataTransfer || !this.#canEdit()) return;
    if (event.target.closest?.(".aig-card button, input, select, textarea, a")) {
      event.preventDefault();
      return;
    }
    const draggedId = source.dataset.entryId;
    if (!this.#gallery.entries.some((entry) => entry.id === draggedId)) {
      event.preventDefault();
      return;
    }
    const card = this.#shell()?.querySelector(`.aig-card[data-entry-id="${globalThis.CSS?.escape?.(draggedId) ?? draggedId}"]`);
    this.#cardDrag = {
      pointerId: null,
      native: true,
      draggedId,
      targetId: draggedId,
      placement: "before",
      baseIds: mergeVisibleEntryOrder(
        this.#gallery.entries.slice().sort((left, right) => left.manualOrder - right.manualOrder).map((entry) => entry.id),
        this.#visibleEntries().map((entry) => entry.id)
      ),
      dragging: true,
      card
    };
    event.dataTransfer.effectAllowed = "move";
    event.dataTransfer.setData(ENTRY_DRAG_TYPE, draggedId);
    event.dataTransfer.setData("text/plain", draggedId);
    card?.classList.add("is-dragging");
    this.#state.sort = SORT_MODES.MANUAL;
    const sort = this.#shell()?.querySelector("[data-role='sort']");
    if (sort) sort.value = SORT_MODES.MANUAL;
  }

  #onCardDragEnd() {
    if (!this.#cardDrag?.native) return;
    this.#cardDrag = null;
    this.#clearDragState();
  }

  #onDragOver(event) {
    const shell = event.target.closest?.(".aig-shell");
    if (!shell || !event.dataTransfer) return;
    const gallery = event.target.closest?.("[data-role='drop-zone']");
    const types = Array.from(event.dataTransfer.types ?? []);
    const internal = types.includes(ENTRY_DRAG_TYPE);
    if (internal && this.#cardDrag?.native) {
      event.preventDefault();
      event.stopPropagation();
      event.dataTransfer.dropEffect = "move";
      const target = event.target.closest?.(".aig-card[data-entry-id]");
      if (target && target.dataset.entryId !== this.#cardDrag.draggedId) {
        const rect = target.getBoundingClientRect();
        const listView = this.#state.view === "list";
        this.#cardDrag.targetId = target.dataset.entryId;
        this.#cardDrag.placement = (listView ? event.clientY > rect.top + rect.height / 2 : event.clientX > rect.left + rect.width / 2) ? "after" : "before";
      } else if (gallery) {
        this.#cardDrag.targetId = null;
        this.#cardDrag.placement = "after";
      }
      shell.querySelectorAll(".aig-card.is-drop-target, .aig-card.is-drop-before, .aig-card.is-drop-after").forEach((card) => {
        const active = card === target && target?.dataset.entryId !== this.#cardDrag.draggedId;
        card.classList.toggle("is-drop-target", active);
        card.classList.toggle("is-drop-before", active && this.#cardDrag.placement === "before");
        card.classList.toggle("is-drop-after", active && this.#cardDrag.placement === "after");
      });
      return;
    }
    const external = types.includes("Files");
    if (!external) return;
    event.preventDefault();
    event.stopPropagation();
    event.dataTransfer.dropEffect = "copy";
    const dropZone = gallery ?? shell.querySelector("[data-role='drop-zone']");
    dropZone?.classList.add("is-external-drop");
    shell.querySelectorAll(".aig-card.is-drop-target").forEach((card) => card.classList.remove("is-drop-target"));
  }

  #onDragLeave(event) {
    const shell = event.target.closest?.(".aig-shell");
    if (shell && (!event.relatedTarget || !shell.contains(event.relatedTarget))) this.#clearDragState();
  }

  async #onDrop(event) {
    const shell = event.target.closest?.(".aig-shell");
    if (!shell || !event.dataTransfer) return;
    const gallery = event.target.closest?.("[data-role='drop-zone']");
    event.preventDefault();
    event.stopPropagation();
    try {
      const internalId = event.dataTransfer.getData(ENTRY_DRAG_TYPE);
      if (internalId && this.#cardDrag?.native) {
        const drag = this.#cardDrag;
        this.#cardDrag = null;
        this.#suppressCardClick = true;
        setTimeout(() => { this.#suppressCardClick = false; }, 150);
        await this.#reorder(drag.draggedId, drag.targetId, drag.placement, drag.baseIds);
        return;
      }
      const plain = event.dataTransfer.getData("text/plain");
      const files = droppedImageFiles(event.dataTransfer);
      if (files.length) {
        await this.#addLocalFiles(files);
        return;
      }
      const raw = event.dataTransfer.getData("text/uri-list") || plain;
      const source = extractDroppedSource(raw);
      if (source) await this.#addSource(source);
    } finally {
      this.#clearDragState();
    }
  }

  #clearDragState() {
    const shell = this.#shell();
    shell?.querySelector("[data-role='drop-zone']")?.classList.remove("is-external-drop");
    shell?.querySelectorAll(".aig-card.is-dragging, .aig-card.is-drop-target, .aig-card.is-drop-before, .aig-card.is-drop-after").forEach((card) => card.classList.remove("is-dragging", "is-drop-target", "is-drop-before", "is-drop-after"));
  }

  #select(entryId) {
    if (!this.#gallery.entries.some((entry) => entry.id === entryId)) return;
    this.#state.selectedId = entryId;
    this.#editing = null;
    this.#renderEntries();
    this.#renderInspector();
  }

  #openEditor(entryId = null) {
    if (!this.#canEdit()) return;
    const existing = this.#gallery.entries.find((entry) => entry.id === entryId);
    this.#editing = existing
      ? deepClone(existing)
      : { ...createEntry({ source: "", name: "" }), __new: true };
    this.#editingKind = featureFlags(this.#gallery).portrait ? PRESET_KINDS.PORTRAIT : PRESET_KINDS.TOKEN;
    this.#renderInspector();
  }

  #closeEditor() {
    this.#editing = null;
    this.#state.editorExpanded = false;
    this.#applyPanelLayout();
    this.#renderInspector();
  }

  async #saveEditor() {
    const form = this.#shell()?.querySelector("[data-role='editor-form']");
    if (!form || !this.#editing) return;
    const formData = new FormData(form);
    const patch = {
      source: String(formData.get("source") ?? "").trim(),
      name: String(formData.get("name") ?? "").trim(),
      tags: String(formData.get("tags") ?? ""),
      collection: String(formData.get("collection") ?? "").trim(),
      quickSlot: formData.get("quickSlot") ? Number(formData.get("quickSlot")) : null,
      description: String(formData.get("description") ?? "").trim(),
      portrait: this.#editing.portrait,
      token: this.#editing.token
    };
    if (!patch.source) throw Object.assign(new Error("sourceRequired"), { code: "sourceRequired" });
    const wasNew = this.#editing.__new;
    const entryId = this.#editing.id;
    const previousEntry = this.#gallery.entries.find((entry) => entry.id === entryId);
    const portraitWasActive = !wasNew && entryMatchesAppliedSource(previousEntry, this.#actor.img, PRESET_KINDS.PORTRAIT);
    const result = await this.#repository.mutate(this.#actor, (gallery) => wasNew
      ? addEntry(gallery, patch)
      : updateEntry(gallery, entryId, patch));
    this.#gallery = result.gallery;
    const savedId = result.value?.id ?? entryId;
    this.#state.selectedId = savedId;
    if (portraitWasActive) {
      await this.#applicator.apply(this.#actor, savedId, APPLY_TARGETS.PORTRAIT, {
        token: this.#token,
        recordUsage: false,
        preserveTemporary: this.#gallery.temporaryState?.activeEntryId === savedId
      });
      this.#gallery = this.#repository.read(this.#actor);
    }
    this.#editing = null;
    this.#state.editorExpanded = false;
    this.#applyPanelLayout();
    this.#renderAll();
    notify("info", wasNew ? "notifications.added" : "notifications.saved");
  }

  async #mutate(mutator) {
    const result = await this.#repository.mutate(this.#actor, mutator);
    this.#gallery = result.gallery;
    this.#renderAll();
    return result;
  }

  async #duplicate(entryId) {
    const result = await this.#mutate((gallery) => duplicateEntry(gallery, entryId, { suffix: localize("entry.copySuffix") }));
    this.#state.selectedId = result.value?.id ?? this.#state.selectedId;
    this.#renderAll();
    notify("info", "notifications.duplicated");
  }

  async #remove(entryId) {
    const entry = this.#gallery.entries.find((candidate) => candidate.id === entryId);
    if (!entry) return;
    const confirmed = await confirmAction({
      title: localize("remove.title"),
      content: `<p>${escapeHtml(localize("remove.content", { name: entry.name }))}</p>`
    });
    if (!confirmed) return;
    await this.#mutate((gallery) => removeEntry(gallery, entryId));
    this.#state.selectedId = this.#gallery.entries[0]?.id ?? null;
    this.#renderAll();
    notify("info", "notifications.removed");
  }

  async #apply(entryId) {
    const targetSelect = this.#shell()?.querySelector("[data-role='apply-target']");
    let target = targetSelect?.value ?? getSetting("defaultApplyTarget", APPLY_TARGETS.PORTRAIT_CURRENT);
    if (!target || target === APPLY_TARGETS.ASK) throw Object.assign(new Error("chooseTarget"), { code: "chooseTarget" });
    if (this.#gallery.temporaryState) {
      const confirmed = await confirmAction({
        title: localize("temporary.commitTitle"),
        content: `<p>${escapeHtml(localize("temporary.commitContent"))}</p>`
      });
      if (!confirmed) return;
    }
    const result = await this.#applicator.apply(this.#actor, entryId, target, { token: this.#token });
    this.#gallery = this.#repository.read(this.#actor);
    this.#renderAll();
    notify("info", result.temporaryCleared ? "notifications.temporaryCommitted" : "notifications.applied");
  }

  async #applyTemporary(entryId) {
    const targetSelect = this.#shell()?.querySelector("[data-role='apply-target']");
    const target = targetSelect?.value ?? getSetting("defaultApplyTarget", APPLY_TARGETS.PORTRAIT_CURRENT);
    if (!target || target === APPLY_TARGETS.ASK) throw Object.assign(new Error("chooseTarget"), { code: "chooseTarget" });
    const result = await this.#temporaryService.apply(this.#actor, entryId, target, { token: this.#token });
    this.#gallery = this.#repository.read(this.#actor);
    this.#renderAll();
    notify("info", result.replaced ? "notifications.temporaryReplaced" : "notifications.temporaryStarted");
  }

  async #revertTemporary() {
    await this.#temporaryService.revert(this.#actor);
    this.#gallery = this.#repository.read(this.#actor);
    this.#renderAll();
    notify("info", "notifications.temporaryReverted");
  }

  #toggleProfilesPanel(open) {
    const panel = this.#shell()?.querySelector("[data-role='profiles-panel']");
    if (!panel) return;
    panel.hidden = !open;
    if (open) {
      this.#renderProfilesPanel();
      panel.querySelector("button, input, select")?.focus();
    } else this.#profileEditingId = null;
  }

  #toggleSequencesPanel(open) {
    const panel = this.#shell()?.querySelector("[data-role='sequences-panel']");
    if (!panel) return;
    panel.hidden = !open;
    if (open) {
      this.#renderSequencesPanel();
      panel.querySelector("button, input, select")?.focus();
    } else this.#sequenceEditing = null;
  }

  #openSequenceEditor(sequenceId = null) {
    if (!this.#canEdit() || !this.#sequencesAvailable()) return;
    const existing = this.#gallery.sequences.find((sequence) => sequence.id === sequenceId);
    if (existing) this.#sequenceEditing = deepClone(existing);
    else {
      const first = defaultSequenceStep(this.#gallery);
      this.#sequenceEditing = {
        __new: true,
        id: null,
        name: "",
        description: "",
        mode: SEQUENCE_MODES.CLAMP,
        steps: first ? [first] : []
      };
    }
    this.#renderSequencesPanel();
  }

  #syncSequenceEditor() {
    const form = this.#shell()?.querySelector("[data-role='sequence-form']");
    if (!form || !this.#sequenceEditing) return;
    const formData = new FormData(form);
    this.#sequenceEditing.name = String(formData.get("name") ?? "").trim();
    this.#sequenceEditing.description = String(formData.get("description") ?? "").trim();
    this.#sequenceEditing.mode = String(formData.get("mode") ?? SEQUENCE_MODES.CLAMP);
    for (const row of form.querySelectorAll(".aig-sequence-step[data-step-index]")) {
      const index = Number(row.dataset.stepIndex);
      const step = this.#sequenceEditing.steps[index];
      if (!step) continue;
      step.label = row.querySelector("[data-sequence-field='label']")?.value?.trim() ?? "";
      step.targetType = row.querySelector("[data-sequence-field='targetType']")?.value ?? "entry";
      step.targetId = row.querySelector("[data-sequence-field='targetId']")?.value ?? "";
    }
  }

  #addSequenceStep() {
    if (!this.#sequenceEditing) return;
    this.#syncSequenceEditor();
    const step = defaultSequenceStep(this.#gallery);
    if (!step) throw Object.assign(new Error("sequenceTargetMissing"), { code: "sequenceTargetMissing" });
    this.#sequenceEditing.steps.push(step);
    this.#renderSequencesPanel();
  }

  #moveSequenceStep(index, action) {
    if (!this.#sequenceEditing?.steps[index]) return;
    this.#syncSequenceEditor();
    if (action === "remove") this.#sequenceEditing.steps.splice(index, 1);
    else {
      const target = action === "up" ? index - 1 : index + 1;
      if (target < 0 || target >= this.#sequenceEditing.steps.length) return;
      [this.#sequenceEditing.steps[index], this.#sequenceEditing.steps[target]] = [this.#sequenceEditing.steps[target], this.#sequenceEditing.steps[index]];
    }
    this.#renderSequencesPanel();
  }

  async #saveSequence() {
    if (!this.#sequenceService || !this.#sequenceEditing) throw Object.assign(new Error("sequenceServiceUnavailable"), { code: "sequenceServiceUnavailable" });
    this.#syncSequenceEditor();
    const input = {
      name: this.#sequenceEditing.name,
      description: this.#sequenceEditing.description,
      mode: this.#sequenceEditing.mode,
      steps: this.#sequenceEditing.steps
    };
    if (this.#sequenceEditing.__new) await this.#sequenceService.create(this.#actor, input);
    else await this.#sequenceService.update(this.#actor, this.#sequenceEditing.id, input);
    this.#gallery = this.#repository.read(this.#actor);
    this.#sequenceEditing = null;
    this.#renderAll();
    notify("info", "notifications.sequenceSaved");
  }

  async #duplicateSequence(sequenceId) {
    if (!this.#sequenceService) throw Object.assign(new Error("sequenceServiceUnavailable"), { code: "sequenceServiceUnavailable" });
    await this.#sequenceService.duplicate(this.#actor, sequenceId, { suffix: localize("sequences.copySuffix") });
    this.#gallery = this.#repository.read(this.#actor);
    this.#renderAll();
    notify("info", "notifications.sequenceDuplicated");
  }

  async #moveSequence(sequenceId, delta) {
    if (!this.#sequenceService) throw Object.assign(new Error("sequenceServiceUnavailable"), { code: "sequenceServiceUnavailable" });
    const orderedIds = this.#gallery.sequences.map((sequence) => sequence.id);
    const index = orderedIds.indexOf(sequenceId);
    const target = index + delta;
    if (index < 0 || target < 0 || target >= orderedIds.length) return;
    [orderedIds[index], orderedIds[target]] = [orderedIds[target], orderedIds[index]];
    await this.#sequenceService.reorder(this.#actor, orderedIds);
    this.#gallery = this.#repository.read(this.#actor);
    this.#renderAll();
    notify("info", "notifications.sequenceReordered");
  }

  async #removeSequence(sequenceId) {
    if (!this.#sequenceService) throw Object.assign(new Error("sequenceServiceUnavailable"), { code: "sequenceServiceUnavailable" });
    const sequence = this.#gallery.sequences.find((candidate) => candidate.id === sequenceId);
    if (!sequence) return;
    const confirmed = await confirmAction({ title: localize("sequences.removeTitle"), content: `<p>${escapeHtml(localize("sequences.removeContent", { name: sequence.name }))}</p>` });
    if (!confirmed) return;
    await this.#sequenceService.remove(this.#actor, sequenceId);
    this.#gallery = this.#repository.read(this.#actor);
    if (this.#sequenceEditing?.id === sequenceId) this.#sequenceEditing = null;
    this.#renderAll();
    notify("info", "notifications.sequenceRemoved");
  }

  async #navigateSequence(sequenceId, action) {
    if (!this.#sequenceService) throw Object.assign(new Error("sequenceServiceUnavailable"), { code: "sequenceServiceUnavailable" });
    const target = this.#state.applyTarget;
    if (!target || target === APPLY_TARGETS.ASK) throw Object.assign(new Error("chooseTarget"), { code: "chooseTarget" });
    if (this.#gallery.temporaryState) {
      const confirmed = await confirmAction({ title: localize("temporary.commitTitle"), content: `<p>${escapeHtml(localize("temporary.commitContent"))}</p>` });
      if (!confirmed) return;
    }
    const result = await this.#sequenceService.navigate(this.#actor, sequenceId, action, { token: this.#token, target });
    this.#gallery = this.#repository.read(this.#actor);
    await this.render({ force: true });
    notify("info", result.atBoundary ? "notifications.sequenceBoundary" : "notifications.sequenceApplied", { position: result.position, total: result.total, label: result.label ?? "" });
  }

  async #saveProfile() {
    if (!this.#profileService) throw Object.assign(new Error("profileServiceUnavailable"), { code: "profileServiceUnavailable" });
    const form = this.#shell()?.querySelector("[data-role='profile-form']");
    if (!form) return;
    const data = new FormData(form);
    const tokenVisual = {};
    for (const key of ["scale", "width", "height", "alpha"]) {
      const value = String(data.get(key) ?? "").trim();
      if (value) tokenVisual[key] = Number(value);
    }
    const tint = String(data.get("tint") ?? "").trim();
    if (tint) tokenVisual.tint = tint;
    const profile = {
      name: String(data.get("name") ?? "").trim(),
      description: String(data.get("description") ?? "").trim(),
      tags: String(data.get("tags") ?? ""),
      category: String(data.get("category") ?? "").trim(),
      portrait: profileReferenceFromValue(data.get("portrait")),
      token: profileReferenceFromValue(data.get("token")),
      prototypeToken: data.has("prototypeToken"),
      sceneTokens: data.has("sceneTokens"),
      tokenVisual
    };
    if (this.#profileEditingId === "__new") await this.#profileService.create(this.#actor, profile);
    else await this.#profileService.update(this.#actor, this.#profileEditingId, profile);
    this.#gallery = this.#repository.read(this.#actor);
    this.#profileEditingId = null;
    this.#renderAll();
    notify("info", "notifications.profileSaved");
  }

  async #applyProfile(profileId) {
    if (!this.#profileService) throw Object.assign(new Error("profileServiceUnavailable"), { code: "profileServiceUnavailable" });
    if (this.#gallery.temporaryState) {
      const confirmed = await confirmAction({
        title: localize("temporary.commitTitle"),
        content: `<p>${escapeHtml(localize("temporary.commitContent"))}</p>`
      });
      if (!confirmed) return;
    }
    await this.#profileService.apply(this.#actor, profileId);
    this.#gallery = this.#repository.read(this.#actor);
    await this.render({ force: true });
    notify("info", "notifications.profileApplied");
  }

  async #removeProfile(profileId) {
    if (!this.#profileService) throw Object.assign(new Error("profileServiceUnavailable"), { code: "profileServiceUnavailable" });
    const profile = this.#gallery.profiles.find((candidate) => candidate.id === profileId);
    if (!profile) return;
    const confirmed = await confirmAction({
      title: localize("profiles.removeTitle"),
      content: `<p>${escapeHtml(localize("profiles.removeContent", { name: profile.name }))}</p>`
    });
    if (!confirmed) return;
    await this.#profileService.remove(this.#actor, profileId);
    this.#gallery = this.#repository.read(this.#actor);
    if (this.#profileEditingId === profileId) this.#profileEditingId = null;
    this.#renderAll();
    notify("info", "notifications.profileRemoved");
  }

  #toggleBackupPanel(open) {
    const panel = this.#shell()?.querySelector("[data-role='backup-panel']");
    if (!panel) return;
    panel.hidden = !open;
    if (open) panel.querySelector("button, select")?.focus();
  }

  #exportActorBackup() {
    if (!this.#backupService) throw Object.assign(new Error("backupUnavailable"), { code: "backupUnavailable" });
    const envelope = this.#backupService.exportActor(this.#actor);
    downloadBackup(envelope, `actor-image-gallery-${this.#actor.name}`);
    notify("info", "notifications.backupExported");
  }

  async #importActorBackup(file) {
    if (!this.#backupService) throw Object.assign(new Error("backupUnavailable"), { code: "backupUnavailable" });
    const strategy = this.#shell()?.querySelector("[data-role='backup-strategy']")?.value ?? "skip";
    const confirmed = await confirmAction({
      title: localize("backup.importTitle"),
      content: `<p>${escapeHtml(localize("backup.importConfirm", { strategy: importStrategyLabel(strategy) }))}</p>`
    });
    if (!confirmed) return;
    const content = await readBackupFile(file);
    const result = await this.#backupService.importActor(this.#actor, content, { strategy });
    this.#gallery = result.gallery;
    if (!this.#gallery.entries.some((entry) => entry.id === this.#state.selectedId)) this.#state.selectedId = this.#gallery.entries[0]?.id ?? null;
    this.#toggleBackupPanel(false);
    this.#renderAll();
    notify("info", "notifications.backupImported", result.report);
  }

  #togglePaletteEditor(open) {
    const editor = this.#shell()?.querySelector("[data-role='palette-editor']");
    if (!editor) return;
    editor.hidden = !open;
    if (open) editor.querySelector("input[type='color']")?.focus();
  }

  #paletteFromInputs() {
    const editor = this.#shell()?.querySelector("[data-role='palette-editor']");
    const palette = {};
    for (const key of PALETTE_FIELDS) palette[key] = editor?.querySelector(`[data-palette-key='${key}']`)?.value;
    return normalizePalette(palette);
  }

  #setPaletteInputs(input) {
    const palette = normalizePalette(input);
    const editor = this.#shell()?.querySelector("[data-role='palette-editor']");
    for (const key of PALETTE_FIELDS) {
      const control = editor?.querySelector(`[data-palette-key='${key}']`);
      if (control) {
        control.value = palette[key];
        const code = control.closest("label")?.querySelector("code");
        if (code) code.textContent = palette[key];
      }
    }
  }

  #applyPalette(input) {
    const palette = applyPalette(globalThis.document?.documentElement, input);
    applyPalette(this.element, palette);
    applyPalette(this.#shell(), palette);
  }

  async #savePalette() {
    const palette = this.#paletteFromInputs();
    await setSetting("customPalette", serializePalette(palette));
    this.#applyPalette(palette);
    this.#togglePaletteEditor(false);
    notify("info", "notifications.paletteSaved");
  }

  async #reorder(draggedId, targetId = null, placement = "before", baseIds = null) {
    const currentIds = this.#gallery.entries.slice().sort((left, right) => left.manualOrder - right.manualOrder).map((entry) => entry.id);
    const baseline = Array.isArray(baseIds)
      && baseIds.length === currentIds.length
      && currentIds.every((id) => baseIds.includes(id))
      ? baseIds
      : currentIds;
    const ids = reorderEntryIds(baseline, draggedId, targetId, placement);
    if (ids.every((id, index) => id === currentIds[index])) return;
    const result = await this.#repository.mutate(this.#actor, (gallery) => reorderEntries(gallery, ids));
    this.#gallery = result.gallery;
    this.#state.sort = SORT_MODES.MANUAL;
    await setSetting("gallerySort", SORT_MODES.MANUAL);
    const sort = this.#shell()?.querySelector("[data-role='sort']");
    if (sort) sort.value = SORT_MODES.MANUAL;
    this.#renderEntries();
  }

  async #browseSource(button) {
    const input = this.#shell()?.querySelector("input[name='source']");
    const FilePicker = getFilePickerClass();
    if (!FilePicker || !input) throw Object.assign(new Error("filePickerUnavailable"), { code: "filePickerUnavailable" });
    const picker = new FilePicker({
      type: "image",
      current: input.value,
      field: input,
      button,
      callback: (path) => {
        input.value = path;
        input.dispatchEvent(new Event("change", { bubbles: true }));
      }
    });
    await picker.browse();
  }

  #reuseSource() {
    const select = this.#shell()?.querySelector("[data-role='reuse-source']");
    const input = this.#shell()?.querySelector("input[name='source']");
    if (!select?.value || !input) return;
    input.value = select.value;
    input.dispatchEvent(new Event("change", { bubbles: true }));
  }

  async #addLocalFiles(files) {
    for (const file of files) {
      const source = await uploadLocalFile(this.#actor, file);
      await this.#addSource(source, sourceName(file.name));
    }
  }

  async #useLocalFileInEditor(file) {
    const source = await uploadLocalFile(this.#actor, file);
    const input = this.#shell()?.querySelector("input[name='source']");
    if (!input || !this.#editing) return;
    input.value = source;
    this.#editing.source = source;
    if (!this.#shell()?.querySelector("input[name='name']")?.value) {
      const nameInput = this.#shell()?.querySelector("input[name='name']");
      if (nameInput) nameInput.value = sourceName(file.name);
    }
    const image = this.#shell()?.querySelector("[data-role='editor-image']");
    if (image) image.src = source;
  }

  async #addSource(source, name = sourceName(source)) {
    const result = await this.#repository.mutate(this.#actor, (gallery) => addEntry(gallery, { source, name }));
    this.#gallery = result.gallery;
    this.#state.selectedId = result.value?.id ?? this.#state.selectedId;
    this.#renderAll();
    notify("info", "notifications.added");
  }

  #editorAction(action) {
    if (!this.#editing) return;
    const preset = this.#editing[this.#editingKind];
    if (action === "fit-contain") preset.fit = IMAGE_FITS.CONTAIN;
    else if (action === "fit-cover") preset.fit = IMAGE_FITS.COVER;
    else if (action === "zoom-in") preset.zoom = clamp(preset.zoom + 0.1, 0.5, 4);
    else if (action === "zoom-out") preset.zoom = clamp(preset.zoom - 0.1, 0.5, 4);
    else if (action === "rotate-left") preset.rotation -= 90;
    else if (action === "rotate-right") preset.rotation += 90;
    else if (action === "flip-horizontal") preset.flipX = !preset.flipX;
    else if (action === "flip-vertical") preset.flipY = !preset.flipY;
    else if (action === "reset-preset") this.#editing[this.#editingKind] = createPreset();
    this.#renderInspector();
  }

  #refreshEditorPreview() {
    if (!this.#editing) return;
    const image = this.#shell()?.querySelector("[data-role='editor-image']");
    if (!image) return;
    const style = presetCss(this.#editing[this.#editingKind]);
    image.style.objectFit = style.objectFit;
    image.style.transform = style.transform;
    image.style.filter = style.filter;
    const zoom = this.#shell()?.querySelector("[data-editor-control='zoom']");
    if (zoom) zoom.value = String(Math.round(this.#editing[this.#editingKind].zoom * 100));
  }

  #layoutActionsHtml({ includeExpand = false } = {}) {
    const moveKey = this.#state.inspectorSide === "right" ? "layout.moveLeft" : "layout.moveRight";
    const moveIcon = this.#state.inspectorSide === "right" ? "fa-arrow-left" : "fa-arrow-right";
    const expandKey = this.#state.editorExpanded ? "layout.restoreEditor" : "layout.expandEditor";
    const expandIcon = this.#state.editorExpanded ? "fa-compress" : "fa-expand";
    return `${includeExpand ? `<button type="button" class="aig-icon-button" data-action="toggle-editor-expand" title="${escapeAttribute(localize(expandKey))}" aria-pressed="${this.#state.editorExpanded}"><i class="fa-solid ${expandIcon}"></i></button>` : ""}<button type="button" class="aig-icon-button" data-action="toggle-inspector-side" title="${escapeAttribute(localize(moveKey))}"><i class="fa-solid ${moveIcon}"></i></button>`;
  }

  #resizePanel(panel, startWidth, deltaX) {
    const shell = this.#shell();
    if (!shell) return;
    const isLeftPane = (panel === "sidebar") !== (this.#state.inspectorSide === "left");
    const requested = startWidth + (isLeftPane ? deltaX : -deltaX);
    const otherWidth = panel === "sidebar" ? this.#state.inspectorWidth : this.#state.sidebarWidth;
    const minimum = panel === "sidebar" ? 120 : 260;
    const configuredMaximum = panel === "sidebar" ? 360 : 720;
    const availableMaximum = Math.max(minimum, shell.clientWidth - otherWidth - 300);
    this.#state[`${panel}Width`] = clamp(requested, minimum, Math.min(configuredMaximum, availableMaximum));
  }

  #applyPanelLayout() {
    const shell = this.#shell();
    if (!shell) return;
    shell.dataset.inspectorSide = this.#state.inspectorSide;
    shell.classList.toggle("is-editor-expanded", this.#state.editorExpanded && Boolean(this.#editing));
    shell.style.setProperty("--aig-sidebar-width", `${Math.round(this.#state.sidebarWidth)}px`);
    shell.style.setProperty("--aig-inspector-width", `${Math.round(this.#state.inspectorWidth)}px`);
    const sidebar = shell.querySelector("[data-resize-panel='sidebar']");
    const inspector = shell.querySelector("[data-resize-panel='inspector']");
    sidebar?.setAttribute("aria-valuenow", String(Math.round(this.#state.sidebarWidth)));
    inspector?.setAttribute("aria-valuenow", String(Math.round(this.#state.inspectorWidth)));
  }

  #rerenderContent() {
    const shell = this.#shell();
    if (!shell) return;
    const favorite = shell.querySelector("[data-action='toggle-favorites']");
    favorite?.classList.toggle("is-active", this.#state.favoritesOnly);
    favorite?.setAttribute("aria-pressed", String(this.#state.favoritesOnly));
    this.#renderFacets();
    this.#renderEntries();
  }

  #hydrateThumbnails(container) {
    this.#observer?.disconnect();
    const load = (image) => {
      const source = image.dataset.thumbSource;
      if (!source) return;
      delete image.dataset.thumbSource;
      void this.#thumbnails.get(source).then((thumbnail) => { if (image.isConnected) image.src = thumbnail; });
    };
    if (!globalThis.IntersectionObserver) {
      container.querySelectorAll("img[data-thumb-source]").forEach(load);
      return;
    }
    this.#observer = new IntersectionObserver((entries, observer) => {
      for (const observed of entries) if (observed.isIntersecting) {
        observer.unobserve(observed.target);
        load(observed.target);
      }
    }, { root: container.closest(".aig-gallery"), rootMargin: "240px" });
    container.querySelectorAll("img[data-thumb-source]").forEach((image) => this.#observer.observe(image));
  }

  #visibleEntries() {
    return queryEntries(this.#gallery, this.#state);
  }

  #selectedEntry() {
    return this.#gallery.entries.find((entry) => entry.id === this.#state.selectedId) ?? null;
  }

  #currentStates(entry) {
    const features = featureFlags(this.#gallery);
    const sources = new Set([entry.source, entry.derived?.portrait?.source, entry.derived?.token?.source].filter(Boolean));
    const result = [];
    if (features.portrait && sources.has(this.#actor.img)) result.push(localize("current.portrait"));
    if (features.token && sources.has(this.#actor.prototypeToken?.texture?.src)) result.push(localize("current.prototype"));
    const token = getActiveTokenForActor(this.#actor, this.#token);
    if (features.token && sources.has(token?.document?.texture?.src)) result.push(localize("current.token"));
    return result;
  }

  #canEdit() {
    return actorCanUpdate(this.#actor);
  }

  #profilesAvailable() {
    return Boolean(this.#profileService && this.#hasCapability?.(CAPABILITIES.APPEARANCE_PROFILES));
  }

  #sequencesAvailable() {
    return Boolean(this.#sequenceService && this.#hasCapability?.(CAPABILITIES.APPEARANCE_SEQUENCES));
  }

  #automationAvailable() {
    return Boolean(this.#openAutomationManager && this.#hasCapability?.(CAPABILITIES.AUTOMATION_RULES));
  }

  #shell() {
    return this.element?.querySelector?.(".aig-shell") ?? null;
  }

  #handleError(error) {
    warn("Gallery action failed.", error);
    const key = {
      permissionDenied: "errors.permissionDenied",
      sourceRequired: "errors.sourceRequired",
      entryNotFound: "errors.entryNotFound",
      tokenRequired: "errors.tokenRequired",
      sceneTokensRequired: "errors.sceneTokensRequired",
      featureDisabled: "errors.featureDisabled",
      tokenDisabledForGallery: "errors.tokenDisabledForGallery",
      filePickerUnavailable: "errors.filePickerUnavailable",
      uploadUnavailable: "errors.uploadUnavailable",
      invalidTarget: "errors.invalidTarget",
      chooseTarget: "errors.chooseTarget",
      temporaryNotActive: "errors.temporaryNotActive",
      backupInvalid: "errors.backupInvalid",
      backupJsonInvalid: "errors.backupJsonInvalid",
      backupFormatInvalid: "errors.backupFormatInvalid",
      backupVersionUnsupported: "errors.backupVersionUnsupported",
      backupScopeInvalid: "errors.backupScopeInvalid",
      backupPayloadInvalid: "errors.backupPayloadInvalid",
      backupStrategyInvalid: "errors.backupStrategyInvalid",
      backupFileInvalid: "errors.backupFileInvalid",
      backupFileTooLarge: "errors.backupFileTooLarge",
      backupDownloadUnavailable: "errors.backupDownloadUnavailable",
      backupUnavailable: "errors.backupUnavailable",
      profileNameRequired: "errors.profileNameRequired",
      profileSourceRequired: "errors.profileSourceRequired",
      profileNotFound: "errors.profileNotFound",
      profileReferenceMissing: "errors.profileReferenceMissing",
      profileNoApplicableChanges: "errors.profileNoApplicableChanges",
      profileServiceUnavailable: "errors.profileServiceUnavailable",
      capabilityRequired: "errors.proRequiredGeneric",
      sequenceNameRequired: "errors.sequenceNameRequired",
      sequenceStepsRequired: "errors.sequenceStepsRequired",
      sequenceNotFound: "errors.sequenceNotFound",
      sequenceStepInvalid: "errors.sequenceStepInvalid",
      sequenceOrderInvalid: "errors.sequenceOrderInvalid",
      sequenceTargetMissing: "errors.sequenceTargetMissing",
      sequenceServiceUnavailable: "errors.sequenceServiceUnavailable"
    }[error?.code] ?? "errors.actionFailed";
    notify("error", key);
  }
}

function rangeHtml(key, label, value, min, max, unit, step = 1) {
  return `<label class="aig-range"><span>${escapeHtml(label)}</span><input type="range" min="${min}" max="${max}" step="${step}" value="${value}" data-editor-control="${key}" data-unit="${escapeAttribute(unit)}"><output>${value}${escapeHtml(unit)}</output></label>`;
}

function sortOptions(selected) {
  return [
    [SORT_MODES.MANUAL, "sort.manual"],
    [SORT_MODES.NAME, "sort.name"],
    [SORT_MODES.RECENT, "sort.recent"],
    [SORT_MODES.USED, "sort.used"],
    [SORT_MODES.FAVORITES, "sort.favorites"]
  ].map(([value, key]) => `<option value="${value}" ${selected === value ? "selected" : ""}>${escapeHtml(localize(key))}</option>`).join("");
}

function applyTargetOptions(selected, features = featureFlags()) {
  const options = [
    [APPLY_TARGETS.PORTRAIT, "targets.portrait"],
    [APPLY_TARGETS.PROTOTYPE, "targets.prototype"],
    [APPLY_TARGETS.CURRENT_TOKEN, "targets.currentToken"],
    [APPLY_TARGETS.SCENE_TOKENS, "targets.sceneTokens"],
    [APPLY_TARGETS.PORTRAIT_PROTOTYPE, "targets.portraitPrototype"],
    [APPLY_TARGETS.PORTRAIT_CURRENT, "targets.portraitCurrent"],
    [APPLY_TARGETS.EVERYTHING, "targets.everything"]
  ].filter(([value]) => targetAllowed(value, features));
  if (!options.length) return `<option value="">${escapeHtml(localize("targets.disabled"))}</option>`;
  if (selected && !options.some(([value]) => value === selected)) selected = options[0][0];
  const html = options.map(([value, key]) => `<option value="${value}" ${selected === value ? "selected" : ""}>${escapeHtml(localize(key))}</option>`).join("");
  return selected ? html : `<option value="" selected disabled>${escapeHtml(localize("actions.chooseTarget"))}</option>${html}`;
}

function paletteEditorHtml(input) {
  const palette = normalizePalette(input);
  const controls = PALETTE_FIELDS.map((key) => `
    <label class="aig-palette-field">
      <input type="color" value="${escapeAttribute(palette[key])}" data-palette-key="${key}">
      <span>${escapeHtml(localize(`palette.${key}`))}</span>
      <code>${escapeHtml(palette[key])}</code>
    </label>
  `).join("");
  return `
    <section class="aig-palette-editor" data-role="palette-editor" hidden aria-label="${escapeAttribute(localize("palette.title"))}">
      <header><div><span class="aig-kicker">${escapeHtml(localize("palette.kicker"))}</span><h2>${escapeHtml(localize("palette.title"))}</h2></div><button type="button" class="aig-icon-button" data-action="palette-cancel" title="${escapeAttribute(localize("common.close"))}"><i class="fa-solid fa-xmark"></i></button></header>
      <div class="aig-palette-grid">${controls}</div>
      <footer><button type="button" class="aig-button" data-action="palette-reset"><i class="fa-solid fa-arrow-rotate-left"></i>${escapeHtml(localize("palette.reset"))}</button><button type="button" class="aig-button aig-button--signal" data-action="palette-save"><i class="fa-solid fa-floppy-disk"></i>${escapeHtml(localize("common.save"))}</button></footer>
    </section>
  `;
}

function backupPanelHtml(canImport) {
  return `<section class="aig-backup-panel" data-role="backup-panel" hidden>
    <header><div><span class="aig-kicker">${escapeHtml(localize("backup.kicker"))}</span><h2>${escapeHtml(localize("backup.actorTitle"))}</h2></div><button type="button" class="aig-icon-button" data-action="backup-close" title="${escapeAttribute(localize("common.close"))}"><i class="fa-solid fa-xmark"></i></button></header>
    <p>${escapeHtml(localize("backup.metadataOnlyHint"))}</p>
    <button type="button" class="aig-button aig-button--wide" data-action="backup-export-actor"><i class="fa-solid fa-file-export"></i><span>${escapeHtml(localize("backup.exportActor"))}</span></button>
    <label class="aig-field"><span>${escapeHtml(localize("backup.conflictStrategy"))}</span><select data-role="backup-strategy">${importStrategyOptions()}</select></label>
    <button type="button" class="aig-button aig-button--signal aig-button--wide" data-action="backup-import-actor" ${disabledIf(!canImport)}><i class="fa-solid fa-file-import"></i><span>${escapeHtml(localize("backup.importActor"))}</span></button>
    <p class="aig-backup-panel__safety"><i class="fa-solid fa-shield-halved"></i>${escapeHtml(localize("backup.nonDestructiveHint"))}</p>
  </section>`;
}

function profilePanelHeader() {
  return `<header><div><span class="aig-kicker">${escapeHtml(localize("profiles.kicker"))}</span><h2>${escapeHtml(localize("profiles.title"))}</h2></div><button type="button" class="aig-icon-button" data-action="profiles-close" title="${escapeAttribute(localize("common.close"))}"><i class="fa-solid fa-xmark"></i></button></header>`;
}

function sequencePanelHeader() {
  return `<header><div><span class="aig-kicker">${escapeHtml(localize("sequences.kicker"))}</span><h2>${escapeHtml(localize("sequences.title"))}</h2></div><button type="button" class="aig-icon-button" data-action="sequences-close" title="${escapeAttribute(localize("common.close"))}"><i class="fa-solid fa-xmark"></i></button></header>`;
}

function sequenceModeOptions(selected) {
  return Object.values(SEQUENCE_MODES).map((mode) => `<option value="${mode}" ${selected === mode ? "selected" : ""}>${escapeHtml(localize(`sequences.modes.${mode}`))}</option>`).join("");
}

function sequenceTargetOptions(step, gallery) {
  const targets = step.targetType === "profile" ? gallery.profiles : gallery.entries;
  if (!targets.length) return `<option value="">${escapeHtml(localize("sequences.noTargets"))}</option>`;
  return targets.map((item) => `<option value="${escapeAttribute(item.id)}" ${item.id === step.targetId ? "selected" : ""}>${escapeHtml(item.name)}</option>`).join("");
}

function sequenceStepLabel(step, gallery) {
  if (!step) return "";
  const targets = step.targetType === "profile" ? gallery.profiles : gallery.entries;
  return step.label || targets.find((item) => item.id === step.targetId)?.name || localize("sequences.unresolved");
}

function defaultSequenceStep(gallery) {
  if (gallery.entries[0]) return { label: "", targetType: "entry", targetId: gallery.entries[0].id };
  if (gallery.profiles[0]) return { label: "", targetType: "profile", targetId: gallery.profiles[0].id };
  return null;
}

function profileSourceOptions(reference, entries, allowEmpty = false) {
  const selected = reference?.entryId ? `entry:${reference.entryId}` : reference?.source ? `source:${reference.source}` : "";
  const options = [];
  if (allowEmpty) options.push(`<option value="" ${selected ? "" : "selected"}>${escapeHtml(localize("profiles.noSource"))}</option>`);
  if (reference?.source && !reference?.entryId) options.push(`<option value="${escapeAttribute(selected)}" selected>${escapeHtml(localize("profiles.externalSource"))}</option>`);
  for (const entry of entries) {
    const value = `entry:${entry.id}`;
    options.push(`<option value="${escapeAttribute(value)}" ${selected === value ? "selected" : ""}>${escapeHtml(entry.name)}</option>`);
  }
  return options.join("");
}

function profileReferenceFromValue(value) {
  const normalized = String(value ?? "");
  if (normalized.startsWith("entry:")) return { entryId: normalized.slice(6) };
  if (normalized.startsWith("source:")) return { source: normalized.slice(7) };
  return null;
}

function profileNumberField(name, labelKey, value, min, max, step) {
  return `<label class="aig-field"><span>${escapeHtml(localize(labelKey))}</span><input type="number" name="${name}" min="${min}" max="${max}" step="${step}" value="${value ?? ""}" placeholder="—"></label>`;
}

function profileThumbnail(profile, entries) {
  const reference = profile.thumbnail || profile.portrait || profile.token;
  if (typeof reference === "string") return reference;
  if (reference?.source) return reference.source;
  if (reference?.entryId) return entries.find((entry) => entry.id === reference.entryId)?.source ?? "";
  return "";
}

function targetAllowed(target, features) {
  if ([APPLY_TARGETS.PORTRAIT].includes(target)) return features.portrait;
  if ([APPLY_TARGETS.PROTOTYPE, APPLY_TARGETS.CURRENT_TOKEN, APPLY_TARGETS.SCENE_TOKENS].includes(target)) return features.token;
  return features.portrait && features.token;
}

function chipHtml(action, value, label, active) {
  return `<button type="button" data-action="${action}" data-value="${escapeAttribute(value)}" class="${active ? "is-active" : ""}" aria-pressed="${active}">${escapeHtml(label)}</button>`;
}

function navButtonHtml(action, value, label, active, count) {
  return `<button type="button" data-action="${action}" data-value="${escapeAttribute(value)}" class="${active ? "is-active" : ""}" aria-pressed="${active}"><span>${escapeHtml(label)}</span><b>${count}</b></button>`;
}

function disabledIf(condition) {
  return condition ? "disabled" : "";
}

function formatDate(value) {
  if (!value) return "—";
  try {
    return new Intl.DateTimeFormat(globalThis.game?.i18n?.lang ?? undefined, { dateStyle: "medium" }).format(new Date(value));
  } catch {
    return value;
  }
}

function getSetting(key, fallback) {
  try {
    return globalThis.game?.settings?.get?.(MODULE_ID, key) ?? fallback;
  } catch {
    return fallback;
  }
}

function featureFlags(gallery = null) {
  return {
    portrait: Boolean(getSetting("enablePortraitFeatures", true)),
    token: Boolean(getSetting("enableTokenFeatures", true)) && !gallery?.ignoreTokenChanges
  };
}

async function setSetting(key, value) {
  try {
    await globalThis.game?.settings?.set?.(MODULE_ID, key, value);
  } catch (error) {
    warn(`Could not persist setting ${key}.`, error);
  }
}

function touchDistance(touches) {
  const [left, right] = Array.from(touches.values()).slice(0, 2);
  return Math.hypot(right.x - left.x, right.y - left.y);
}

function entryMatchesAppliedSource(entry, source, kind) {
  if (!entry || !source) return false;
  if ([entry.source, entry.derived?.[kind]?.source].filter(Boolean).includes(source)) return true;
  const cleanSource = String(source).split(/[?#]/, 1)[0].toLocaleLowerCase();
  return cleanSource.includes(`-${String(entry.id).toLocaleLowerCase()}-${kind}-`);
}

async function uploadLocalFile(actor, file) {
  const FilePicker = getFilePickerClass();
  if (!FilePicker) throw Object.assign(new Error("uploadUnavailable"), { code: "uploadUnavailable" });
  const filename = slugifyFilename(file.name);
  let response;
  if (typeof FilePicker.uploadPersistent === "function") {
    response = await FilePicker.uploadPersistent(MODULE_ID, `uploads/${actor.id}/${filename}`, file, {}, { notify: true });
  } else if (typeof FilePicker.upload === "function") {
    response = await FilePicker.upload("data", `${MODULE_ID}/uploads/${actor.id}`, file, {}, { notify: true });
  } else throw Object.assign(new Error("uploadUnavailable"), { code: "uploadUnavailable" });
  const source = response?.path ?? response?.src ?? response?.url;
  if (!source) throw Object.assign(new Error("uploadUnavailable"), { code: "uploadUnavailable" });
  return source;
}

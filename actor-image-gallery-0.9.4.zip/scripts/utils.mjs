import { MODULE_ID } from "./constants.mjs";
import { getDialogV2Class } from "./foundry/compatibility.mjs";

export function localize(key, data = null) {
  const fullKey = key.startsWith("AIG.") ? key : `AIG.${key}`;
  if (data) return globalThis.game?.i18n?.format?.(fullKey, data) ?? fullKey;
  return globalThis.game?.i18n?.localize?.(fullKey) ?? fullKey;
}

export function notify(level, key, data = null) {
  if (!notificationAllowed(level)) return;
  globalThis.ui?.notifications?.[level]?.(localize(key, data));
}

export function notificationAllowed(level, configuredLevel = null) {
  const preference = configuredLevel ?? getNotificationLevel();
  if (preference === "all") return true;
  if (preference === "warnings") return level === "warn" || level === "error";
  return level === "error";
}

export function warn(message, error = null) {
  console.warn(`${MODULE_ID} | ${message}`, error ?? "");
}

function getNotificationLevel() {
  try {
    return globalThis.game?.settings?.get?.(MODULE_ID, "notificationLevel") ?? "errors";
  } catch {
    return "errors";
  }
}

export function clamp(value, minimum, maximum) {
  const number = Number(value);
  if (!Number.isFinite(number)) return minimum;
  return Math.min(maximum, Math.max(minimum, number));
}

export function deepClone(value) {
  if (globalThis.foundry?.utils?.deepClone) return foundry.utils.deepClone(value);
  if (globalThis.structuredClone) return structuredClone(value);
  return JSON.parse(JSON.stringify(value));
}

export function randomId() {
  return globalThis.foundry?.utils?.randomID?.()
    ?? globalThis.crypto?.randomUUID?.()
    ?? `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
}

export function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

export function escapeAttribute(value) {
  return escapeHtml(value).replaceAll("`", "&#096;");
}

export function slugifyFilename(value) {
  return String(value ?? "image")
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-zA-Z0-9._-]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .toLowerCase()
    .slice(0, 80) || "image";
}

export function sourceName(source) {
  const clean = String(source ?? "").split(/[?#]/)[0];
  const raw = clean.split("/").at(-1) || localize("entry.untitled");
  try {
    return decodeURIComponent(raw).replace(/\.[a-z0-9]+$/i, "");
  } catch {
    return raw.replace(/\.[a-z0-9]+$/i, "");
  }
}

export function getActiveTokenForActor(actor, preferred = null) {
  if (preferred?.actor?.id === actor?.id || preferred?.document?.actorId === actor?.id) return preferred;
  return globalThis.canvas?.tokens?.controlled?.find?.((token) => token.actor?.id === actor?.id) ?? null;
}

export function actorCanUpdate(actor) {
  if (!actor) return false;
  if (actor.isOwner !== undefined) return Boolean(actor.isOwner);
  return Boolean(actor.testUserPermission?.(globalThis.game?.user, "OWNER"));
}

export async function confirmAction({ title, content, yes = "AIG.common.confirm", no = "AIG.common.cancel" }) {
  const DialogV2 = getDialogV2Class();
  if (DialogV2?.confirm) {
    return DialogV2.confirm({
      window: { title },
      content,
      yes: { label: localize(yes), icon: "fa-solid fa-check" },
      no: { label: localize(no), icon: "fa-solid fa-xmark" },
      modal: true
    });
  }
  if (globalThis.Dialog?.confirm) {
    return Dialog.confirm({ title, content, yes: () => true, no: () => false, defaultYes: false });
  }
  return globalThis.confirm?.(content.replace(/<[^>]*>/g, "")) ?? false;
}

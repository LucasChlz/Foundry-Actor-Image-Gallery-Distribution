import { CAPABILITIES, FEATURE_REGISTRY } from "./constants.mjs";

const VALID_TIERS = new Set(["free", "patreon"]);

export class EntitlementService {
  #provider;
  #status;

  constructor({ provider = new StaticEntitlementProvider(), initialStatus = null } = {}) {
    this.#provider = provider;
    this.#status = normalizeStatus(initialStatus ?? provider.cachedStatus?.() ?? {});
  }

  has(capability) {
    const feature = FEATURE_REGISTRY[capability];
    if (!feature) return false;
    if (feature.tier === "free") return true;
    return this.#status.tier === "patreon" && this.#status.state === "active";
  }

  tier() {
    return this.#status.tier;
  }

  status() {
    return Object.freeze({ ...this.#status });
  }

  capabilities() {
    return Object.freeze(Object.fromEntries(
      Object.keys(FEATURE_REGISTRY).map((capability) => [capability, this.has(capability)])
    ));
  }

  async refresh() {
    try {
      const next = await this.#provider.resolve();
      this.#status = normalizeStatus(next);
    } catch (error) {
      this.#status = normalizeStatus({
        tier: "free",
        state: "inactive",
        source: this.#status.source || "patreon-provider",
        error: String(error?.message ?? error ?? "entitlementUnavailable")
      });
    }
    return this.status();
  }
}

export class StaticEntitlementProvider {
  #status;
  #error;

  constructor(status = { tier: "free", state: "inactive", source: "static" }, { error = null } = {}) {
    this.#status = normalizeStatus(status);
    this.#error = error;
  }

  cachedStatus() {
    return this.#status;
  }

  async resolve() {
    if (this.#error) throw this.#error;
    return this.#status;
  }
}

export class FoundryPatreonEntitlementProvider {
  cachedStatus() {
    return this.#freeStatus();
  }

  async resolve() {
    return this.#freeStatus();
  }

  #freeStatus() {
    return {
      tier: "free",
      state: "inactive",
      source: "patreon-not-connected",
      checkedAt: Date.now()
    };
  }
}

export function createFoundryEntitlementService({ provider = new FoundryPatreonEntitlementProvider() } = {}) {
  return new EntitlementService({ provider });
}

export function assertCapability(entitlements, capability) {
  if (!entitlements?.has?.(capability)) throw new CapabilityError(capability);
}

export class CapabilityError extends Error {
  constructor(capability) {
    super("capabilityRequired");
    this.name = "CapabilityError";
    this.code = "capabilityRequired";
    this.capability = capability;
  }
}

export { CAPABILITIES, FEATURE_REGISTRY };

function normalizeStatus(input = {}) {
  const tier = VALID_TIERS.has(input.tier) ? input.tier : "free";
  const state = tier === "patreon" && input.state === "active" ? "active" : "inactive";
  return {
    tier,
    state,
    source: String(input.source ?? "default"),
    checkedAt: Number.isFinite(Number(input.checkedAt)) ? Number(input.checkedAt) : Date.now(),
    error: input.error ? String(input.error) : null
  };
}

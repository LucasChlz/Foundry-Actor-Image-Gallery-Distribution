import { APPLY_TARGETS, MODULE_ID } from "../constants.mjs";
import { getCollections, presetCss, queryEntries } from "../domain/gallery.mjs";
import { actorCanUpdate, deepClone, escapeAttribute, escapeHtml, localize, notify, warn } from "../utils.mjs";
import { applyPalette, DEFAULT_PALETTE } from "../palette.mjs";

const CAROUSEL_MODE = "carousel";

export class QuickSwitch {
  #repository;
  #applicator;
  #preloader;
  #extensions;
  #root = null;
  #actor = null;
  #token = null;
  #gallery = null;
  #entries = [];
  #selectedIndex = 0;
  #collection = "";
  #favoritesOnly = false;
  #busy = false;
  #outsideListener = null;
  #tokenPreview = null;
  #origin = "token";
  #anchor = null;
  #mode = CAROUSEL_MODE;
  #controllers = [];
  #openGallery;

  constructor({ repository, applicator, preloader, extensions = null, openGallery = null }) {
    this.#openGallery = openGallery;
    this.#repository = repository;
    this.#applicator = applicator;
    this.#preloader = preloader;
    this.#extensions = extensions;
  }

  async open(actorOrToken, { anchor = null, origin = null, token = null, mode = CAROUSEL_MODE } = {}) {
    const requestedMode = String(mode ?? CAROUSEL_MODE);
    if (requestedMode !== CAROUSEL_MODE && !this.#extensions?.providesQuickSwitchMode?.(requestedMode)) {
      warn(`Quick Switch mode "${requestedMode}" is not provided by an active companion module.`);
      return null;
    }
    const resolvedToken = token ?? resolveToken(actorOrToken);
    const actor = resolveActor(actorOrToken, resolvedToken);
    if (!actor) return null;
    this.close();
    this.#actor = actor;
    this.#token = resolvedToken;
    this.#origin = origin ?? (resolvedToken ? "token" : "sheet");
    this.#anchor = anchor;
    this.#mode = requestedMode;
    if (this.#origin === "sheet" && !getSetting("enablePortraitFeatures", true)) return null;
    if (this.#origin !== "sheet" && !getSetting("enablePortraitFeatures", true) && !getSetting("enableTokenFeatures", true)) return null;
    this.#gallery = this.#repository.read(actor);
    this.#controllers = this.#extensions?.createQuickSwitchControllers?.(this.#createExtensionView()) ?? [];
    this.#favoritesOnly = getSetting("quickFavoritesOnly", false);
    this.#collection = "";
    this.#refreshEntries();
    if (!this.#entries.length && this.#favoritesOnly) {
      this.#favoritesOnly = false;
      this.#refreshEntries();
    }
    // An empty gallery opens too, with a way to add the first image: silently refusing
    // looked like a broken button, because routine warnings are hidden by default.
    const previewKind = this.#previewKind();
    this.#selectedIndex = Math.max(0, this.#entries.findIndex((entry) => isCurrentEntry(entry, actor, resolvedToken, previewKind)));
    const root = document.createElement("section");
    root.className = this.#mode === CAROUSEL_MODE ? "aig-quick-switch" : `aig-quick-switch aig-quick-switch--${this.#mode}`;
    applyPalette(root, getSetting("customPalette", DEFAULT_PALETTE));
    root.dataset.reducedMotion = String(Boolean(getSetting("reducedMotion", false)));
    root.setAttribute("role", "dialog");
    root.setAttribute("aria-modal", "false");
    root.setAttribute("aria-label", localize("quick.title", { name: actor.name }));
    root.tabIndex = -1;
    root.addEventListener("click", (event) => void this.#onClick(event));
    root.addEventListener("pointerover", (event) => this.#onPointerOver(event));
    root.addEventListener("wheel", (event) => void this.#onWheel(event), { passive: false });
    root.addEventListener("keydown", (event) => void this.#onKeyDown(event));
    document.body.append(root);
    this.#root = root;
    this.#position(anchor);
    this.#render();
    root.focus();
    this.#outsideListener = (event) => {
      if (this.#root && !this.#root.contains(event.target) && !this.#anchor?.contains?.(event.target) && !event.target.closest?.(".aig-token-hud-button, .aig-sheet-portrait-trigger, .aig-sheet-launch--quick")) this.close();
    };
    setTimeout(() => document.addEventListener("pointerdown", this.#outsideListener), 0);
    if (getSetting("preloadFavorites", true)) void this.#preloader.preload(this.#entries);
    return root;
  }

  close() {
    if (this.#outsideListener) document.removeEventListener("pointerdown", this.#outsideListener);
    this.#outsideListener = null;
    this.#root?.remove();
    this.#tokenPreview?.remove();
    for (const { id, controller } of this.#controllers) {
      try {
        controller.dispose?.();
      } catch (error) {
        warn(`Extension ${id} could not release its Quick Switch controller.`, error);
      }
    }
    this.#controllers = [];
    this.#root = null;
    this.#tokenPreview = null;
    this.#actor = null;
    this.#token = null;
    this.#gallery = null;
    this.#entries = [];
    this.#busy = false;
    this.#origin = "token";
    this.#anchor = null;
    this.#mode = CAROUSEL_MODE;
  }

  get openState() {
    return Boolean(this.#root);
  }

  get mode() {
    return this.#root ? this.#mode : null;
  }

  #render() {
    if (!this.#root) return;
    const selected = this.#entries[this.#selectedIndex];
    if (!selected) {
      this.#tokenPreview?.remove();
      this.#tokenPreview = null;
      const header = `<header class="aig-quick__header"><div><span>${escapeHtml(localize(this.#origin === "sheet" ? "quick.portraitKicker" : "quick.kicker"))}</span><h2>${escapeHtml(this.#actor.name)}</h2></div><button type="button" data-action="close" title="${escapeAttribute(localize("common.close"))}"><i class="fa-solid fa-xmark"></i></button></header>`;
      this.#root.innerHTML = `${header}${this.#extensionSectionsHtml()}${this.#gallery?.entries?.length ? `<div class="aig-quick__empty">${escapeHtml(localize("gallery.noResults"))}</div>` : this.#emptyGalleryHtml()}`;
      this.#bindExtensionSections();
      return;
    }
    if (this.#mode !== CAROUSEL_MODE) {
      this.#renderExtensionMode(selected);
      return;
    }
    const collections = getCollections(this.#gallery);
    const previewKind = this.#previewKind();
    const css = presetCss(selected[previewKind]);
    this.#root.innerHTML = `
      <header class="aig-quick__header">
        <div><span>${escapeHtml(localize(this.#origin === "sheet" ? "quick.portraitKicker" : "quick.kicker"))}</span><h2>${escapeHtml(this.#actor.name)}</h2></div>
        <button type="button" data-action="close" title="${escapeAttribute(localize("common.close"))}"><i class="fa-solid fa-xmark"></i></button>
      </header>
      <div class="aig-quick__filters">
        <button type="button" data-action="favorites" class="${this.#favoritesOnly ? "is-active" : ""}" aria-pressed="${this.#favoritesOnly}"><i class="fa-solid fa-star"></i>${escapeHtml(localize("actions.favoritesOnly"))}</button>
        ${collections.length ? `<select data-role="quick-collection" aria-label="${escapeAttribute(localize("entry.collection"))}"><option value="">${escapeHtml(localize("common.all"))}</option>${collections.map((collection) => `<option value="${escapeAttribute(collection)}" ${this.#collection === collection ? "selected" : ""}>${escapeHtml(collection)}</option>`).join("")}</select>` : ""}
      </div>
      ${this.#extensionSectionsHtml()}
      <div class="aig-quick__preview">
        <div class="aig-quick__preview-frame"><img src="${escapeAttribute(selected.source)}" alt="${escapeAttribute(selected.name)}" style="object-fit:${escapeAttribute(css.objectFit)};transform:${escapeAttribute(css.transform)};filter:${escapeAttribute(css.filter)}"></div>
        <div><span>${escapeHtml(localize("quick.ready"))}</span><strong>${escapeHtml(selected.name)}</strong><small>${escapeHtml(selected.collection || selected.tags.join(" · ") || localize("entry.uncategorized"))}</small></div>
      </div>
      <div class="aig-quick__carousel" data-role="quick-carousel">
        <button type="button" data-action="previous" title="${escapeAttribute(localize("quick.previous"))}"><i class="fa-solid fa-chevron-left"></i></button>
        <div class="aig-quick__items">${this.#entries.map((entry, index) => `
          <button type="button" data-action="choose" data-index="${index}" class="${index === this.#selectedIndex ? "is-selected" : ""}" aria-current="${index === this.#selectedIndex ? "true" : "false"}">
            <img src="${escapeAttribute(entry.source)}" loading="lazy" alt=""><span>${escapeHtml(entry.name)}</span>${entry.favorite ? `<i class="fa-solid fa-star"></i>` : ""}
          </button>
        `).join("")}</div>
        <button type="button" data-action="next" title="${escapeAttribute(localize("quick.next"))}"><i class="fa-solid fa-chevron-right"></i></button>
      </div>
      <footer class="aig-quick__footer">
        <span><i class="fa-solid fa-computer-mouse"></i>${escapeHtml(localize("quick.wheelHint"))}</span>
        <button type="button" class="aig-button aig-button--signal" data-action="confirm" ${this.#busy ? "disabled" : ""}><i class="fa-solid fa-check"></i>${escapeHtml(localize("quick.apply"))}</button>
      </footer>
    `;
    const selectedButton = this.#root.querySelector(".aig-quick__items .is-selected");
    selectedButton?.scrollIntoView?.({ behavior: getSetting("reducedMotion", false) ? "auto" : "smooth", inline: "center", block: "nearest" });
    const collectionSelect = this.#root.querySelector("[data-role='quick-collection']");
    collectionSelect?.addEventListener("change", () => {
      this.#collection = collectionSelect.value;
      this.#refreshEntries();
      this.#selectedIndex = 0;
      this.#render();
    });
    this.#bindExtensionSections();
    if (previewKind === "token") this.#renderTokenPreview(selected, css);
    else {
      this.#tokenPreview?.remove();
      this.#tokenPreview = null;
    }
  }

  #renderExtensionMode(selected) {
    const previewKind = this.#previewKind();
    const css = presetCss(selected[previewKind]);
    const provider = this.#modeProvider();
    let html = "";
    try {
      html = String(provider?.controller.renderMode?.(this.#mode, selected) ?? "");
    } catch (error) {
      warn(`Extension ${provider?.id ?? "unknown"} could not render the ${this.#mode} Quick Switch mode.`, error);
    }
    this.#root.innerHTML = html;
    if (previewKind === "token") this.#renderTokenPreview(selected, css);
    else {
      this.#tokenPreview?.remove();
      this.#tokenPreview = null;
    }
  }

  async #onClick(event) {
    const button = event.target.closest?.("[data-action]");
    if (!button) return;
    const action = button.dataset.action;
    if (action === "close") this.close();
    else if (action === "favorites") {
      this.#favoritesOnly = !this.#favoritesOnly;
      await setSetting("quickFavoritesOnly", this.#favoritesOnly);
      this.#refreshEntries();
      if (!this.#entries.length) {
        this.#favoritesOnly = false;
        await setSetting("quickFavoritesOnly", false);
        this.#refreshEntries();
        notify("warn", "quick.noFavorites");
      }
      this.#selectedIndex = 0;
      this.#render();
    } else if (action === "previous") await this.#step(-1);
    else if (action === "next") await this.#step(1);
    else if (action === "choose") {
      this.#selectedIndex = Number(button.dataset.index);
      if (this.#mode !== CAROUSEL_MODE || getSetting("quickConfirmMode", "confirm") === "instant") await this.#commit();
      else this.#render();
    } else if (action === "confirm") await this.#commit();
    else if (action === "empty-add" || action === "empty-gallery") {
      const actor = this.#actor;
      const token = this.#token;
      this.close();
      await this.#openGallery?.(actor, { token, newEntry: action === "empty-add" });
    } else await this.#dispatchExtensionAction(action, button, event);
  }

  #emptyGalleryHtml() {
    const canAdd = Boolean(this.#openGallery) && actorCanUpdate(this.#actor);
    return `<div class="aig-quick__empty aig-quick__empty--gallery">
      <i class="fa-solid fa-images" aria-hidden="true"></i>
      <strong>${escapeHtml(localize("quick.empty"))}</strong>
      <p>${escapeHtml(localize(canAdd ? "quick.emptyHint" : "quick.emptyReadOnly"))}</p>
      <div class="aig-quick__empty-actions">
        ${canAdd ? `<button type="button" class="aig-button aig-button--signal" data-action="empty-add"><i class="fa-solid fa-upload" aria-hidden="true"></i>${escapeHtml(localize("quick.addFirst"))}</button>` : ""}
        ${this.#openGallery ? `<button type="button" class="aig-button" data-action="empty-gallery"><i class="fa-solid fa-images" aria-hidden="true"></i>${escapeHtml(localize("quick.openGallery"))}</button>` : ""}
      </div>
    </div>`;
  }

  #onPointerOver(event) {
    if (this.#mode === CAROUSEL_MODE || this.#busy) return;
    const provider = this.#modeProvider();
    try {
      provider?.controller.onPointerOver?.(event);
    } catch (error) {
      warn(`Extension ${provider?.id ?? "unknown"} failed to handle pointer movement.`, error);
    }
  }

  async #onWheel(event) {
    if (!this.#root || this.#busy) return;
    event.preventDefault();
    await this.#step(event.deltaY > 0 ? 1 : -1);
  }

  // Handled keys stop here so Foundry does not also pan the canvas (arrows) or
  // close every open window (Escape).
  async #onKeyDown(event) {
    if (!["ArrowRight", "ArrowDown", "ArrowLeft", "ArrowUp", "Enter", "Escape"].includes(event.key)) return;
    if (event.target.closest?.("select, input, textarea") && event.key !== "Escape") return;
    event.preventDefault();
    event.stopPropagation();
    if (["ArrowRight", "ArrowDown"].includes(event.key)) await this.#step(1);
    else if (["ArrowLeft", "ArrowUp"].includes(event.key)) await this.#step(-1);
    else if (event.key === "Enter") await this.#commit();
    else this.close();
  }

  async #step(direction) {
    if (!this.#entries.length) return;
    this.#selectedIndex = (this.#selectedIndex + direction + this.#entries.length) % this.#entries.length;
    if (getSetting("quickConfirmMode", "confirm") === "instant") await this.#commit({ close: false });
    else this.#render();
  }

  async #commit({ close = true } = {}) {
    const entry = this.#entries[this.#selectedIndex];
    if (!entry || this.#busy) return;
    this.#busy = true;
    this.#render();
    try {
      const target = this.#resolveTarget();
      if (!target) throw Object.assign(new Error("featureDisabled"), { code: "featureDisabled" });
      const result = await this.#applicator.apply(this.#actor, entry, target, { token: this.#token });
      notify("info", result.temporaryCleared ? "notifications.temporaryCommitted" : "notifications.applied");
      if (close) this.close();
      else {
        this.#gallery = this.#repository.read(this.#actor);
        this.#refreshEntries();
        this.#busy = false;
        this.#render();
      }
    } catch (error) {
      warn("Quick switch failed.", error);
      const key = error?.code === "tokenRequired"
        ? "errors.tokenRequired"
        : error?.code === "featureDisabled" ? "errors.featureDisabled"
          : error?.code === "tokenDisabledForGallery" ? "errors.tokenDisabledForGallery" : "errors.actionFailed";
      notify("error", key);
      this.#busy = false;
      this.#render();
    }
  }

  #resolveTarget() {
    return resolveQuickTarget({
      origin: this.#origin,
      hasToken: Boolean(this.#token),
      configuredTarget: getSetting("quickApplyTarget", APPLY_TARGETS.PORTRAIT_CURRENT),
      portraitEnabled: getSetting("enablePortraitFeatures", true),
      tokenEnabled: getSetting("enableTokenFeatures", true),
      ignoreTokenChanges: this.#gallery?.ignoreTokenChanges
    });
  }

  #refreshEntries() {
    this.#entries = queryEntries(this.#gallery, {
      collection: this.#collection,
      favoritesOnly: this.#favoritesOnly,
      sort: "manual"
    });
  }

  #extensionSectionsHtml() {
    return this.#controllers.map(({ id, controller }) => {
      try {
        return String(controller.sectionHtml?.() ?? "");
      } catch (error) {
        warn(`Extension ${id} could not render its Quick Switch section.`, error);
        return "";
      }
    }).join("");
  }

  #bindExtensionSections() {
    for (const { id, controller } of this.#controllers) {
      try {
        controller.bind?.(this.#root);
      } catch (error) {
        warn(`Extension ${id} could not bind its Quick Switch section.`, error);
      }
    }
  }

  #extensionsAllowEmpty() {
    return this.#controllers.some(({ id, controller }) => {
      try {
        return Boolean(controller.allowEmpty?.());
      } catch (error) {
        warn(`Extension ${id} failed to evaluate an empty Quick Switch.`, error);
        return false;
      }
    });
  }

  async #dispatchExtensionAction(action, button, event) {
    for (const { id, controller } of this.#controllers) {
      if (typeof controller.onAction !== "function") continue;
      try {
        if (await controller.onAction(action, button, event)) return true;
      } catch (error) {
        warn(`Extension ${id} failed to handle the Quick Switch action ${action}.`, error);
        notify("error", "errors.actionFailed");
        return true;
      }
    }
    return false;
  }

  #modeProvider() {
    return this.#controllers.find((candidate) => candidate.modes.includes(this.#mode)) ?? null;
  }

  // What a companion may read or drive while the Quick Switch is open.
  #createExtensionView() {
    return Object.freeze({
      actor: this.#actor,
      token: this.#token,
      origin: this.#origin,
      mode: this.#mode,
      getGallery: () => deepClone(this.#gallery),
      getEntries: () => deepClone(this.#entries),
      getSelectedIndex: () => this.#selectedIndex,
      setSelectedIndex: (index) => {
        const value = Number(index);
        if (!Number.isInteger(value) || value < 0 || value >= this.#entries.length) return false;
        this.#selectedIndex = value;
        return true;
      },
      isBusy: () => this.#busy,
      setBusy: (busy) => { this.#busy = Boolean(busy); },
      render: () => this.#render(),
      reload: () => {
        if (!this.#actor) return;
        this.#gallery = this.#repository.read(this.#actor);
        this.#refreshEntries();
        if (this.#selectedIndex >= this.#entries.length) this.#selectedIndex = Math.max(0, this.#entries.length - 1);
      },
      commit: (options = {}) => this.#commit(options),
      close: () => this.close(),
      previewKind: () => this.#previewKind(),
      resolveTarget: () => this.#resolveTarget()
    });
  }

  #previewKind() {
    if (this.#origin === "sheet" || this.#gallery?.ignoreTokenChanges) return "portrait";
    return this.#token && getSetting("enableTokenFeatures", true) ? "token" : "portrait";
  }

  #position(anchor) {
    if (!this.#root || this.#mode !== CAROUSEL_MODE || !anchor?.getBoundingClientRect) return;
    const rect = anchor.getBoundingClientRect();
    this.#root.style.left = `${Math.max(12, Math.min(window.innerWidth - 440, rect.right + 12))}px`;
    this.#root.style.top = `${Math.max(12, Math.min(window.innerHeight - 520, rect.top))}px`;
  }

  #renderTokenPreview(entry, css) {
    this.#tokenPreview?.remove();
    this.#tokenPreview = null;
    const bounds = this.#token?.getBounds?.();
    const view = globalThis.canvas?.app?.view ?? globalThis.canvas?.app?.canvas;
    const screen = globalThis.canvas?.app?.renderer?.screen;
    const viewRect = view?.getBoundingClientRect?.();
    if (!bounds || !viewRect || !screen?.width || !screen?.height) return;
    const overlay = document.createElement("div");
    overlay.className = "aig-token-preview-overlay";
    overlay.setAttribute("aria-hidden", "true");
    Object.assign(overlay.style, {
      left: `${viewRect.left + bounds.x / screen.width * viewRect.width}px`,
      top: `${viewRect.top + bounds.y / screen.height * viewRect.height}px`,
      width: `${Math.max(24, bounds.width / screen.width * viewRect.width)}px`,
      height: `${Math.max(24, bounds.height / screen.height * viewRect.height)}px`
    });
    overlay.innerHTML = `<img src="${escapeAttribute(entry.source)}" alt="" style="object-fit:${escapeAttribute(css.objectFit)};transform:${escapeAttribute(css.transform)};filter:${escapeAttribute(css.filter)}">`;
    document.body.append(overlay);
    this.#tokenPreview = overlay;
  }
}

function isCurrentEntry(entry, actor, token, kind) {
  const source = kind === "token" ? token?.document?.texture?.src : actor?.img;
  return [entry.source, entry.derived?.[kind]?.source].includes(source);
}

function resolveToken(value) {
  return value?.actor || value?.document?.actor ? value : null;
}

function resolveActor(value, token) {
  if (value?.documentName === "Actor" || value?.constructor?.metadata?.name === "Actor") return value;
  return token?.actor ?? token?.document?.actor ?? null;
}

export function resolveQuickTarget({ origin = "token", hasToken = false, configuredTarget = APPLY_TARGETS.PORTRAIT_CURRENT, portraitEnabled = true, tokenEnabled = true, ignoreTokenChanges = false } = {}) {
  if (ignoreTokenChanges) return portraitEnabled ? APPLY_TARGETS.PORTRAIT : null;
  if (origin === "sheet") return portraitEnabled ? APPLY_TARGETS.PORTRAIT : null;
  if (!portraitEnabled && !tokenEnabled) return null;
  if (portraitEnabled && !tokenEnabled) return APPLY_TARGETS.PORTRAIT;
  if (!portraitEnabled && tokenEnabled) {
    const tokenOnlyTargets = {
      [APPLY_TARGETS.PROTOTYPE]: APPLY_TARGETS.PROTOTYPE,
      [APPLY_TARGETS.CURRENT_TOKEN]: hasToken ? APPLY_TARGETS.CURRENT_TOKEN : APPLY_TARGETS.PROTOTYPE,
      [APPLY_TARGETS.SCENE_TOKENS]: APPLY_TARGETS.SCENE_TOKENS,
      [APPLY_TARGETS.PORTRAIT_PROTOTYPE]: APPLY_TARGETS.PROTOTYPE,
      [APPLY_TARGETS.PORTRAIT_CURRENT]: hasToken ? APPLY_TARGETS.CURRENT_TOKEN : APPLY_TARGETS.PROTOTYPE,
      [APPLY_TARGETS.EVERYTHING]: APPLY_TARGETS.SCENE_TOKENS
    };
    return tokenOnlyTargets[configuredTarget] ?? (hasToken ? APPLY_TARGETS.CURRENT_TOKEN : APPLY_TARGETS.PROTOTYPE);
  }
  return configuredTarget;
}

function getSetting(key, fallback) {
  try {
    return globalThis.game?.settings?.get?.(MODULE_ID, key) ?? fallback;
  } catch {
    return fallback;
  }
}

async function setSetting(key, value) {
  try {
    await globalThis.game?.settings?.set?.(MODULE_ID, key, value);
  } catch (error) {
    warn(`Could not persist setting ${key}.`, error);
  }
}

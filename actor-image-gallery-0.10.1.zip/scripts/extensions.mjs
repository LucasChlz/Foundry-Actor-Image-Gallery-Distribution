import { EXTENSION_API_VERSION, EXTENSION_CAPABILITIES, MODULE_ID } from "./constants.mjs";
import { warn } from "./utils.mjs";

const EXTENSION_ID_PATTERN = /^[a-z0-9][a-z0-9._-]{0,99}$/i;
const QUICK_SWITCH_MODE_PATTERN = /^[a-z][a-z0-9-]{0,31}$/;
const CORE_QUICK_SWITCH_MODES = new Set(["carousel"]);

// Companion modules register here during the Free module's `init` hook and are
// activated once the Free runtime exists. The registry never stores anything
// beyond the validated id, capabilities, activation callback and contributions.
export class ExtensionRegistry {
  #records = new Map();
  #providers = new Map();
  #modules;
  #host = null;

  constructor({ modules = () => globalThis.game?.modules ?? null } = {}) {
    this.#modules = modules;
  }

  get apiVersion() {
    return EXTENSION_API_VERSION;
  }

  registrar({ coreVersion = null } = {}) {
    return Object.freeze({
      apiVersion: EXTENSION_API_VERSION,
      coreVersion,
      register: (descriptor) => this.register(descriptor)
    });
  }

  register(descriptor) {
    const record = this.#validate(descriptor);
    this.#records.set(record.id, record);
    for (const capability of record.capabilities) this.#providers.set(capability, record.id);
    if (this.#host) this.#activate(record, this.#host);
    return Object.freeze({ id: record.id, capabilities: record.capabilities });
  }

  activateAll(host) {
    this.#host = host;
    for (const record of this.#records.values()) {
      if (record.state === "registered") this.#activate(record, host);
    }
    return this.list();
  }

  has(capability) {
    const id = this.#providers.get(capability);
    return Boolean(id && this.#records.get(id)?.state === "active");
  }

  hasActiveExtensions() {
    return this.#activeRecords().length > 0;
  }

  list() {
    return Array.from(this.#records.values(), (record) => Object.freeze({
      id: record.id,
      capabilities: record.capabilities,
      state: record.state,
      error: record.error
    }));
  }

  createGalleryControllers(view) {
    return this.#createControllers("gallery", view);
  }

  createQuickSwitchControllers(view) {
    return this.#createControllers("quickSwitch", view);
  }

  providesQuickSwitchMode(mode) {
    return this.#activeRecords().some((record) => record.contributions?.quickSwitch?.modes.includes(mode));
  }

  #createControllers(kind, view) {
    const controllers = [];
    for (const record of this.#activeRecords()) {
      const contribution = record.contributions?.[kind];
      if (!contribution) continue;
      try {
        const controller = contribution.create(view);
        if (controller && typeof controller === "object") {
          controllers.push(Object.freeze({ id: record.id, controller, modes: contribution.modes ?? Object.freeze([]) }));
        }
      } catch (error) {
        warn(`Extension ${record.id} could not create its ${kind} controller.`, error);
      }
    }
    return controllers;
  }

  #activeRecords() {
    return Array.from(this.#records.values()).filter((record) => record.state === "active");
  }

  #activate(record, host) {
    try {
      const result = record.activate(host);
      if (typeof result?.then === "function") throw new ExtensionError("extensionActivationAsync");
      record.contributions = normalizeContributions(result);
      record.state = "active";
      record.error = null;
    } catch (error) {
      record.contributions = null;
      record.state = "failed";
      record.error = String(error?.code ?? error?.message ?? "extensionActivationFailed");
      warn(`Extension ${record.id} failed to activate; its capabilities stay unavailable.`, error);
    }
  }

  #validate(descriptor) {
    if (!descriptor || typeof descriptor !== "object" || typeof descriptor.activate !== "function") {
      throw new ExtensionError("extensionInvalid");
    }
    const id = String(descriptor.id ?? "").trim();
    if (!EXTENSION_ID_PATTERN.test(id)) throw new ExtensionError("extensionIdInvalid");
    if (id === MODULE_ID) throw new ExtensionError("extensionIdReserved");
    if (this.#records.has(id)) throw new ExtensionError("extensionAlreadyRegistered", { id });
    if (!this.#modules()?.get?.(id)?.active) throw new ExtensionError("extensionModuleInactive", { id });
    if (Number(descriptor.apiVersion) !== EXTENSION_API_VERSION) {
      throw new ExtensionError("extensionApiVersionUnsupported", { id, requested: descriptor.apiVersion, supported: EXTENSION_API_VERSION });
    }
    const capabilities = Array.from(new Set(Array.isArray(descriptor.capabilities) ? descriptor.capabilities.map(String) : []));
    if (!capabilities.length) throw new ExtensionError("extensionCapabilitiesRequired", { id });
    const unknown = capabilities.find((capability) => !EXTENSION_CAPABILITIES.includes(capability));
    if (unknown) throw new ExtensionError("extensionCapabilityUnknown", { id, capability: unknown });
    const conflict = capabilities.find((capability) => this.#providers.has(capability));
    if (conflict) throw new ExtensionError("extensionCapabilityConflict", { id, capability: conflict, provider: this.#providers.get(conflict) });
    return {
      id,
      capabilities: Object.freeze(capabilities),
      activate: descriptor.activate,
      state: "registered",
      error: null,
      contributions: null
    };
  }
}

export class ExtensionError extends Error {
  constructor(code, details = {}) {
    super(code);
    this.name = "ExtensionError";
    this.code = code;
    this.details = Object.freeze({ ...details });
  }
}

function normalizeContributions(value) {
  const source = value && typeof value === "object" ? value : {};
  const gallery = typeof source.gallery?.create === "function"
    ? Object.freeze({ create: (view) => source.gallery.create(view) })
    : null;
  const modes = Array.isArray(source.quickSwitch?.modes)
    ? Array.from(new Set(source.quickSwitch.modes.map(String))).filter((mode) => QUICK_SWITCH_MODE_PATTERN.test(mode) && !CORE_QUICK_SWITCH_MODES.has(mode))
    : [];
  const quickSwitch = typeof source.quickSwitch?.create === "function"
    ? Object.freeze({ create: (view) => source.quickSwitch.create(view), modes: Object.freeze(modes) })
    : null;
  return Object.freeze({ gallery, quickSwitch });
}

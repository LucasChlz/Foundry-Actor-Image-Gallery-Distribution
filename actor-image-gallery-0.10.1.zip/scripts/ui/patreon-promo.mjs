import { escapeAttribute, escapeHtml, localize } from "../utils.mjs";

// Where "Join the Guild" leads. Point it at the companion's Patreon post once
// that post is published.
export const PATREON_URL = "https://www.patreon.com/LontraTheWizard";

const FEATURES = Object.freeze([
  ["profiles", "fa-masks-theater"],
  ["sequences", "fa-list-ol"],
  ["automation", "fa-wand-magic-sparkles"],
  ["wheel", "fa-circle-notch"]
]);

// Like Battle Replay's Studio card: only GMs see it, and never once a
// companion already adds its own buttons to the gallery.
export function shouldShowPatreonPromo(user, companionCount) {
  return Boolean(user?.isGM) && companionCount === 0;
}

export function patreonPromoButtonHtml() {
  return `<button type="button" class="aig-button aig-patreon-button" data-action="patreon-open" title="${escapeAttribute(localize("patreonPromo.openHint"))}">
    <i class="fa-brands fa-patreon" aria-hidden="true"></i><span>${escapeHtml(localize("patreonPromo.open"))}</span><b class="aig-pro-badge">PATREON</b>
  </button>`;
}

export function patreonPromoPanelHtml() {
  const features = FEATURES.map(([key, icon]) => `<li><i class="fa-solid ${icon}" aria-hidden="true"></i><span><strong>${escapeHtml(localize(`patreonPromo.features.${key}.name`))}</strong>${escapeHtml(localize(`patreonPromo.features.${key}.hint`))}</span></li>`).join("");
  return `<section class="aig-patreon-panel" data-role="patreon-panel" aria-label="${escapeAttribute(localize("patreonPromo.title"))}" hidden>
    <header><div><span class="aig-kicker">${escapeHtml(localize("patreonPromo.kicker"))}</span><h2>${escapeHtml(localize("patreonPromo.title"))}</h2></div><button type="button" class="aig-icon-button" data-action="patreon-close" title="${escapeAttribute(localize("common.close"))}"><i class="fa-solid fa-xmark" aria-hidden="true"></i></button></header>
    <p>${escapeHtml(localize("patreonPromo.headline"))}</p>
    <ul class="aig-patreon-panel__features">${features}</ul>
    <a class="aig-button aig-button--signal aig-button--wide aig-patreon-panel__cta" href="${escapeAttribute(PATREON_URL)}" target="_blank" rel="noopener noreferrer">
      <i class="fa-brands fa-patreon" aria-hidden="true"></i><span>${escapeHtml(localize("patreonPromo.cta"))}</span><i class="fa-solid fa-arrow-up-right-from-square" aria-hidden="true"></i>
    </a>
    <p class="aig-patreon-panel__note">${escapeHtml(localize("patreonPromo.requirement"))}</p>
  </section>`;
}

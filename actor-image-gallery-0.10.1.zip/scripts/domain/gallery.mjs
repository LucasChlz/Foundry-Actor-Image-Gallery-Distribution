import {
  DEFAULT_ADJUSTMENTS,
  DEFAULT_PRESET,
  HISTORY_LIMIT,
  IMAGE_FITS,
  SCHEMA_VERSION,
  SORT_MODES
} from "../constants.mjs";
import { clamp, deepClone, randomId, sourceName } from "../utils.mjs";

// Position is the image's offset from the frame's center, in percent of the frame. A zoomed or
// filled image can be several frames tall, so a fixed ±100 % never reached its edges (a zoomed
// full-body image could not be dragged down to its head). The editor limits dragging with
// positionLimits; the preset only rejects absurd values.
export const POSITION_LIMIT = 1000;

export function createPreset(input = {}) {
  return {
    fit: input.fit === IMAGE_FITS.COVER ? IMAGE_FITS.COVER : IMAGE_FITS.CONTAIN,
    zoom: clamp(input.zoom ?? DEFAULT_PRESET.zoom, 0.5, 4),
    positionX: clamp(input.positionX ?? DEFAULT_PRESET.positionX, -POSITION_LIMIT, POSITION_LIMIT),
    positionY: clamp(input.positionY ?? DEFAULT_PRESET.positionY, -POSITION_LIMIT, POSITION_LIMIT),
    rotation: normalizeRotation(input.rotation ?? DEFAULT_PRESET.rotation),
    flipX: Boolean(input.flipX),
    flipY: Boolean(input.flipY),
    adjustments: {
      brightness: clamp(input.adjustments?.brightness ?? DEFAULT_ADJUSTMENTS.brightness, 0, 200),
      contrast: clamp(input.adjustments?.contrast ?? DEFAULT_ADJUSTMENTS.contrast, 0, 200),
      saturation: clamp(input.adjustments?.saturation ?? DEFAULT_ADJUSTMENTS.saturation, 0, 200),
      temperature: clamp(input.adjustments?.temperature ?? DEFAULT_ADJUSTMENTS.temperature, -100, 100),
      exposure: clamp(input.adjustments?.exposure ?? DEFAULT_ADJUSTMENTS.exposure, -100, 100),
      shadows: clamp(input.adjustments?.shadows ?? DEFAULT_ADJUSTMENTS.shadows, -100, 100),
      highlights: clamp(input.adjustments?.highlights ?? DEFAULT_ADJUSTMENTS.highlights, -100, 100),
      grayscale: clamp(input.adjustments?.grayscale ?? DEFAULT_ADJUSTMENTS.grayscale, 0, 100),
      blur: clamp(input.adjustments?.blur ?? DEFAULT_ADJUSTMENTS.blur, 0, 12)
    }
  };
}

export function createEntry(input = {}, { now = new Date().toISOString(), id = randomId() } = {}) {
  const source = String(input.source ?? "").trim();
  const quickSlot = Number(input.quickSlot);
  return {
    id: String(input.id ?? id),
    globalEntryId: input.globalEntryId ? String(input.globalEntryId) : null,
    source,
    name: String(input.name ?? "").trim() || sourceName(source),
    tags: normalizeTags(input.tags),
    description: String(input.description ?? "").trim(),
    collection: String(input.collection ?? "").trim(),
    favorite: Boolean(input.favorite),
    isDefault: Boolean(input.isDefault),
    quickSlot: Number.isInteger(quickSlot) && quickSlot >= 1 && quickSlot <= 4 ? quickSlot : null,
    createdAt: validDate(input.createdAt) ?? now,
    updatedAt: validDate(input.updatedAt) ?? now,
    lastUsedAt: validDate(input.lastUsedAt),
    usageCount: Math.max(0, Number.parseInt(input.usageCount ?? 0, 10) || 0),
    manualOrder: Number.isFinite(Number(input.manualOrder)) ? Number(input.manualOrder) : 0,
    portrait: createPreset(input.portrait),
    token: createPreset(input.token),
    derived: normalizeDerived(input.derived)
  };
}

export function createGallery(input = {}) {
  const migrated = migrateGalleryData(input);
  const entries = normalizeEntries(migrated);
  const ids = new Set(entries.map((entry) => entry.id));
  const profiles = cloneOpaqueArray(migrated.profiles);
  const sequences = cloneOpaqueArray(migrated.sequences);
  return {
    version: SCHEMA_VERSION,
    schemaVersion: SCHEMA_VERSION,
    ignoreTokenChanges: Boolean(migrated.ignoreTokenChanges),
    entries,
    history: Array.from(new Set(Array.isArray(migrated.history) ? migrated.history.map(String) : []))
      .filter((id) => ids.has(id))
      .slice(0, HISTORY_LIMIT),
    temporaryState: cloneOptionalRecord(migrated.temporaryState),
    profiles,
    activeProfileId: migrated.activeProfileId ? String(migrated.activeProfileId) : null,
    sequences,
    sequenceState: cloneOptionalRecord(migrated.sequenceState) ?? {},
    activeSequenceId: migrated.activeSequenceId ? String(migrated.activeSequenceId) : null,
    automationRules: cloneOpaqueArray(migrated.automationRules),
    automationState: cloneOptionalRecord(migrated.automationState),
    radialWheelConfig: cloneOptionalRecord(migrated.radialWheelConfig),
    sceneMappings: cloneOpaqueArray(migrated.sceneMappings),
    sharedSubscriptions: cloneOpaqueArray(migrated.sharedSubscriptions)
  };
}

export function migrateGalleryData(input = {}) {
  const source = input && typeof input === "object" && !Array.isArray(input) ? deepClone(input) : {};
  const version = Number(source.schemaVersion ?? source.version ?? 1);
  if (version < 2 && source.ignoreTokenChanges === undefined) source.ignoreTokenChanges = false;
  if (version < 3) {
    source.temporaryState ??= null;
    source.profiles ??= [];
    source.sequences ??= [];
    source.automationRules ??= [];
    source.radialWheelConfig ??= null;
    source.sceneMappings ??= [];
    source.sharedSubscriptions ??= [];
  }
  if (version < 4) source.activeProfileId ??= null;
  if (version < 5) {
    source.sequenceState ??= {};
    source.activeSequenceId ??= null;
  }
  if (version < 6) source.automationState ??= null;
  source.version = SCHEMA_VERSION;
  source.schemaVersion = SCHEMA_VERSION;
  return source;
}

export function addEntry(galleryInput, entryInput, options = {}) {
  const gallery = createGallery(galleryInput);
  const nextOrder = gallery.entries.reduce((highest, entry) => Math.max(highest, entry.manualOrder), -1) + 1;
  const entry = createEntry({ ...entryInput, manualOrder: nextOrder }, options);
  if (!entry.source) throw new GalleryValidationError("sourceRequired");
  if (entry.isDefault) for (const current of gallery.entries) current.isDefault = false;
  if (entry.quickSlot) clearQuickSlot(gallery.entries, entry.quickSlot);
  gallery.entries.push(entry);
  return { gallery, entry };
}

export function updateEntry(galleryInput, entryId, patch, { now = new Date().toISOString() } = {}) {
  const gallery = createGallery(galleryInput);
  const index = gallery.entries.findIndex((entry) => entry.id === entryId);
  if (index < 0) throw new GalleryValidationError("entryNotFound");
  const current = gallery.entries[index];
  const editsAffectDerivative = ["source", "portrait", "token"].some((key) => Object.hasOwn(patch, key));
  const entry = createEntry({
    ...current,
    ...deepClone(patch),
    id: current.id,
    createdAt: current.createdAt,
    updatedAt: now,
    portrait: patch.portrait ? { ...current.portrait, ...patch.portrait } : current.portrait,
    token: patch.token ? { ...current.token, ...patch.token } : current.token,
    derived: Object.hasOwn(patch, "derived") ? patch.derived : editsAffectDerivative ? {} : current.derived
  }, { now, id: current.id });
  if (!entry.source) throw new GalleryValidationError("sourceRequired");
  if (entry.isDefault) {
    for (const candidate of gallery.entries) candidate.isDefault = false;
  }
  if (entry.quickSlot) clearQuickSlot(gallery.entries, entry.quickSlot, entry.id);
  gallery.entries[index] = entry;
  return { gallery, entry };
}

export function removeEntry(galleryInput, entryId) {
  const gallery = createGallery(galleryInput);
  const index = gallery.entries.findIndex((entry) => entry.id === entryId);
  if (index < 0) throw new GalleryValidationError("entryNotFound");
  const [entry] = gallery.entries.splice(index, 1);
  gallery.history = gallery.history.filter((id) => id !== entryId);
  compactManualOrder(gallery.entries);
  return { gallery, entry };
}

export function duplicateEntry(galleryInput, entryId, { suffix = " copy", now = new Date().toISOString(), id } = {}) {
  const gallery = createGallery(galleryInput);
  const source = gallery.entries.find((entry) => entry.id === entryId);
  if (!source) throw new GalleryValidationError("entryNotFound");
  return addEntry(gallery, {
    ...deepClone(source),
    id: undefined,
    name: `${source.name}${suffix}`,
    favorite: false,
    isDefault: false,
    quickSlot: null,
    usageCount: 0,
    lastUsedAt: null,
    derived: {}
  }, { now, id });
}

export function toggleFavorite(galleryInput, entryId) {
  const gallery = createGallery(galleryInput);
  const entry = gallery.entries.find((candidate) => candidate.id === entryId);
  if (!entry) throw new GalleryValidationError("entryNotFound");
  entry.favorite = !entry.favorite;
  entry.updatedAt = new Date().toISOString();
  return { gallery, entry };
}

export function setDefault(galleryInput, entryId) {
  const gallery = createGallery(galleryInput);
  let selected = null;
  for (const entry of gallery.entries) {
    entry.isDefault = entry.id === entryId;
    if (entry.isDefault) selected = entry;
  }
  if (!selected) throw new GalleryValidationError("entryNotFound");
  selected.updatedAt = new Date().toISOString();
  return { gallery, entry: selected };
}

export function reorderEntries(galleryInput, orderedIds) {
  const gallery = createGallery(galleryInput);
  const allIds = gallery.entries.map((entry) => entry.id);
  const normalized = Array.from(new Set(orderedIds.map(String)));
  if (normalized.length !== allIds.length || allIds.some((id) => !normalized.includes(id))) {
    throw new GalleryValidationError("invalidOrder");
  }
  const order = new Map(normalized.map((id, index) => [id, index]));
  for (const entry of gallery.entries) entry.manualOrder = order.get(entry.id);
  gallery.entries.sort((left, right) => left.manualOrder - right.manualOrder);
  return gallery;
}

export function reorderEntryIds(orderedIds, draggedId, targetId = null, placement = "before") {
  const ids = orderedIds.map(String);
  const dragged = String(draggedId ?? "");
  const target = targetId === null ? null : String(targetId);
  const from = ids.indexOf(dragged);
  if (from < 0 || target === dragged) return ids;
  ids.splice(from, 1);
  if (target === null) {
    ids.push(dragged);
    return ids;
  }
  const targetIndex = ids.indexOf(target);
  if (targetIndex < 0) return orderedIds.map(String);
  ids.splice(targetIndex + (placement === "after" ? 1 : 0), 0, dragged);
  return ids;
}

export function mergeVisibleEntryOrder(orderedIds, visibleIds) {
  const ids = orderedIds.map(String);
  const allowed = new Set(ids);
  const visible = Array.from(new Set(visibleIds.map(String))).filter((id) => allowed.has(id));
  if (!visible.length) return ids;
  const visibleSet = new Set(visible);
  let index = 0;
  return ids.map((id) => visibleSet.has(id) ? visible[index++] : id);
}

export function recordUsage(galleryInput, entryId, { now = new Date().toISOString() } = {}) {
  const gallery = createGallery(galleryInput);
  const entry = gallery.entries.find((candidate) => candidate.id === entryId);
  if (!entry) throw new GalleryValidationError("entryNotFound");
  entry.usageCount += 1;
  entry.lastUsedAt = now;
  gallery.history = [entryId, ...gallery.history.filter((id) => id !== entryId)].slice(0, HISTORY_LIMIT);
  return { gallery, entry };
}

export function queryEntries(galleryInput, {
  query = "",
  tag = "",
  collection = "",
  favoritesOnly = false,
  sort = SORT_MODES.MANUAL
} = {}) {
  const entries = normalizeEntries(galleryInput);
  const normalizedQuery = normalizeSearchText(query);
  const normalizedTag = normalizeSearchText(tag);
  const normalizedCollection = normalizeSearchText(collection);
  const filtered = entries.filter((entry) => {
    if (favoritesOnly && !entry.favorite) return false;
    if (normalizedTag && !entry.tags.some((candidate) => normalizeSearchText(candidate) === normalizedTag)) return false;
    if (normalizedCollection && normalizeSearchText(entry.collection) !== normalizedCollection) return false;
    if (!normalizedQuery) return true;
    return normalizeSearchText([entry.name, entry.description, entry.collection, ...entry.tags].join(" "))
      .includes(normalizedQuery);
  });
  return filtered.sort(sorter(sort));
}

export function getTags(galleryInput) {
  return Array.from(new Set(normalizeEntries(galleryInput).flatMap((entry) => entry.tags)))
    .sort((left, right) => left.localeCompare(right));
}

export function getCollections(galleryInput) {
  return Array.from(new Set(normalizeEntries(galleryInput).map((entry) => entry.collection).filter(Boolean)))
    .sort((left, right) => left.localeCompare(right));
}

export function presetSignature(presetInput) {
  const preset = createPreset(presetInput);
  return JSON.stringify(preset);
}

// "Fill frame" on tall art (full-body portraits) starts at the top, where the face usually is,
// instead of a centered crop that keeps the belly.
export function topAnchorPosition({ width, height } = {}) {
  const ratio = Number(height) / Number(width);
  if (!Number.isFinite(ratio) || ratio <= 1) return 0;
  return clamp(Math.round((ratio - 1) / 2 * 100), 0, POSITION_LIMIT);
}

// How far the editor lets an image move from the center: until it just leaves the frame, which is
// the old ±100 % for an image the size of the frame and grows with zoom and "Fill frame".
// Same scale as the renderer (fit, then zoom); a quarter turn swaps width and height.
export function positionLimits({ frameWidth, frameHeight, imageWidth, imageHeight, fit = IMAGE_FITS.CONTAIN, zoom = 1, rotation = 0 } = {}) {
  const sizes = [frameWidth, frameHeight, imageWidth, imageHeight].map(Number);
  if (!sizes.every((value) => Number.isFinite(value) && value > 0)) return { x: 100, y: 100 };
  const [frameW, frameH, imageW, imageH] = sizes;
  const ratios = [frameW / imageW, frameH / imageH];
  const scale = (fit === IMAGE_FITS.COVER ? Math.max(...ratios) : Math.min(...ratios)) * (Number(zoom) || 1);
  const quarterTurn = Math.abs(Math.round(Number(rotation) / 90)) % 2 === 1;
  const [width, height] = quarterTurn ? [imageH * scale, imageW * scale] : [imageW * scale, imageH * scale];
  const limit = (size, frame) => clamp(Math.ceil(50 * (size / frame + 1)), 100, POSITION_LIMIT);
  return { x: limit(width, frameW), y: limit(height, frameH) };
}

export function isIdentityPreset(presetInput) {
  return presetSignature(presetInput) === presetSignature(DEFAULT_PRESET);
}

// Size of an edited image. The Portrait keeps the image's own shape and resolution (a fixed
// 768 px square made it smaller in the sheet than the original); the Token is a square as sharp
// as the source allows. A quarter turn swaps the Portrait's width and height.
export const PORTRAIT_MAX_SIZE = 4096;
export const TOKEN_MIN_SIZE = 512;
export const TOKEN_MAX_SIZE = 2048;
export const BLUR_REFERENCE_SIZE = 512;

export function derivedFrameSize(kind, imageSize = {}, presetInput = {}) {
  const preset = createPreset(presetInput);
  const width = Number(imageSize?.width);
  const height = Number(imageSize?.height);
  const known = Number.isFinite(width) && Number.isFinite(height) && width > 0 && height > 0;
  if (kind === "portrait") {
    if (!known) return { width: 768, height: 768 };
    const quarterTurn = Math.abs(Math.round(preset.rotation / 90)) % 2 === 1;
    const [frameWidth, frameHeight] = quarterTurn ? [height, width] : [width, height];
    const scale = Math.min(1, PORTRAIT_MAX_SIZE / Math.max(frameWidth, frameHeight));
    return { width: Math.round(frameWidth * scale), height: Math.round(frameHeight * scale) };
  }
  if (!known) return { width: TOKEN_MIN_SIZE, height: TOKEN_MIN_SIZE };
  // One output pixel per source pixel where possible: the side that spans the frame, over the zoom.
  const spanning = preset.fit === IMAGE_FITS.COVER ? Math.min(width, height) : Math.max(width, height);
  const size = clamp(Math.round(spanning / preset.zoom), TOKEN_MIN_SIZE, TOKEN_MAX_SIZE);
  return { width: size, height: size };
}

// frameSize: the preview's size in pixels. Blur is stored for a 512 px frame so the preview and a
// large saved image look equally soft.
export function presetCss(presetInput, { frameSize = BLUR_REFERENCE_SIZE } = {}) {
  const preset = createPreset(presetInput);
  const adjustment = preset.adjustments;
  const brightness = clamp(adjustment.brightness + adjustment.exposure * 0.45 + adjustment.highlights * 0.15, 0, 250);
  const contrast = clamp(adjustment.contrast - adjustment.shadows * 0.2 + adjustment.highlights * 0.1, 0, 250);
  const warmth = adjustment.temperature;
  const sepia = Math.abs(warmth) * 0.35;
  const hue = warmth < 0 ? 185 : warmth > 0 ? -12 : 0;
  return {
    objectFit: preset.fit,
    transform: `translate(${preset.positionX}%, ${preset.positionY}%) scale(${preset.flipX ? -preset.zoom : preset.zoom}, ${preset.flipY ? -preset.zoom : preset.zoom}) rotate(${preset.rotation}deg)`,
    filter: [
      `brightness(${brightness}%)`,
      `contrast(${contrast}%)`,
      `saturate(${adjustment.saturation}%)`,
      `sepia(${sepia}%)`,
      `hue-rotate(${hue}deg)`,
      `grayscale(${adjustment.grayscale}%)`,
      `blur(${adjustment.blur * frameSize / BLUR_REFERENCE_SIZE}px)`
    ].join(" ")
  };
}

export function normalizeTags(tags) {
  const values = Array.isArray(tags) ? tags : String(tags ?? "").split(",");
  const seen = new Set();
  return values.map((tag) => String(tag).trim()).filter((tag) => {
    const key = normalizeSearchText(tag);
    if (!key || seen.has(key)) return false;
    seen.add(key);
    return true;
  }).slice(0, 30);
}

export class GalleryValidationError extends Error {
  constructor(code) {
    super(code);
    this.name = "GalleryValidationError";
    this.code = code;
  }
}

function normalizeSearchText(value) {
  return String(value ?? "").normalize("NFKD").replace(/[\u0300-\u036f]/g, "").toLocaleLowerCase();
}

function normalizeRotation(value) {
  const number = Number(value);
  if (!Number.isFinite(number)) return 0;
  const normalized = number % 360;
  return normalized > 180 ? normalized - 360 : normalized < -180 ? normalized + 360 : normalized;
}

function validDate(value) {
  if (!value) return null;
  const time = Date.parse(value);
  return Number.isFinite(time) ? new Date(time).toISOString() : null;
}

function normalizeDerived(value) {
  const result = {};
  for (const kind of ["portrait", "token"]) {
    const item = value?.[kind];
    if (!item?.source || !item?.signature) continue;
    result[kind] = { source: String(item.source), signature: String(item.signature) };
    if (Number.isInteger(item.renderVersion)) result[kind].renderVersion = item.renderVersion;
  }
  return result;
}

function normalizeEntries(galleryInput) {
  const sourceEntries = Array.isArray(galleryInput?.entries) ? galleryInput.entries : [];
  const entries = sourceEntries.map((entry, index) => createEntry({ ...entry, manualOrder: entry.manualOrder ?? index }));
  enforceUniqueState(entries);
  return entries;
}

function cloneOpaqueArray(value) {
  return Array.isArray(value) ? deepClone(value) : [];
}

function cloneOptionalRecord(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? deepClone(value) : null;
}

function clearQuickSlot(entries, slot, exceptId = null) {
  for (const entry of entries) if (entry.id !== exceptId && entry.quickSlot === slot) entry.quickSlot = null;
}

function enforceUniqueState(entries) {
  let defaultSeen = false;
  const quickSlots = new Set();
  for (const entry of entries) {
    if (entry.isDefault) {
      if (defaultSeen) entry.isDefault = false;
      defaultSeen = true;
    }
    if (entry.quickSlot) {
      if (quickSlots.has(entry.quickSlot)) entry.quickSlot = null;
      else quickSlots.add(entry.quickSlot);
    }
  }
}

function compactManualOrder(entries) {
  entries.sort((left, right) => left.manualOrder - right.manualOrder);
  entries.forEach((entry, index) => { entry.manualOrder = index; });
}

function sorter(mode) {
  const name = (left, right) => left.name.localeCompare(right.name, undefined, { sensitivity: "base" });
  if (mode === SORT_MODES.NAME) return name;
  if (mode === SORT_MODES.RECENT) {
    return (left, right) => Date.parse(right.createdAt) - Date.parse(left.createdAt) || name(left, right);
  }
  if (mode === SORT_MODES.USED) {
    return (left, right) => right.usageCount - left.usageCount || Date.parse(right.lastUsedAt ?? 0) - Date.parse(left.lastUsedAt ?? 0) || name(left, right);
  }
  if (mode === SORT_MODES.FAVORITES) {
    return (left, right) => Number(right.favorite) - Number(left.favorite) || name(left, right);
  }
  return (left, right) => left.manualOrder - right.manualOrder || name(left, right);
}

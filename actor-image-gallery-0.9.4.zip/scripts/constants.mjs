export const MODULE_ID = "actor-image-gallery";
export const FLAG_KEY = "gallery";
export const SCHEMA_VERSION = 6;
export const APPEARANCE_PROFILE_SCHEMA_VERSION = 1;
export const APPEARANCE_SEQUENCE_SCHEMA_VERSION = 1;
export const AUTOMATION_RULE_SCHEMA_VERSION = 1;
export const GLOBAL_GALLERY_SCHEMA_VERSION = 1;
export const HISTORY_LIMIT = 12;
export const PUBLIC_API_VERSION = 1;
export const BACKUP_SCHEMA_VERSION = 1;

export const HOOKS = Object.freeze({
  ENTRY_ADDED: "actorImageGallery.entryAdded",
  ENTRY_REMOVED: "actorImageGallery.entryRemoved",
  GLOBAL_ENTRY_ADDED: "actorImageGallery.globalEntryAdded",
  GLOBAL_ENTRY_UPDATED: "actorImageGallery.globalEntryUpdated",
  GLOBAL_ENTRY_REMOVED: "actorImageGallery.globalEntryRemoved",
  APPEARANCE_CHANGED: "actorImageGallery.appearanceChanged",
  TEMPORARY_STARTED: "actorImageGallery.temporaryStarted",
  TEMPORARY_REVERTED: "actorImageGallery.temporaryReverted",
  TEMPORARY_CLEARED: "actorImageGallery.temporaryCleared",
  BACKUP_IMPORTED: "actorImageGallery.backupImported",
  PROFILE_ADDED: "actorImageGallery.profileAdded",
  PROFILE_UPDATED: "actorImageGallery.profileUpdated",
  PROFILE_REMOVED: "actorImageGallery.profileRemoved",
  PROFILE_APPLIED: "actorImageGallery.profileApplied",
  SEQUENCE_ADDED: "actorImageGallery.sequenceAdded",
  SEQUENCE_UPDATED: "actorImageGallery.sequenceUpdated",
  SEQUENCE_REMOVED: "actorImageGallery.sequenceRemoved",
  SEQUENCE_REORDERED: "actorImageGallery.sequenceReordered",
  SEQUENCE_NAVIGATED: "actorImageGallery.sequenceNavigated",
  AUTOMATION_RULE_ADDED: "actorImageGallery.automationRuleAdded",
  AUTOMATION_RULE_UPDATED: "actorImageGallery.automationRuleUpdated",
  AUTOMATION_RULE_REMOVED: "actorImageGallery.automationRuleRemoved",
  AUTOMATION_RULE_REORDERED: "actorImageGallery.automationRuleReordered",
  AUTOMATION_EVALUATED: "actorImageGallery.automationEvaluated",
  AUTOMATION_APPLIED: "actorImageGallery.automationApplied",
  MANUAL_OVERRIDE_CHANGED: "actorImageGallery.manualOverrideChanged",
  ENTITLEMENT_CHANGED: "actorImageGallery.entitlementChanged"
});

export const CAPABILITIES = Object.freeze({
  GLOBAL_GALLERY: "globalGallery",
  PUBLIC_API: "publicApi",
  METADATA_BACKUP: "metadataBackup",
  MANUAL_TEMPORARY_APPEARANCE: "manualTemporaryAppearance",
  APPEARANCE_PROFILES: "appearanceProfiles",
  APPEARANCE_SEQUENCES: "appearanceSequences",
  AUTOMATION_RULES: "automationRules",
  RADIAL_WHEEL: "radialWheel",
  SHARED_COLLECTIONS: "sharedCollections",
  PARTY_MANAGER: "partyManager",
  SMART_BULK_IMPORT: "smartBulkImport",
  SCENE_APPEARANCES: "sceneAppearances",
  ADVANCED_RANDOMIZATION: "advancedRandomization",
  ADVANCED_IMAGE_PIPELINE: "advancedImagePipeline"
});

export const FEATURE_REGISTRY = Object.freeze({
  [CAPABILITIES.GLOBAL_GALLERY]: Object.freeze({ tier: "free" }),
  [CAPABILITIES.PUBLIC_API]: Object.freeze({ tier: "free" }),
  [CAPABILITIES.METADATA_BACKUP]: Object.freeze({ tier: "free" }),
  [CAPABILITIES.MANUAL_TEMPORARY_APPEARANCE]: Object.freeze({ tier: "free" }),
  [CAPABILITIES.APPEARANCE_PROFILES]: Object.freeze({ tier: "patreon" }),
  [CAPABILITIES.APPEARANCE_SEQUENCES]: Object.freeze({ tier: "patreon" }),
  [CAPABILITIES.AUTOMATION_RULES]: Object.freeze({ tier: "patreon" }),
  [CAPABILITIES.RADIAL_WHEEL]: Object.freeze({ tier: "patreon" }),
  [CAPABILITIES.SHARED_COLLECTIONS]: Object.freeze({ tier: "patreon" }),
  [CAPABILITIES.PARTY_MANAGER]: Object.freeze({ tier: "patreon" }),
  [CAPABILITIES.SMART_BULK_IMPORT]: Object.freeze({ tier: "patreon" }),
  [CAPABILITIES.SCENE_APPEARANCES]: Object.freeze({ tier: "patreon" }),
  [CAPABILITIES.ADVANCED_RANDOMIZATION]: Object.freeze({ tier: "patreon" }),
  [CAPABILITIES.ADVANCED_IMAGE_PIPELINE]: Object.freeze({ tier: "patreon" })
});

export const APPLY_TARGETS = Object.freeze({
  PORTRAIT: "portrait",
  PROTOTYPE: "prototype",
  CURRENT_TOKEN: "current-token",
  SCENE_TOKENS: "scene-tokens",
  PORTRAIT_PROTOTYPE: "portrait-prototype",
  PORTRAIT_CURRENT: "portrait-current",
  EVERYTHING: "everything",
  ASK: "ask"
});

export const SEQUENCE_MODES = Object.freeze({
  CLAMP: "clamp",
  LOOP: "loop",
  PING_PONG: "pingpong"
});

export const SEQUENCE_TARGET_TYPES = Object.freeze({
  ENTRY: "entry",
  PROFILE: "profile"
});

export const AUTOMATION_TRIGGER_TYPES = Object.freeze({
  ACTOR_UPDATE: "actor-update",
  TOKEN_UPDATE: "token-update",
  COMBAT_START: "combat-start",
  COMBAT_END: "combat-end",
  COMBAT_TURN: "combat-turn",
  SCENE_ACTIVATED: "scene-activated",
  TOKEN_ENTER_SCENE: "token-enter-scene",
  ACTIVE_EFFECT_CHANGE: "active-effect-change",
  MANUAL: "manual"
});

export const AUTOMATION_ACTION_TYPES = Object.freeze({
  APPLY_ENTRY: "apply-entry",
  APPLY_PROFILE: "apply-profile",
  SEQUENCE_NEXT: "sequence-next",
  SEQUENCE_PREVIOUS: "sequence-previous",
  SEQUENCE_RESET: "sequence-reset",
  SEQUENCE_STEP: "sequence-step",
  APPLY_TEMPORARY: "apply-temporary",
  REVERT_TEMPORARY: "revert-temporary"
});

export const CONDITION_OPERATORS = Object.freeze({
  EQ: "eq",
  NEQ: "neq",
  LT: "lt",
  LTE: "lte",
  GT: "gt",
  GTE: "gte",
  CONTAINS: "contains",
  NOT_CONTAINS: "notContains",
  EXISTS: "exists",
  NOT_EXISTS: "notExists"
});

export const CONDITION_GROUP_OPERATORS = Object.freeze({ AND: "AND", OR: "OR" });
export const MANUAL_OVERRIDE_POLICIES = Object.freeze({ RESPECT: "respect", REPLACE: "replace", ASK: "ask" });
export const MANUAL_OVERRIDE_DURATIONS = Object.freeze({
  UNTIL_CLEARED: "until-cleared",
  SCENE_CHANGE: "scene-change",
  COMBAT_END: "combat-end"
});

export const SORT_MODES = Object.freeze({
  MANUAL: "manual",
  NAME: "name",
  RECENT: "recent",
  USED: "used",
  FAVORITES: "favorites"
});

export const PRESET_KINDS = Object.freeze({
  PORTRAIT: "portrait",
  TOKEN: "token"
});

export const IMAGE_FITS = Object.freeze({
  CONTAIN: "contain",
  COVER: "cover"
});

export const DEFAULT_ADJUSTMENTS = Object.freeze({
  brightness: 100,
  contrast: 100,
  saturation: 100,
  temperature: 0,
  exposure: 0,
  shadows: 0,
  highlights: 0,
  grayscale: 0,
  blur: 0
});

export const DEFAULT_PRESET = Object.freeze({
  fit: IMAGE_FITS.CONTAIN,
  zoom: 1,
  positionX: 0,
  positionY: 0,
  rotation: 0,
  flipX: false,
  flipY: false,
  adjustments: DEFAULT_ADJUSTMENTS
});

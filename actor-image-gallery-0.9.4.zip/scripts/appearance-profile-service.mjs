import { CAPABILITIES, HOOKS, MODULE_ID } from "./constants.mjs";
import {
  addAppearanceProfile,
  AppearanceProfileError,
  removeAppearanceProfile,
  updateAppearanceProfile
} from "./domain/appearance-profile.mjs";
import { createPreset, recordUsage, updateEntry } from "./domain/gallery.mjs";
import { assertCapability } from "./entitlements.mjs";
import { DerivedImageRenderer } from "./foundry/image-application.mjs";
import { deepClone, warn } from "./utils.mjs";

export class AppearanceProfileService {
  #repository;
  #entitlements;
  #renderer;

  constructor({ repository, entitlements, renderer = new DerivedImageRenderer() }) {
    this.#repository = repository;
    this.#entitlements = entitlements;
    this.#renderer = renderer;
  }

  list(actor) {
    this.#assertAccess();
    return deepClone(this.#repository.read(actor).profiles);
  }

  async create(actor, input) {
    this.#assertAccess();
    const mutation = await this.#repository.mutate(actor, (gallery) => {
      const result = addAppearanceProfile(gallery, input);
      return { gallery: result.gallery, value: result.profile };
    });
    const profile = mutation.gallery.profiles.find((candidate) => candidate.id === mutation.value?.id) ?? mutation.value;
    callHook(HOOKS.PROFILE_ADDED, actor, deepClone(profile));
    return profile;
  }

  async update(actor, profileId, patch) {
    this.#assertAccess();
    const mutation = await this.#repository.mutate(actor, (gallery) => {
      const result = updateAppearanceProfile(gallery, profileId, patch);
      return { gallery: result.gallery, value: result.profile };
    });
    const profile = mutation.gallery.profiles.find((candidate) => candidate.id === String(profileId));
    callHook(HOOKS.PROFILE_UPDATED, actor, deepClone(profile));
    return profile;
  }

  async remove(actor, profileId) {
    this.#assertAccess();
    const mutation = await this.#repository.mutate(actor, (gallery) => {
      const result = removeAppearanceProfile(gallery, profileId);
      return { gallery: result.gallery, value: result.profile };
    });
    callHook(HOOKS.PROFILE_REMOVED, actor, deepClone(mutation.value));
    return mutation.value;
  }

  async previewPlan(actor, profileId) {
    this.#assertAccess();
    const gallery = this.#repository.read(actor);
    const profile = findProfile(gallery, profileId);
    return this.#resolvePlan(actor, gallery, profile);
  }

  async apply(actor, profileId, { preserveActiveSequence = false, applicationContext = null } = {}) {
    this.#assertAccess();
    const gallery = this.#repository.read(actor);
    const profile = findProfile(gallery, profileId);
    const plan = await this.#resolvePlan(actor, gallery, profile);
    let actorAttempted = false;
    let sceneAttempted = false;
    try {
      if (Object.keys(plan.actor.patch).length) {
        actorAttempted = true;
        await actor.update(plan.actor.patch, { [MODULE_ID]: applicationContext ?? { origin: "manual", source: "appearance-profile", profileId: profile.id } });
      }
      if (plan.scene.patches.length) {
        sceneAttempted = true;
        await plan.scene.document.updateEmbeddedDocuments("Token", plan.scene.patches, {
          [MODULE_ID]: applicationContext ?? { origin: "manual", source: "appearance-profile", profileId: profile.id }
        });
      }

      const mutation = await this.#repository.mutate(actor, (current) => {
        let next = current;
        const usageRecorded = new Set();
        for (const resolved of uniqueResolvedEntries(plan.resolved)) {
          if (resolved.derived) {
            const currentEntry = next.entries.find((candidate) => candidate.id === resolved.entry.id);
            if (currentEntry) {
              next = updateEntry(next, resolved.entry.id, {
                derived: { ...currentEntry.derived, [resolved.kind]: resolved.derived }
              }).gallery;
            }
          }
          if (!usageRecorded.has(resolved.entry.id) && next.entries.some((candidate) => candidate.id === resolved.entry.id)) {
            next = recordUsage(next, resolved.entry.id).gallery;
            usageRecorded.add(resolved.entry.id);
          }
        }
        return { ...next, activeProfileId: profile.id, activeSequenceId: preserveActiveSequence ? next.activeSequenceId : null, temporaryState: null };
      }, applicationContext ? { context: applicationContext } : {});

      const appliedProfile = mutation.gallery.profiles.find((candidate) => candidate.id === profile.id) ?? profile;
      const result = {
        actor,
        profile: deepClone(appliedProfile),
        changed: deepClone(plan.changed),
        temporaryCleared: Boolean(gallery.temporaryState)
      };
      callHook(HOOKS.APPEARANCE_CHANGED, { actor, profile: deepClone(appliedProfile), source: "appearance-profile", origin: applicationContext?.origin ?? "manual", applicationContext: applicationContext ? deepClone(applicationContext) : null, changed: deepClone(plan.changed) });
      callHook(HOOKS.PROFILE_APPLIED, result);
      if (result.temporaryCleared) callHook(HOOKS.TEMPORARY_CLEARED, { actor, state: deepClone(gallery.temporaryState), reason: "profile-apply" });
      return result;
    } catch (error) {
      const rollbackErrors = await rollbackPlan(plan, { actor, actorAttempted, sceneAttempted, applicationContext });
      if (rollbackErrors.length) error.rollbackErrors = rollbackErrors;
      throw error;
    }
  }

  async #resolvePlan(actor, gallery, profile) {
    const tokenRequested = Boolean(profile.token || Object.keys(profile.tokenVisual ?? {}).length)
      && (profile.prototypeToken || profile.sceneTokens);
    if (gallery.ignoreTokenChanges && !profile.portrait && tokenRequested) throw new AppearanceProfileError("tokenDisabledForGallery");

    const portrait = profile.portrait ? await resolveReference(this.#renderer, actor, gallery, profile, profile.portrait, "portrait") : null;
    const token = !gallery.ignoreTokenChanges && profile.token
      ? await resolveReference(this.#renderer, actor, gallery, profile, profile.token, "token")
      : null;
    const resolved = { portrait, token };
    return buildAppearanceProfilePlan(actor, profile, resolved, {
      ignoreTokenChanges: gallery.ignoreTokenChanges,
      scene: globalThis.canvas?.scene ?? null
    });
  }

  #assertAccess() {
    assertCapability(this.#entitlements, CAPABILITIES.APPEARANCE_PROFILES);
  }
}

export function buildAppearanceProfilePlan(actor, profile, resolved, { ignoreTokenChanges = false, scene = null } = {}) {
  if (!actor) throw new AppearanceProfileError("actorRequired");
  const actorPatch = {};
  const changed = { portrait: false, prototypeToken: false, sceneTokens: 0, tokenVisual: [] };
  if (resolved.portrait?.source) {
    actorPatch.img = resolved.portrait.source;
    changed.portrait = true;
  }

  const visual = ignoreTokenChanges ? {} : profile.tokenVisual ?? {};
  const prototypePatch = !ignoreTokenChanges && profile.prototypeToken
    ? tokenPatch(resolved.token?.source, visual, "prototypeToken.")
    : {};
  Object.assign(actorPatch, prototypePatch);
  changed.prototypeToken = Object.keys(prototypePatch).length > 0;
  changed.tokenVisual = visualPaths(visual);

  const sceneDocuments = !ignoreTokenChanges && profile.sceneTokens ? getSceneActorTokens(actor, scene) : [];
  const perToken = tokenPatch(resolved.token?.source, visual);
  const scenePatches = Object.keys(perToken).length
    ? sceneDocuments.map((document) => ({ _id: document.id, ...perToken }))
    : [];
  changed.sceneTokens = scenePatches.length;

  if (!Object.keys(actorPatch).length && !scenePatches.length) throw new AppearanceProfileError("profileNoApplicableChanges");
  return {
    profileId: profile.id,
    actor: {
      patch: actorPatch,
      before: snapshotPaths(actor, Object.keys(actorPatch)),
      expected: deepClone(actorPatch)
    },
    scene: {
      document: scene,
      documents: sceneDocuments,
      patches: scenePatches,
      before: sceneDocuments.map((document) => ({ _id: document.id, ...snapshotPaths(document, Object.keys(perToken)) })),
      expected: deepClone(perToken)
    },
    resolved,
    changed
  };
}

export class AppearanceProfileApplicationError extends Error {
  constructor(code) {
    super(code);
    this.name = "AppearanceProfileApplicationError";
    this.code = code;
  }
}

async function resolveReference(renderer, actor, gallery, profile, reference, kind) {
  let entry = null;
  if (reference.entryId) {
    entry = gallery.entries.find((candidate) => candidate.id === reference.entryId);
    if (!entry) throw new AppearanceProfileApplicationError("profileReferenceMissing");
  } else if (reference.source) {
    entry = {
      id: `${profile.id}-${kind}`,
      source: reference.source,
      portrait: createPreset(kind === "portrait" ? reference.preset : {}),
      token: createPreset(kind === "token" ? reference.preset : {}),
      derived: {}
    };
  }
  if (!entry?.source) throw new AppearanceProfileApplicationError("profileReferenceMissing");
  if (reference.source && reference.entryId) entry = { ...entry, source: reference.source };
  if (reference.preset) entry = { ...entry, [kind]: createPreset(reference.preset), derived: {} };
  const result = await renderer.resolve(actor, entry, kind);
  if (!result?.source) throw new AppearanceProfileApplicationError("profileReferenceMissing");
  return { ...result, entry, kind };
}

function tokenPatch(source, visual, prefix = "") {
  const patch = {};
  if (source) patch[`${prefix}texture.src`] = source;
  if (visual.scale !== undefined) {
    patch[`${prefix}texture.scaleX`] = visual.scale;
    patch[`${prefix}texture.scaleY`] = visual.scale;
  }
  if (visual.width !== undefined) patch[`${prefix}width`] = visual.width;
  if (visual.height !== undefined) patch[`${prefix}height`] = visual.height;
  if (visual.tint !== undefined) patch[`${prefix}texture.tint`] = visual.tint;
  if (visual.alpha !== undefined) patch[`${prefix}alpha`] = visual.alpha;
  if (visual.ring?.enabled !== undefined) patch[`${prefix}ring.enabled`] = visual.ring.enabled;
  if (visual.ring?.effects !== undefined) patch[`${prefix}ring.effects`] = visual.ring.effects;
  if (visual.ring?.colors?.ring !== undefined) patch[`${prefix}ring.colors.ring`] = visual.ring.colors.ring;
  if (visual.ring?.colors?.background !== undefined) patch[`${prefix}ring.colors.background`] = visual.ring.colors.background;
  return patch;
}

function visualPaths(visual) {
  return Object.keys(tokenPatch(null, visual)).map((path) => path.replace(/^texture\./, "")).sort();
}

async function rollbackPlan(plan, { actor, actorAttempted, sceneAttempted, applicationContext = null }) {
  const errors = [];
  if (sceneAttempted && plan.scene.document) {
    try {
      const updates = plan.scene.documents.map((document) => rollbackPatch(document, plan.scene.before.find((item) => item._id === document.id), plan.scene.expected));
      const filtered = updates.filter((patch) => Object.keys(patch).length > 1);
      if (filtered.length) await plan.scene.document.updateEmbeddedDocuments("Token", filtered, { [MODULE_ID]: applicationContext ?? { origin: "manual", source: "appearance-profile-rollback" } });
    } catch (error) {
      errors.push(error);
    }
  }
  if (actorAttempted) {
    try {
      const patch = rollbackPatch(actor, plan.actor.before, plan.actor.expected, false);
      if (Object.keys(patch).length) await actor.update(patch, { [MODULE_ID]: applicationContext ?? { origin: "manual", source: "appearance-profile-rollback" } });
    } catch (error) {
      errors.push(error);
    }
  }
  return errors;
}

function rollbackPatch(document, before, expected, includeId = true) {
  const patch = includeId ? { _id: document.id } : {};
  for (const [path, value] of Object.entries(before ?? {})) {
    if (path === "_id") continue;
    if (sameValue(readPath(document, path), expected[path])) patch[path] = deepClone(value);
  }
  return patch;
}

function snapshotPaths(document, paths) {
  return Object.fromEntries(paths.map((path) => [path, deepClone(readPath(document, path))]));
}

function readPath(object, path) {
  return String(path).split(".").reduce((value, key) => value?.[key], object);
}

function sameValue(left, right) {
  return JSON.stringify(left) === JSON.stringify(right);
}

function getSceneActorTokens(actor, scene) {
  return Array.from(scene?.tokens ?? []).filter((document) => document.actorId === actor.id || document.actor?.id === actor.id);
}

function findProfile(gallery, profileId) {
  const profile = gallery.profiles.find((candidate) => candidate.id === String(profileId));
  if (!profile) throw new AppearanceProfileError("profileNotFound");
  return profile;
}

function uniqueResolvedEntries(resolved) {
  const seen = new Set();
  return Object.values(resolved).filter((item) => {
    if (!item?.entry?.id || seen.has(`${item.entry.id}:${item.kind}`)) return false;
    seen.add(`${item.entry.id}:${item.kind}`);
    return true;
  });
}

function callHook(name, ...args) {
  try {
    globalThis.Hooks?.callAll?.(name, ...args);
  } catch (error) {
    warn(`Integration hook ${name} failed.`, error);
  }
}

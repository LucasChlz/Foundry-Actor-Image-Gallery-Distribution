import { CONDITION_GROUP_OPERATORS, CONDITION_OPERATORS } from "../constants.mjs";
import { normalizeConditionTree } from "../domain/automation-rule.mjs";

export function evaluateConditionTree(input, facts = {}) {
  const tree = normalizeConditionTree(input);
  const conditions = [];
  const matched = evaluateNode(tree, facts, conditions);
  return { matched, conditions, tree };
}

function evaluateNode(node, facts, conditions) {
  if (Array.isArray(node.children)) {
    if (!node.children.length) return true;
    if (node.operator === CONDITION_GROUP_OPERATORS.OR) {
      let matched = false;
      for (const child of node.children) matched = evaluateNode(child, facts, conditions) || matched;
      return matched;
    }
    let matched = true;
    for (const child of node.children) matched = evaluateNode(child, facts, conditions) && matched;
    return matched;
  }
  const actual = facts[node.fact];
  const result = compare(actual, node.operator, node.value);
  conditions.push({ fact: node.fact, operator: node.operator, actual, expected: node.value, matched: result });
  return result;
}

export function compare(actual, operator, expected) {
  if (operator === CONDITION_OPERATORS.EXISTS) return actual !== undefined && actual !== null;
  if (operator === CONDITION_OPERATORS.NOT_EXISTS) return actual === undefined || actual === null;
  if (operator === CONDITION_OPERATORS.EQ) return same(actual, expected);
  if (operator === CONDITION_OPERATORS.NEQ) return !same(actual, expected);
  if (operator === CONDITION_OPERATORS.CONTAINS) return contains(actual, expected);
  if (operator === CONDITION_OPERATORS.NOT_CONTAINS) return !contains(actual, expected);
  const left = Number(actual);
  const right = Number(expected);
  if (!Number.isFinite(left) || !Number.isFinite(right)) return false;
  if (operator === CONDITION_OPERATORS.LT) return left < right;
  if (operator === CONDITION_OPERATORS.LTE) return left <= right;
  if (operator === CONDITION_OPERATORS.GT) return left > right;
  if (operator === CONDITION_OPERATORS.GTE) return left >= right;
  return false;
}

function same(left, right) {
  if (typeof left === "number" || typeof right === "number") {
    const leftNumber = Number(left);
    const rightNumber = Number(right);
    if (Number.isFinite(leftNumber) && Number.isFinite(rightNumber)) return leftNumber === rightNumber;
  }
  return JSON.stringify(left) === JSON.stringify(right);
}

function contains(container, value) {
  if (Array.isArray(container)) return container.some((item) => same(item, value));
  if (typeof container === "string") return container.toLocaleLowerCase().includes(String(value ?? "").toLocaleLowerCase());
  if (container && typeof container === "object") return Object.hasOwn(container, String(value));
  return false;
}

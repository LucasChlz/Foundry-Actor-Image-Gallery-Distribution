export class SystemAdapterRegistry {
  #adapters = [];

  register(adapter) {
    if (!adapter?.id || typeof adapter.supports !== "function" || typeof adapter.registerFacts !== "function") {
      throw new SystemAdapterError("automationAdapterInvalid");
    }
    this.#adapters = [...this.#adapters.filter((candidate) => candidate.id !== adapter.id), adapter];
    return () => { this.#adapters = this.#adapters.filter((candidate) => candidate.id !== adapter.id); };
  }

  activate(systemId, factRegistry) {
    const adapter = this.#adapters.find((candidate) => candidate.supports(String(systemId ?? ""))) ?? null;
    if (adapter) adapter.registerFacts(factRegistry);
    return adapter;
  }

  list() {
    return this.#adapters.map((adapter) => ({ id: adapter.id }));
  }
}

export class Dnd5eAutomationAdapter {
  id = "dnd5e";
  supports(systemId) { return systemId === "dnd5e"; }
  registerFacts(registry) { registerHpFacts(registry, this.id, (actor) => actor?.system?.attributes?.hp); }
}

export class Pf2eAutomationAdapter {
  id = "pf2e";
  supports(systemId) { return systemId === "pf2e"; }
  registerFacts(registry) { registerHpFacts(registry, this.id, (actor) => actor?.system?.attributes?.hp); }
}

export function createDefaultSystemAdapterRegistry() {
  const registry = new SystemAdapterRegistry();
  registry.register(new Dnd5eAutomationAdapter());
  registry.register(new Pf2eAutomationAdapter());
  return registry;
}

export class SystemAdapterError extends Error {
  constructor(code) {
    super(code);
    this.name = "SystemAdapterError";
    this.code = code;
  }
}

function registerHpFacts(registry, source, resolver) {
  const definition = (key, provider) => registry.register(key, provider, {
    label: `AIG.automation.facts.${key}`,
    type: "number",
    source
  });
  definition("hp.current", ({ actor }) => hpValue(resolver(actor), "value"));
  definition("hp.max", ({ actor }) => hpValue(resolver(actor), "max"));
  definition("hp.percent", ({ actor }) => {
    const hp = resolver(actor);
    const current = hpValue(hp, "value");
    const maximum = hpValue(hp, "max");
    return maximum > 0 ? Math.max(0, Math.min(100, current / maximum * 100)) : null;
  });
}

function hpValue(hp, key) {
  const number = Number(hp?.[key]);
  return Number.isFinite(number) ? number : null;
}

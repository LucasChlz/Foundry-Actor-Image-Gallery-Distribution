import { MODULE_ID } from "./constants.mjs";
import { localize } from "./utils.mjs";

export function registerIntegrations(runtime) {
  // The sheet gets one Gallery button; Quick Switch opens from the sheet's portrait (attachPortraitQuickSwitch).
  Hooks.on("getActorSheetHeaderButtons", (application, buttons) => {
    const actor = resolveActor(application);
    if (!actor || buttons.some((button) => button.class === `${MODULE_ID}-open`)) return;
    buttons.unshift({
      label: localize("actions.gallery"),
      class: `${MODULE_ID}-open`,
      icon: "fas fa-images",
      onclick: () => runtime().openGallery(actor, { token: application.token?.object ?? null })
    });
  });

  Hooks.on("renderActorSheet", (application, element) => attachPortraitQuickSwitch(application, element, runtime));

  Hooks.on("renderApplicationV2", (application, element) => {
    if (!isActorSheet(application)) return;
    const actor = resolveActor(application);
    const root = normalizeElement(element);
    if (!actor || !root || root.matches?.(".aig-shell") || root.querySelector?.(".aig-shell")) return;
    attachHeaderGalleryButton(root, {
      label: localize("actions.gallery"),
      onClick: () => runtime().openGallery(actor, { token: application.token?.object ?? null })
    });
    attachPortraitQuickSwitch(application, root, runtime);
  });

  Hooks.on("renderTokenHUD", (hud, element) => {
    if (!getSetting("enableTokenFeatures", true)) return;
    const root = normalizeElement(element);
    const token = hud.object ?? hud.token ?? globalThis.canvas?.tokens?.hud?.object;
    if (!root || !token?.actor || root.querySelector?.(".aig-token-hud-button")) return;
    const button = document.createElement("button");
    button.type = "button";
    button.className = "control-icon aig-token-hud-button";
    button.dataset.tooltip = localize("quick.open");
    button.setAttribute("aria-label", localize("quick.open"));
    button.innerHTML = '<i class="fa-solid fa-images" aria-hidden="true"></i>';
    button.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      void runtime().openQuickSwitch(token, { anchor: button });
    });
    const column = root.querySelector?.(".col.right") ?? root;
    column.append(button);
  });

  Hooks.on("getSceneControlButtons", (controls) => attachSceneControl(controls, runtime));

  Hooks.on("controlToken", (token, controlled) => {
    if (controlled && token.actor) void runtime().preloadActor(token.actor);
  });

  Hooks.on("canvasReady", () => void runtime().preloadScene());
  Hooks.on("updateActor", (actor) => void runtime().refreshActor(actor));
  Hooks.on("updateToken", (tokenDocument) => void runtime().refreshActor(tokenDocument.actor));

  Hooks.on("getActorDirectoryEntryContext", (_html, options) => {
    if (!Array.isArray(options)) return;
    options.push({
      name: localize("actions.gallery"),
      icon: '<i class="fa-solid fa-images"></i>',
      condition: (target) => Boolean(resolveDirectoryActor(target)),
      callback: (target) => {
        const actor = resolveDirectoryActor(target);
        if (actor) void runtime().openGallery(actor);
      }
    });
  });
}

/**
 * Puts the Gallery icon among the sheet's header icons, first after the title. It is a real Foundry `header-control`
 * (same size, tooltip, hidden while minimized), and the accent chip in the CSS keeps it findable next to the icons of
 * the system and other modules. It is added to the header directly, not through getHeaderControlsApplicationV2:
 * that hook files it under the ⋮ menu on most sheets.
 * The header is rendered once per window, so later renders find the button and leave it alone.
 */
export function attachHeaderGalleryButton(root, { label, onClick }) {
  const header = root?.querySelector?.(":scope > .window-header");
  if (!header) return null;
  const existing = header.querySelector(":scope > .aig-header-gallery");
  if (existing) return existing;
  const button = header.ownerDocument.createElement("button");
  button.type = "button";
  button.className = "header-control icon fa-solid fa-images aig-header-gallery";
  button.dataset.tooltip = label;
  button.setAttribute("aria-label", label);
  button.addEventListener("click", (event) => {
    event.preventDefault();
    event.stopPropagation();
    onClick(event);
  });
  const title = header.querySelector(":scope > .window-title");
  if (title) title.after(button);
  else header.querySelector(':scope > [data-action="toggleControls"], :scope > [data-action="close"]')?.before(button) ?? header.append(button);
  return button;
}

function attachPortraitQuickSwitch(application, element, runtime) {
  if (!getSetting("enablePortraitFeatures", true) || !getSetting("portraitClickQuickSwitch", true)) return;
  const actor = resolveActor(application);
  const root = normalizeElement(element);
  if (!actor || !root) return;
  const portrait = findActorPortrait(root, actor);
  if (!portrait || portrait.dataset.aigQuickSwitch === "true") return;
  portrait.dataset.aigQuickSwitch = "true";
  portrait.classList.add("aig-sheet-portrait-trigger");
  portrait.tabIndex = portrait.tabIndex >= 0 ? portrait.tabIndex : 0;
  portrait.setAttribute("aria-haspopup", "dialog");
  portrait.title = localize("quick.portraitClickHint");
  const host = portrait.parentElement;
  if (host && !host.querySelector(":scope > .aig-sheet-portrait-badge")) {
    host.classList.add("aig-sheet-portrait-host");
    const badge = document.createElement("span");
    badge.className = "aig-sheet-portrait-badge";
    badge.setAttribute("aria-hidden", "true");
    badge.innerHTML = '<i class="fa-solid fa-bolt"></i>';
    host.append(badge);
  }
  const open = (event) => {
    if (event.type === "click" && event.shiftKey) return;
    if (event.type === "keydown" && !["Enter", " "].includes(event.key)) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    void runtime().openQuickSwitch(actor, {
      anchor: portrait,
      origin: "sheet",
      token: application.token?.object ?? null
    });
  };
  portrait.addEventListener("click", open, true);
  portrait.addEventListener("keydown", open, true);
}

function findActorPortrait(root, actor) {
  const selectors = [
    'img[data-edit="img"]',
    'img[data-action="editImage"]',
    "img.profile-img",
    ".profile img",
    ".portrait img",
    "img.actor-image"
  ];
  const explicit = selectors.flatMap((selector) => Array.from(root.querySelectorAll?.(selector) ?? []));
  const candidates = explicit.length ? explicit : Array.from(root.querySelectorAll?.("img") ?? []);
  return candidates.find((image) => sameImageSource(image.getAttribute("src"), actor.img)) ?? explicit[0] ?? null;
}

function sameImageSource(left, right) {
  if (!left || !right) return false;
  try {
    return new URL(left, globalThis.location?.href).href === new URL(right, globalThis.location?.href).href;
  } catch {
    return String(left).replace(/^\.\//, "") === String(right).replace(/^\.\//, "");
  }
}

// Only the Actor's own sheet gets the buttons. Sheet Configuration, Ownership, Token and Prototype
// Token windows also carry the Actor (as document, token.actor or actor) and got them too.
export function isActorSheet(application) {
  const ActorSheetV2 = globalThis.foundry?.applications?.sheets?.ActorSheetV2;
  return typeof ActorSheetV2 === "function" && application instanceof ActorSheetV2;
}

export function resolveActor(application) {
  const candidates = [
    application?.document,
    application?.object,
    application?.actor,
    application?.token?.actor,
    application?.object?.actor
  ];
  return candidates.find((candidate) => candidate?.documentName === "Actor" || candidate?.constructor?.metadata?.name === "Actor") ?? null;
}

function attachSceneControl(controls, runtime) {
  const callback = () => runtime().openSelected();
  if (Array.isArray(controls)) {
    const tokens = controls.find((control) => control.name === "token" || control.name === "tokens");
    if (!tokens?.tools || tokens.tools.some((tool) => tool.name === `${MODULE_ID}-open`)) return;
    tokens.tools.push({
      name: `${MODULE_ID}-open`,
      title: localize("actions.gallery"),
      icon: "fa-solid fa-images",
      button: true,
      visible: true,
      onClick: callback
    });
    return;
  }
  const tokens = controls?.tokens ?? controls?.token ?? Object.values(controls ?? {}).find((control) => control?.tools);
  if (!tokens?.tools) return;
  if (Array.isArray(tokens.tools)) return attachSceneControl([tokens], runtime);
  if (tokens.tools[`${MODULE_ID}-open`]) return;
  tokens.tools[`${MODULE_ID}-open`] = {
    name: `${MODULE_ID}-open`,
    title: localize("actions.gallery"),
    icon: "fa-solid fa-images",
    button: true,
    visible: true,
    order: Object.keys(tokens.tools).length + 100,
    onChange: callback
  };
}

function resolveDirectoryActor(target) {
  const element = normalizeElement(target);
  const id = element?.closest?.("[data-entry-id], [data-document-id]")?.dataset?.entryId
    ?? element?.closest?.("[data-entry-id], [data-document-id]")?.dataset?.documentId;
  return id ? globalThis.game?.actors?.get?.(id) : null;
}

function normalizeElement(value) {
  if (value instanceof globalThis.HTMLElement) return value;
  return value?.[0] instanceof globalThis.HTMLElement ? value[0] : null;
}

function getSetting(key, fallback) {
  try {
    return globalThis.game?.settings?.get?.(MODULE_ID, key) ?? fallback;
  } catch {
    return fallback;
  }
}

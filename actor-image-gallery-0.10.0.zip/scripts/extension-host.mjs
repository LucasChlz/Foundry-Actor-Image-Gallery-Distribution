import { APPLY_TARGETS, EXTENSION_API_VERSION, FLAG_KEY, HOOKS, IMAGE_FITS, MODULE_ID, PRESET_KINDS, SORT_MODES } from "./constants.mjs";
import { createGallery, createPreset, getCollections, normalizeTags, presetCss, queryEntries, recordUsage, updateEntry } from "./domain/gallery.mjs";
import { applyPalette, DEFAULT_PALETTE } from "./palette.mjs";
import { resolveQuickTarget } from "./ui/quick-switch.mjs";
import { actorCanUpdate, confirmAction, deepClone, escapeAttribute, escapeHtml, getActiveTokenForActor, localize, notify, warn } from "./utils.mjs";

// The narrow, versioned surface handed to companion modules. Everything exposed
// here already belongs to the Free runtime, so a companion never imports Free
// files by path. Writes still pass through the Free repository queue and its
// normalizer, which keeps premium fields opaque and core fields valid.
export function createExtensionHost({
  coreVersion = null,
  repository,
  applicator,
  temporaryService,
  renderer,
  runtime = {},
  hasCapability = () => false,
  getSetting = readCoreSetting
}) {
  return Object.freeze({
    apiVersion: EXTENSION_API_VERSION,
    coreModuleId: MODULE_ID,
    coreVersion,
    flagKey: FLAG_KEY,
    constants: Object.freeze({ APPLY_TARGETS, HOOKS, IMAGE_FITS, PRESET_KINDS, SORT_MODES }),
    repository: Object.freeze({
      read: (actor) => repository.read(actor),
      mutate: (actor, mutator, options = {}) => repository.mutate(actor, mutator, options)
    }),
    applicator: Object.freeze({
      apply: (actor, entryOrId, target, options = {}) => applicator.apply(actor, entryOrId, target, options)
    }),
    temporary: Object.freeze({
      apply: (actor, entryId, target, options = {}) => temporaryService.apply(actor, entryId, target, options),
      revert: (actor, options = {}) => temporaryService.revert(actor, options)
    }),
    images: Object.freeze({
      resolve: (actor, entry, kind) => renderer.resolve(actor, entry, kind)
    }),
    domain: Object.freeze({ createGallery, createPreset, getCollections, normalizeTags, presetCss, queryEntries, recordUsage, updateEntry }),
    ui: Object.freeze({ applyPalette, confirmAction, DEFAULT_PALETTE, escapeAttribute, escapeHtml, localize, notify, warn }),
    permissions: Object.freeze({ actorCanUpdate }),
    tokens: Object.freeze({ getActiveTokenForActor }),
    settings: Object.freeze({ get: (key, fallback = null) => getSetting(key, fallback) }),
    utils: Object.freeze({ deepClone }),
    resolveQuickTarget,
    hasCapability: (capability) => Boolean(hasCapability(capability)),
    runtime: Object.freeze({
      openGallery: (actorOrUuid, options = {}) => runtime.openGallery?.(actorOrUuid, options) ?? null,
      openQuickSwitch: (actorOrToken, options = {}) => runtime.openQuickSwitch?.(actorOrToken, options) ?? null,
      closeQuickSwitch: () => runtime.closeQuickSwitch?.(),
      quickSwitchMode: () => runtime.quickSwitchMode?.() ?? null,
      refreshActor: (actor) => runtime.refreshActor?.(actor),
      resolveActor: (input, token = null) => runtime.resolveActor?.(input, token) ?? { actor: null, token: null }
    })
  });
}

function readCoreSetting(key, fallback) {
  try {
    return globalThis.game?.settings?.get?.(MODULE_ID, key) ?? fallback;
  } catch {
    return fallback;
  }
}

import {
  APPLY_TARGETS,
  AUTOMATION_ACTION_TYPES,
  AUTOMATION_TRIGGER_TYPES,
  CAPABILITIES,
  HOOKS,
  MANUAL_OVERRIDE_DURATIONS,
  MANUAL_OVERRIDE_POLICIES,
  MODULE_ID
} from "./constants.mjs";
import {
  addAutomationRule,
  AutomationRuleError,
  duplicateAutomationRule,
  normalizeAutomationRules,
  normalizeAutomationState,
  removeAutomationRule,
  reorderAutomationRules,
  updateAutomationRule,
  validateAutomationRule
} from "./domain/automation-rule.mjs";
import { assertCapability } from "./entitlements.mjs";
import { evaluateConditionTree } from "./automation/condition-evaluator.mjs";
import { deepClone, randomId, warn } from "./utils.mjs";

export class AutomationRuleService {
  #repository;
  #applicator;
  #profileService;
  #sequenceService;
  #temporaryService;
  #entitlements;
  #facts;
  #confirmOverride;
  #manualOverrideDuration;
  #clock;
  #activeActors = new Set();

  constructor({
    repository,
    applicator,
    profileService,
    sequenceService,
    temporaryService,
    entitlements,
    factRegistry,
    confirmOverride = async () => false,
    manualOverrideDuration = () => MANUAL_OVERRIDE_DURATIONS.UNTIL_CLEARED,
    clock = () => Date.now()
  }) {
    this.#repository = repository;
    this.#applicator = applicator;
    this.#profileService = profileService;
    this.#sequenceService = sequenceService;
    this.#temporaryService = temporaryService;
    this.#entitlements = entitlements;
    this.#facts = factRegistry;
    this.#confirmOverride = confirmOverride;
    this.#manualOverrideDuration = manualOverrideDuration;
    this.#clock = clock;
  }

  list(actor) {
    this.#assertAccess();
    return deepClone(normalizeAutomationRules(this.#repository.read(actor).automationRules));
  }

  getState(actor) {
    this.#assertAccess();
    const gallery = this.#repository.read(actor);
    const rules = normalizeAutomationRules(gallery.automationRules);
    return deepClone(normalizeAutomationState(gallery.automationState, rules));
  }

  getDiagnostics(actor) {
    return this.getState(actor).lastEvaluation;
  }

  availableFacts() {
    this.#assertAccess();
    return this.#facts.list();
  }

  async create(actor, input) {
    this.#assertAccess();
    const mutation = await this.#repository.mutate(actor, (gallery) => {
      const result = addAutomationRule(gallery, input);
      return { gallery: result.gallery, value: result.rule };
    });
    const rule = normalizeAutomationRules(mutation.gallery.automationRules).find((candidate) => candidate.id === mutation.value?.id) ?? mutation.value;
    callHook(HOOKS.AUTOMATION_RULE_ADDED, actor, deepClone(rule));
    return rule;
  }

  async update(actor, ruleId, patch) {
    this.#assertAccess();
    const mutation = await this.#repository.mutate(actor, (gallery) => {
      const result = updateAutomationRule(gallery, ruleId, patch);
      return { gallery: result.gallery, value: result.rule };
    });
    const rule = normalizeAutomationRules(mutation.gallery.automationRules).find((candidate) => candidate.id === String(ruleId));
    callHook(HOOKS.AUTOMATION_RULE_UPDATED, actor, deepClone(rule));
    return rule;
  }

  async duplicate(actor, ruleId, { suffix } = {}) {
    this.#assertAccess();
    const mutation = await this.#repository.mutate(actor, (gallery) => {
      const result = duplicateAutomationRule(gallery, ruleId, { suffix });
      return { gallery: result.gallery, value: result.rule };
    });
    const rule = normalizeAutomationRules(mutation.gallery.automationRules).find((candidate) => candidate.id === mutation.value?.id) ?? mutation.value;
    callHook(HOOKS.AUTOMATION_RULE_ADDED, actor, deepClone(rule));
    return rule;
  }

  async reorder(actor, orderedIds) {
    this.#assertAccess();
    const mutation = await this.#repository.mutate(actor, (gallery) => reorderAutomationRules(gallery, orderedIds));
    const rules = deepClone(normalizeAutomationRules(mutation.gallery.automationRules));
    callHook(HOOKS.AUTOMATION_RULE_REORDERED, actor, rules);
    return rules;
  }

  async remove(actor, ruleId) {
    this.#assertAccess();
    const mutation = await this.#repository.mutate(actor, (gallery) => {
      const result = removeAutomationRule(gallery, ruleId);
      return { gallery: result.gallery, value: result.rule };
    });
    callHook(HOOKS.AUTOMATION_RULE_REMOVED, actor, deepClone(mutation.value));
    return mutation.value;
  }

  async markManualOverride(actor, { source = "manual", scene = null, combat = null, duration = null } = {}) {
    if (!actor || !this.#entitlements?.has?.(CAPABILITIES.AUTOMATION_RULES)) return null;
    const now = this.#clock();
    const selectedDuration = Object.values(MANUAL_OVERRIDE_DURATIONS).includes(duration)
      ? duration
      : this.#manualOverrideDuration();
    const manualOverride = {
      active: true,
      source: String(source),
      startedAt: now,
      duration: Object.values(MANUAL_OVERRIDE_DURATIONS).includes(selectedDuration)
        ? selectedDuration
        : MANUAL_OVERRIDE_DURATIONS.UNTIL_CLEARED,
      sceneId: String(scene?.id ?? globalThis.canvas?.scene?.id ?? "") || null,
      combatId: String(combat?.id ?? globalThis.game?.combat?.id ?? "") || null
    };
    const operationId = randomId();
    await this.#repository.mutate(actor, (gallery) => ({
      ...gallery,
      automationState: {
        ...normalizeAutomationState(gallery.automationState, normalizeAutomationRules(gallery.automationRules)),
        manualOverride
      }
    }), { context: automationContext(operationId, null, "manual-override-state") });
    callHook(HOOKS.MANUAL_OVERRIDE_CHANGED, { actor, manualOverride: deepClone(manualOverride) });
    return manualOverride;
  }

  async clearManualOverride(actor, { reason = "manual-clear" } = {}) {
    this.#assertAccess();
    const current = this.#repository.read(actor);
    const rules = normalizeAutomationRules(current.automationRules);
    const state = normalizeAutomationState(current.automationState, rules);
    if (!state.manualOverride) return false;
    const operationId = randomId();
    await this.#repository.mutate(actor, (gallery) => ({
      ...gallery,
      automationState: { ...normalizeAutomationState(gallery.automationState, normalizeAutomationRules(gallery.automationRules)), manualOverride: null }
    }), { context: automationContext(operationId, null, "manual-override-state") });
    callHook(HOOKS.MANUAL_OVERRIDE_CHANGED, { actor, manualOverride: null, reason });
    return true;
  }

  isApplying(actor) {
    return this.#activeActors.has(actorKey(actor));
  }

  async evaluate(actor, {
    token = null,
    trigger = { type: AUTOMATION_TRIGGER_TYPES.MANUAL },
    scene = globalThis.canvas?.scene ?? null,
    combat = globalThis.game?.combat ?? null,
    changes = null,
    force = false
  } = {}) {
    this.#assertAccess();
    if (!actor) throw new AutomationRuleError("actorRequired");
    const key = actorKey(actor);
    if (this.#activeActors.has(key)) return { applied: false, skipped: "self-update" };

    const operationId = randomId();
    const now = this.#clock();
    this.#activeActors.add(key);
    try {
      const gallery = this.#repository.read(actor);
      const rules = normalizeAutomationRules(gallery.automationRules);
      let state = normalizeAutomationState(gallery.automationState, rules);
      state.manualOverride = expireManualOverride(state.manualOverride, trigger, { scene, combat });
      const triggerType = String(trigger?.type ?? AUTOMATION_TRIGGER_TYPES.MANUAL);
      const eventName = String(trigger?.eventName ?? "");
      const factResult = await this.#facts.resolve({ actor, token, scene, combat, gallery: { ...gallery, automationState: state }, trigger: { type: triggerType, eventName }, changes });
      const availableFacts = new Set(this.#facts.list().map((fact) => fact.key));
      const failedFacts = new Set(factResult.errors.map((item) => item.key));
      const previousMatches = new Set(state.matchedRuleIds);
      const relevantRuleIds = new Set();
      const matchedRuleIds = new Set();
      const candidates = [];
      const suppressed = [];

      for (const rawRule of rules) {
        let rule;
        try {
          rule = validateAutomationRule(rawRule);
        } catch (error) {
          suppressed.push(suppression(rawRule, "invalid-rule"));
          continue;
        }
        if (!rule.enabled || !triggerMatches(rule.trigger, triggerType, eventName)) continue;
        relevantRuleIds.add(rule.id);
        const missingFact = collectFactKeys(rule.conditionTree).find((fact) => !availableFacts.has(fact) || failedFacts.has(fact));
        if (missingFact) {
          suppressed.push(suppression(rule, "fact-unavailable"));
          continue;
        }
        const evaluation = evaluateConditionTree(rule.conditionTree, factResult.facts);
        if (!evaluation.matched) {
          suppressed.push(suppression(rule, "conditions-false"));
          continue;
        }
        matchedRuleIds.add(rule.id);
        try {
          validateActionReferences(gallery, rule.action);
        } catch {
          suppressed.push(suppression(rule, "action-unavailable"));
          continue;
        }
        candidates.push({ rule, evaluation });
      }

      candidates.sort(compareRules);
      const currentMatches = new Set([...previousMatches].filter((id) => !relevantRuleIds.has(id)));
      for (const id of matchedRuleIds) currentMatches.add(id);
      let winner = null;
      for (const candidate of candidates) {
        const hasCooldown = Object.hasOwn(state.cooldowns, candidate.rule.id);
        const lastApplied = state.cooldowns[candidate.rule.id] ?? 0;
        if (!force && hasCooldown && candidate.rule.cooldownMs > 0 && now - lastApplied < candidate.rule.cooldownMs) {
          suppressed.push(suppression(candidate.rule, "cooldown"));
          continue;
        }
        if (state.manualOverride) {
          if (candidate.rule.manualOverridePolicy === MANUAL_OVERRIDE_POLICIES.RESPECT) {
            suppressed.push(suppression(candidate.rule, "manual-override"));
            continue;
          }
          if (candidate.rule.manualOverridePolicy === MANUAL_OVERRIDE_POLICIES.ASK) {
            const accepted = await this.#confirmOverride({ actor, rule: deepClone(candidate.rule), manualOverride: deepClone(state.manualOverride) });
            if (!accepted) {
              suppressed.push(suppression(candidate.rule, "manual-override-declined"));
              continue;
            }
          }
        }
        winner = candidate;
        break;
      }

      if (winner) {
        for (const candidate of candidates) {
          if (candidate.rule.id !== winner.rule.id && !suppressed.some((item) => item.ruleId === candidate.rule.id)) {
            suppressed.push(suppression(candidate.rule, "lower-priority"));
          }
        }
      }

      const isManualTrigger = triggerType === AUTOMATION_TRIGGER_TYPES.MANUAL;
      const shouldApply = Boolean(winner) && (force || isManualTrigger || !previousMatches.has(winner.rule.id) || state.lastAppliedRuleId !== winner.rule.id);
      let application = null;
      let outcome = winner ? "unchanged" : "none";
      let errorCode = null;
      if (winner && shouldApply) {
        try {
          validateActionReferences(gallery, winner.rule.action);
          application = await this.#executeAction(actor, token, winner.rule, operationId);
          outcome = "applied";
          state.cooldowns[winner.rule.id] = now;
          state.lastAppliedRuleId = winner.rule.id;
          state.lastAppliedAt = now;
          if (state.manualOverride && winner.rule.manualOverridePolicy !== MANUAL_OVERRIDE_POLICIES.RESPECT) state.manualOverride = null;
        } catch (error) {
          outcome = "error";
          errorCode = String(error?.code ?? error?.message ?? "automationActionFailed");
          await this.#persistState(actor, state, {
            evaluatedAt: now,
            triggerType,
            eventName,
            outcome,
            winnerRuleId: winner.rule.id,
            winnerName: winner.rule.name,
            errorCode,
            suppressed,
            conditions: winner.evaluation.conditions
          }, currentMatches, operationId);
          throw new AutomationExecutionError(errorCode, { cause: error });
        }
      }

      const diagnostic = {
        evaluatedAt: now,
        triggerType,
        eventName,
        outcome,
        winnerRuleId: winner?.rule.id ?? null,
        winnerName: winner?.rule.name ?? null,
        errorCode,
        suppressed,
        conditions: winner?.evaluation.conditions ?? candidates[0]?.evaluation.conditions ?? []
      };
      const persisted = await this.#persistState(actor, state, diagnostic, currentMatches, operationId);
      const result = {
        actor,
        trigger: { type: triggerType, eventName },
        winner: winner ? deepClone(winner.rule) : null,
        suppressed: deepClone(suppressed),
        diagnostic: deepClone(persisted.automationState.lastEvaluation),
        facts: deepClone(factResult.facts),
        factErrors: deepClone(factResult.errors),
        application,
        applied: outcome === "applied"
      };
      callHook(HOOKS.AUTOMATION_EVALUATED, result);
      if (result.applied) callHook(HOOKS.AUTOMATION_APPLIED, result);
      return result;
    } finally {
      this.#activeActors.delete(key);
    }
  }

  async #persistState(actor, state, diagnostic, matchedRuleIds, operationId) {
    const mutation = await this.#repository.mutate(actor, (gallery) => ({
      ...gallery,
      automationState: {
        ...state,
        matchedRuleIds: Array.from(matchedRuleIds),
        lastEvaluation: diagnostic
      }
    }), { context: automationContext(operationId, diagnostic.winnerRuleId, "automation-state") });
    return mutation.gallery;
  }

  async #executeAction(actor, token, rule, operationId) {
    const context = automationContext(operationId, rule.id, "automation-action");
    const action = rule.action;
    if (action.type === AUTOMATION_ACTION_TYPES.APPLY_ENTRY) {
      return this.#applicator.apply(actor, action.entryId, action.target ?? APPLY_TARGETS.PORTRAIT_CURRENT, { token, applicationContext: context });
    }
    if (action.type === AUTOMATION_ACTION_TYPES.APPLY_PROFILE) {
      return this.#profileService.apply(actor, action.profileId, { applicationContext: context });
    }
    if (action.type === AUTOMATION_ACTION_TYPES.APPLY_TEMPORARY) {
      return this.#temporaryService.apply(actor, action.entryId, action.target ?? APPLY_TARGETS.PORTRAIT_CURRENT, { token, applicationContext: context });
    }
    if (action.type === AUTOMATION_ACTION_TYPES.REVERT_TEMPORARY) {
      return this.#temporaryService.revert(actor, { applicationContext: context });
    }
    const sequenceAction = {
      [AUTOMATION_ACTION_TYPES.SEQUENCE_NEXT]: "next",
      [AUTOMATION_ACTION_TYPES.SEQUENCE_PREVIOUS]: "previous",
      [AUTOMATION_ACTION_TYPES.SEQUENCE_RESET]: "reset",
      [AUTOMATION_ACTION_TYPES.SEQUENCE_STEP]: "step"
    }[action.type];
    if (sequenceAction) {
      return this.#sequenceService.navigate(actor, action.sequenceId, sequenceAction, {
        token,
        target: action.target ?? APPLY_TARGETS.PORTRAIT_CURRENT,
        stepIndex: action.stepIndex ?? null,
        applicationContext: context
      });
    }
    throw new AutomationRuleError("automationActionInvalid");
  }

  #assertAccess() {
    assertCapability(this.#entitlements, CAPABILITIES.AUTOMATION_RULES);
  }
}

export class AutomationExecutionError extends Error {
  constructor(code, options = {}) {
    super(code, options);
    this.name = "AutomationExecutionError";
    this.code = code;
  }
}

export function triggerMatches(ruleTrigger, triggerType, eventName = "") {
  if (ruleTrigger.type !== triggerType) return false;
  return triggerType !== AUTOMATION_TRIGGER_TYPES.MANUAL || !ruleTrigger.event || ruleTrigger.event === eventName;
}

export function isModuleAutomationUpdate(options) {
  const context = options?.[MODULE_ID];
  return context?.origin === "automation" || String(context?.source ?? "").startsWith("automation");
}

function expireManualOverride(manualOverride, trigger, { scene, combat }) {
  if (!manualOverride) return null;
  if (manualOverride.duration === MANUAL_OVERRIDE_DURATIONS.SCENE_CHANGE
    && trigger?.type === AUTOMATION_TRIGGER_TYPES.SCENE_ACTIVATED
    && String(scene?.id ?? "") !== String(manualOverride.sceneId ?? "")) return null;
  if (manualOverride.duration === MANUAL_OVERRIDE_DURATIONS.COMBAT_END
    && trigger?.type === AUTOMATION_TRIGGER_TYPES.COMBAT_END
    && (!manualOverride.combatId || String(combat?.id ?? "") === String(manualOverride.combatId))) return null;
  return manualOverride;
}

function validateActionReferences(gallery, action) {
  const exists = (collection, id) => collection.some((item) => item.id === id);
  if ([AUTOMATION_ACTION_TYPES.APPLY_ENTRY, AUTOMATION_ACTION_TYPES.APPLY_TEMPORARY].includes(action.type)
    && !exists(gallery.entries, action.entryId)) throw new AutomationRuleError("automationActionReferenceMissing");
  if (action.type === AUTOMATION_ACTION_TYPES.APPLY_PROFILE
    && !exists(gallery.profiles, action.profileId)) throw new AutomationRuleError("automationActionReferenceMissing");
  if ([AUTOMATION_ACTION_TYPES.SEQUENCE_NEXT, AUTOMATION_ACTION_TYPES.SEQUENCE_PREVIOUS, AUTOMATION_ACTION_TYPES.SEQUENCE_RESET, AUTOMATION_ACTION_TYPES.SEQUENCE_STEP].includes(action.type)) {
    const sequence = gallery.sequences.find((candidate) => candidate.id === action.sequenceId);
    if (!sequence) throw new AutomationRuleError("automationActionReferenceMissing");
    if (action.type === AUTOMATION_ACTION_TYPES.SEQUENCE_STEP && !sequence.steps[action.stepIndex]) {
      throw new AutomationRuleError("sequenceStepInvalid");
    }
  }
  if (action.type === AUTOMATION_ACTION_TYPES.REVERT_TEMPORARY && !gallery.temporaryState) {
    throw new AutomationRuleError("temporaryNotActive");
  }
}

function compareRules(left, right) {
  return right.rule.priority - left.rule.priority || left.rule.id.localeCompare(right.rule.id);
}

function suppression(rule, reason) {
  return { ruleId: String(rule?.id ?? ""), name: String(rule?.name ?? ""), reason };
}

function collectFactKeys(node, result = []) {
  if (Array.isArray(node?.children)) {
    for (const child of node.children) collectFactKeys(child, result);
  } else if (node?.fact) result.push(node.fact);
  return result;
}

function automationContext(operationId, ruleId, source) {
  return { origin: "automation", operationId, ruleId, source };
}

function actorKey(actor) {
  return String(actor?.uuid ?? actor?.id ?? "unknown");
}

function callHook(name, ...args) {
  try {
    globalThis.Hooks?.callAll?.(name, ...args);
  } catch (error) {
    warn(`Integration hook ${name} failed.`, error);
  }
}

import { APPLY_TARGETS, EXTENSION_CAPABILITIES, FEATURE_REGISTRY, HOOKS, MODULE_ID } from "./constants.mjs";
import { createExtensionHost } from "./extension-host.mjs";
import { ExtensionRegistry } from "./extensions.mjs";
import { registerIntegrations } from "./integration.mjs";
import { createPublicApi } from "./public-api.mjs";
import { registerKeybindings, registerSettings } from "./settings.mjs";
import { TemporaryAppearanceService } from "./temporary-appearance-service.mjs";
import { BackupService } from "./backup-service.mjs";
import { ActorGalleryRepository } from "./foundry/gallery-repository.mjs";
import { GlobalGalleryRepository } from "./foundry/global-gallery-repository.mjs";
import { ActorImageApplicator, DerivedImageRenderer, ThumbnailService } from "./foundry/image-application.mjs";
import { GalleryPreloader } from "./foundry/preloader.mjs";
import { GlobalGalleryService } from "./global-gallery-service.mjs";
import { ActorGalleryApplication } from "./ui/gallery-app.mjs";
import { GlobalGalleryApplication } from "./ui/global-gallery-app.mjs";
import { QuickSwitch, resolveQuickTarget } from "./ui/quick-switch.mjs";
import { getActiveTokenForActor, notify, warn } from "./utils.mjs";
import { applyPalette, DEFAULT_PALETTE } from "./palette.mjs";

let runtime = null;
const extensions = new ExtensionRegistry();

Hooks.once("init", () => {
  registerSettings({
    globalGalleryChanged: () => void runtime?.refreshGlobalGallery()
  });
  registerKeybindings({
    quickSlot: (slot) => {
      if (!runtime) return false;
      void runtime.applyQuickSlot(slot);
      return true;
    },
    previous: () => {
      if (!runtime) return false;
      void runtime.applyPrevious();
      return true;
    },
    open: () => {
      if (!runtime) return false;
      void runtime.openSelected();
      return true;
    }
  });
  globalThis.Hooks?.callAll?.(HOOKS.REGISTER_EXTENSIONS, extensions.registrar({ coreVersion: coreModuleVersion() }));
});

Hooks.once("ready", () => {
  applyPalette(globalThis.document?.documentElement, getSetting("customPalette", DEFAULT_PALETTE));
  const repository = new ActorGalleryRepository();
  const globalRepository = new GlobalGalleryRepository();
  const preloader = new GalleryPreloader();
  const thumbnails = new ThumbnailService();
  const renderer = new DerivedImageRenderer();
  const applicator = new ActorImageApplicator({ repository, renderer });
  const temporaryService = new TemporaryAppearanceService({ repository, applicator });
  const backupService = new BackupService({ actorRepository: repository, globalRepository });
  const globalService = new GlobalGalleryService({ globalRepository, actorRepository: repository });
  const quickSwitch = new QuickSwitch({ repository, applicator, preloader, extensions, openGallery: (actor, options) => runtime.openGallery(actor, options) });
  runtime = new ActorImageGalleryRuntime({ repository, globalRepository, globalService, temporaryService, backupService, applicator, preloader, thumbnails, quickSwitch, extensions });
  activateExtensions({ repository, applicator, temporaryService, renderer });
  registerIntegrations(() => runtime);
  exposeApi(runtime);
  globalThis.Hooks?.callAll?.(HOOKS.EXTENSIONS_READY, extensions.list());
  void runtime.preloadScene();
});

Hooks.on("hotReload", () => runtime?.destroy());

export class ActorImageGalleryRuntime {
  #repository;
  #globalRepository;
  #globalService;
  #temporaryService;
  #backupService;
  #applicator;
  #preloader;
  #thumbnails;
  #quickSwitch;
  #extensions;
  #applications = new Map();
  #globalApplication = null;

  constructor({ repository, globalRepository, globalService, temporaryService, backupService, applicator, preloader, thumbnails, quickSwitch, extensions = null }) {
    this.#repository = repository;
    this.#globalRepository = globalRepository;
    this.#globalService = globalService;
    this.#temporaryService = temporaryService;
    this.#backupService = backupService;
    this.#applicator = applicator;
    this.#preloader = preloader;
    this.#thumbnails = thumbnails;
    this.#quickSwitch = quickSwitch;
    this.#extensions = extensions;
  }

  // newEntry: open straight into the "new appearance" editor (used by the empty Quick Switch).
  async openGallery(actorInput, { token = null, newEntry = false } = {}) {
    const { actor, resolvedToken } = resolveActorInput(actorInput, token);
    if (!actor) {
      notify("warn", "errors.actorRequired");
      return null;
    }
    const key = actor.uuid ?? actor.id;
    let application = this.#applications.get(key);
    if (!application) {
      application = new ActorGalleryApplication({
        actor,
        token: resolvedToken,
        repository: this.#repository,
        applicator: this.#applicator,
        preloader: this.#preloader,
        thumbnails: this.#thumbnails,
        temporaryService: this.#temporaryService,
        backupService: this.#backupService,
        extensions: this.#extensions,
        openGlobalGallery: () => this.openGlobalGallery({ actor })
      });
      application.addEventListener("close", () => this.#applications.delete(key));
      this.#applications.set(key, application);
    }
    if (application.rendered) application.bringToFront();
    else await application.render({ force: true });
    if (newEntry) application.startNewEntry();
    return application;
  }

  async openGlobalGallery(options = {}) {
    const actorInput = options?.actor ?? (options?.documentName === "Actor" ? options : null);
    const { actor } = resolveActorInput(actorInput);
    if (!this.#globalApplication) {
      this.#globalApplication = new GlobalGalleryApplication({
        repository: this.#globalRepository,
        service: this.#globalService,
        backupService: this.#backupService,
        thumbnails: this.#thumbnails,
        actor
      });
      this.#globalApplication.addEventListener("close", () => { this.#globalApplication = null; });
    } else if (actor) this.#globalApplication.setTargetActor(actor);
    if (this.#globalApplication.rendered) this.#globalApplication.bringToFront();
    else await this.#globalApplication.render({ force: true });
    return this.#globalApplication;
  }

  async openQuickSwitch(actorOrToken, options = {}) {
    const { actor, resolvedToken } = resolveActorInput(actorOrToken, options.token ?? null);
    if (!actor) {
      notify("warn", "errors.actorRequired");
      return null;
    }
    return this.#quickSwitch.open(resolvedToken ?? actor, { ...options, token: options.token ?? resolvedToken });
  }

  closeQuickSwitch() {
    this.#quickSwitch.close();
  }

  quickSwitchMode() {
    return this.#quickSwitch.mode;
  }

  async openSelected() {
    const token = selectedToken();
    if (token) return this.openGallery(token.actor, { token });
    const actor = globalThis.game?.user?.character;
    if (actor) return this.openGallery(actor);
    notify("warn", "errors.selectToken");
    return null;
  }

  async applyQuickSlot(slot) {
    const token = selectedToken();
    const actor = token?.actor ?? globalThis.game?.user?.character;
    if (!actor) {
      notify("warn", "errors.selectToken");
      return false;
    }
    const gallery = this.#repository.read(actor);
    const entry = gallery.entries.find((candidate) => candidate.quickSlot === slot);
    if (!entry) {
      notify("warn", "errors.slotEmpty", { slot });
      return false;
    }
    try {
      const target = quickTarget(token, gallery);
      if (!target) throw Object.assign(new Error("featureDisabled"), { code: "featureDisabled" });
      const result = await this.#applicator.apply(actor, entry, target, { token });
      notify("info", result.temporaryCleared ? "notifications.temporaryCommitted" : "notifications.applied");
      return true;
    } catch (error) {
      handleRuntimeError(error);
      return false;
    }
  }

  async applyPrevious() {
    const token = selectedToken();
    const actor = token?.actor ?? globalThis.game?.user?.character;
    if (!actor) {
      notify("warn", "errors.selectToken");
      return false;
    }
    const gallery = this.#repository.read(actor);
    const currentSource = getSetting("enableTokenFeatures", true) && token && !gallery.ignoreTokenChanges
      ? token.document?.texture?.src
      : actor.img;
    const byId = new Map(gallery.entries.map((entry) => [entry.id, entry]));
    const history = gallery.history.map((id) => byId.get(id)).filter(Boolean);
    const entry = history.find((candidate) => ![candidate.source, candidate.derived?.token?.source, candidate.derived?.portrait?.source].includes(currentSource));
    if (!entry) {
      notify("warn", "errors.noPrevious");
      return false;
    }
    try {
      const target = quickTarget(token, gallery);
      if (!target) throw Object.assign(new Error("featureDisabled"), { code: "featureDisabled" });
      const result = await this.#applicator.apply(actor, entry, target, { token });
      notify("info", result.temporaryCleared ? "notifications.temporaryCommitted" : "notifications.applied");
      return true;
    } catch (error) {
      handleRuntimeError(error);
      return false;
    }
  }

  async preloadActor(actor) {
    if (!getSetting("preloadFavorites", true) || !actor) return;
    return this.#preloader.preload(this.#repository.read(actor).entries, { favoritesOnly: true });
  }

  async preloadScene() {
    if (!getSetting("preloadFavorites", true)) return;
    const actors = new Map();
    for (const token of globalThis.canvas?.tokens?.placeables ?? []) {
      if (token.actor) actors.set(token.actor.uuid ?? token.actor.id, token.actor);
    }
    await Promise.allSettled(Array.from(actors.values()).map((actor) => this.preloadActor(actor)));
  }

  async refreshActor(actor) {
    if (!actor) return;
    const app = this.#applications.get(actor.uuid ?? actor.id);
    if (app?.rendered) await app.refresh();
  }

  async apply(actor, entryId, target, options = {}) {
    const { actor: resolvedActor, resolvedToken } = resolveActorInput(actor, options.token ?? null);
    if (!resolvedActor) throw Object.assign(new Error("actorRequired"), { code: "actorRequired" });
    return this.#applicator.apply(resolvedActor, entryId, target, { ...options, token: options.token ?? resolvedToken });
  }

  async applyTemporary(actorInput, entryId, options = {}) {
    const { actor, resolvedToken } = resolveActorInput(actorInput, options.token ?? null);
    if (!actor) throw Object.assign(new Error("actorRequired"), { code: "actorRequired" });
    const target = options.target ?? quickTarget(resolvedToken, this.#repository.read(actor));
    if (!target) throw Object.assign(new Error("featureDisabled"), { code: "featureDisabled" });
    const result = await this.#temporaryService.apply(actor, entryId, target, { token: options.token ?? resolvedToken });
    await this.refreshActor(actor);
    return result;
  }

  async revertTemporary(actorInput) {
    const { actor } = resolveActorInput(actorInput);
    if (!actor) throw Object.assign(new Error("actorRequired"), { code: "actorRequired" });
    const result = await this.#temporaryService.revert(actor);
    await this.refreshActor(actor);
    return result;
  }


  exportActorMetadata(actorInput) {
    const { actor } = resolveActorInput(actorInput);
    if (!actor) throw Object.assign(new Error("actorRequired"), { code: "actorRequired" });
    return this.#backupService.exportActor(actor);
  }

  exportGlobalMetadata() {
    return this.#backupService.exportGlobal();
  }

  exportWorldMetadata() {
    return this.#backupService.exportWorld();
  }

  async importActorMetadata(actorInput, envelope, options = {}) {
    const { actor } = resolveActorInput(actorInput);
    if (!actor) throw Object.assign(new Error("actorRequired"), { code: "actorRequired" });
    const result = await this.#backupService.importActor(actor, envelope, options);
    await this.refreshActor(actor);
    return result;
  }

  async importGlobalMetadata(envelope, options = {}) {
    const result = await this.#backupService.importGlobal(envelope, options);
    await this.refreshGlobalGallery();
    return result;
  }

  async importWorldMetadata(envelope, options = {}) {
    const result = await this.#backupService.importWorld(envelope, options);
    await this.refreshGlobalGallery();
    await Promise.allSettled(Array.from(this.#applications.values()).map((application) => application.refresh()));
    return result;
  }

  getGallery(actorInput) {
    const { actor } = resolveActorInput(actorInput);
    if (!actor) throw Object.assign(new Error("actorRequired"), { code: "actorRequired" });
    return this.#repository.read(actor);
  }

  getGlobalGallery() {
    return this.#globalService.getGallery();
  }

  async refreshGlobalGallery() {
    if (this.#globalApplication?.rendered) await this.#globalApplication.refresh();
  }

  async addGlobalEntryToActor(entryIds, actorInput) {
    const { actor } = resolveActorInput(actorInput);
    if (!actor) throw Object.assign(new Error("actorRequired"), { code: "actorRequired" });
    const result = await this.#globalService.addToActor(actor, entryIds);
    await this.refreshActor(actor);
    return result;
  }

  hasCapability(capability) {
    if (FEATURE_REGISTRY[capability]?.tier === "free") return true;
    return Boolean(this.#extensions?.has(capability));
  }

  getCapabilities() {
    const capabilities = [...Object.keys(FEATURE_REGISTRY), ...EXTENSION_CAPABILITIES];
    return Object.freeze(Object.fromEntries(capabilities.map((capability) => [capability, this.hasCapability(capability)])));
  }

  getEntitlementStatus() {
    const active = (this.#extensions?.list() ?? []).filter((extension) => extension.state === "active").map((extension) => extension.id);
    if (active.length) return Object.freeze({ tier: "patreon", state: "active", source: "companion-module", extensions: Object.freeze(active), checkedAt: Date.now(), error: null });
    return Object.freeze({ tier: "free", state: "inactive", source: "free-distribution", checkedAt: Date.now(), error: null });
  }

  async refreshEntitlements() {
    return this.getEntitlementStatus();
  }

  registerExtension(descriptor) {
    if (!this.#extensions) throw Object.assign(new Error("extensionsUnavailable"), { code: "extensionsUnavailable" });
    return this.#extensions.register(descriptor);
  }

  getExtensions() {
    return this.#extensions?.list() ?? [];
  }

  extensionRuntime() {
    return {
      openGallery: (actorOrUuid, options = {}) => this.openGallery(actorOrUuid, options),
      openQuickSwitch: (actorOrToken, options = {}) => this.openQuickSwitch(actorOrToken, options),
      closeQuickSwitch: () => this.closeQuickSwitch(),
      quickSwitchMode: () => this.quickSwitchMode(),
      refreshActor: (actor) => this.refreshActor(actor),
      resolveActor: (input, token = null) => {
        const { actor, resolvedToken } = resolveActorInput(input, token);
        return { actor: actor ?? null, token: resolvedToken ?? null };
      }
    };
  }

  async destroy() {
    this.#quickSwitch.close();
    const applications = Array.from(this.#applications.values());
    this.#applications.clear();
    if (this.#globalApplication) applications.push(this.#globalApplication);
    this.#globalApplication = null;
    await Promise.allSettled(applications.map((application) => application.close({ animate: false })));
  }
}

function exposeApi(instance) {
  const module = globalThis.game?.modules?.get?.(MODULE_ID);
  if (!module) return;
  module.api = createPublicApi(instance);
}

function activateExtensions({ repository, applicator, temporaryService, renderer }) {
  const host = createExtensionHost({
    coreVersion: coreModuleVersion(),
    repository,
    applicator,
    temporaryService,
    renderer,
    runtime: runtime.extensionRuntime(),
    hasCapability: (capability) => Boolean(runtime?.hasCapability(capability))
  });
  const results = extensions.activateAll(host);
  if (!globalThis.game?.user?.isGM) return;
  for (const result of results) {
    if (result.state !== "failed") continue;
    const title = globalThis.game?.modules?.get?.(result.id)?.title ?? result.id;
    notify("error", "errors.extensionFailed", { name: title });
  }
}

function coreModuleVersion() {
  return globalThis.game?.modules?.get?.(MODULE_ID)?.version ?? null;
}

function resolveActorInput(value, token = null) {
  if (value?.documentName === "Actor") return { actor: value, resolvedToken: token };
  if (value?.actor) return { actor: value.actor, resolvedToken: value.object ?? value };
  if (typeof value === "string") {
    const actor = globalThis.game?.actors?.get?.(value)
      ?? globalThis.game?.actors?.get?.(value.split(".").at(-1));
    return { actor, resolvedToken: token ?? getActiveTokenForActor(actor) };
  }
  return { actor: null, resolvedToken: token };
}


function selectedToken() {
  return globalThis.canvas?.tokens?.controlled?.[0] ?? null;
}

function getSetting(key, fallback) {
  try {
    return globalThis.game?.settings?.get?.(MODULE_ID, key) ?? fallback;
  } catch {
    return fallback;
  }
}

function quickTarget(token, gallery = null) {
  return resolveQuickTarget({
    origin: token ? "token" : "sheet",
    hasToken: Boolean(token),
    configuredTarget: getSetting("quickApplyTarget", APPLY_TARGETS.PORTRAIT_CURRENT),
    portraitEnabled: getSetting("enablePortraitFeatures", true),
    tokenEnabled: getSetting("enableTokenFeatures", true),
    ignoreTokenChanges: Boolean(gallery?.ignoreTokenChanges)
  });
}

function handleRuntimeError(error) {
  warn("Runtime action failed.", error);
  const key = error?.code === "tokenRequired"
    ? "errors.tokenRequired"
    : error?.code === "featureDisabled" ? "errors.featureDisabled"
      : error?.code === "tokenDisabledForGallery" ? "errors.tokenDisabledForGallery"
        : "errors.actionFailed";
  notify("error", key);
}

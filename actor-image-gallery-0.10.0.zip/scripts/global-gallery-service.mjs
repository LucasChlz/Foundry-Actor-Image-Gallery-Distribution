import { addEntry, smartTokenPreset } from "./domain/gallery.mjs";
import { loadImageSize } from "./foundry/image-application.mjs";

export class GlobalGalleryService {
  #globalRepository;
  #actorRepository;
  #imageSize;

  // imageSize(source) -> { width, height } | null frames tall art for the Token (injectable for tests).
  constructor({ globalRepository, actorRepository, imageSize = loadImageSize }) {
    this.#globalRepository = globalRepository;
    this.#actorRepository = actorRepository;
    this.#imageSize = imageSize;
  }

  getGallery() {
    return this.#globalRepository.read();
  }

  async addToActor(actor, entryIds) {
    if (!actor) throw new GlobalGalleryServiceError("actorRequired");
    const requestedIds = Array.from(new Set((Array.isArray(entryIds) ? entryIds : [entryIds]).map(String).filter(Boolean)));
    if (!requestedIds.length) throw new GlobalGalleryServiceError("globalSelectionRequired");
    const globalGallery = this.#globalRepository.read();
    const entriesById = new Map(globalGallery.entries.map((entry) => [entry.id, entry]));
    const selected = requestedIds.map((id) => entriesById.get(id));
    if (selected.some((entry) => !entry)) throw new GlobalGalleryServiceError("globalEntryNotFound");
    const sizes = await Promise.all(selected.map((entry) => Promise.resolve(this.#imageSize?.(entry.source)).catch(() => null)));

    const mutation = await this.#actorRepository.mutate(actor, (current) => {
      let gallery = current;
      const added = [];
      for (const [index, globalEntry] of selected.entries()) {
        const token = sizes[index] ? smartTokenPreset(sizes[index]) : null;
        const result = addEntry(gallery, {
          ...(token ? { token } : {}),
          globalEntryId: globalEntry.id,
          source: globalEntry.source,
          name: globalEntry.name,
          tags: globalEntry.tags,
          description: globalEntry.description,
          collection: globalEntry.category,
          favorite: globalEntry.favorite
        });
        gallery = result.gallery;
        added.push(result.entry);
      }
      return { gallery, value: added };
    });
    return { gallery: mutation.gallery, entries: mutation.value };
  }
}

export class GlobalGalleryServiceError extends Error {
  constructor(code) {
    super(code);
    this.name = "GlobalGalleryServiceError";
    this.code = code;
  }
}

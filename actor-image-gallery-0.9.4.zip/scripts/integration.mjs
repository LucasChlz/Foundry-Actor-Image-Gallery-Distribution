import { AUTOMATION_TRIGGER_TYPES, MODULE_ID } from "./constants.mjs";
import { actorCanUpdate, localize } from "./utils.mjs";

export function registerIntegrations(runtime) {
  Hooks.on("getActorSheetHeaderButtons", (application, buttons) => {
    const actor = resolveActor(application);
    if (!actor) return;
    if (!buttons.some((button) => button.class === `${MODULE_ID}-open`)) {
      buttons.unshift({
        label: localize("actions.gallery"),
        class: `${MODULE_ID}-open`,
        icon: "fas fa-images",
        onclick: () => runtime().openGallery(actor, { token: application.token?.object ?? null })
      });
    }
    if (getSetting("enablePortraitFeatures", true) && !buttons.some((button) => button.class === `${MODULE_ID}-quick`)) {
      buttons.unshift({
        label: localize("quick.openPortrait"),
        class: `${MODULE_ID}-quick`,
        icon: "fas fa-bolt",
        onclick: (event) => runtime().openQuickSwitch(actor, {
          anchor: event?.currentTarget ?? null,
          origin: "sheet",
          token: application.token?.object ?? null
        })
      });
    }
  });

  Hooks.on("renderActorSheet", (application, element) => attachPortraitQuickSwitch(application, element, runtime));

  Hooks.on("renderApplicationV2", (application, element) => {
    const actor = resolveActor(application);
    const root = normalizeElement(element);
    if (!actor || !root || application?.constructor?.name === "ActorGalleryApplication" || root.matches?.(".aig-shell") || root.querySelector?.(".aig-shell")) return;
    if (!root.querySelector?.(".aig-sheet-launches")) {
      const launches = document.createElement("div");
      launches.className = "aig-sheet-launches";
      launches.append(createSheetLaunch({
        action: "gallery",
        icon: "fa-images",
        label: localize("actions.gallery"),
        onClick: () => runtime().openGallery(actor, { token: application.token?.object ?? null })
      }));
      if (getSetting("enablePortraitFeatures", true)) {
        launches.append(createSheetLaunch({
          action: "quick",
          icon: "fa-bolt",
          label: localize("quick.openPortrait"),
          onClick: (event) => runtime().openQuickSwitch(actor, {
            anchor: event.currentTarget,
            origin: "sheet",
            token: application.token?.object ?? null
          })
        }));
      }
      root.prepend(launches);
    }
    attachPortraitQuickSwitch(application, root, runtime);
  });

  Hooks.on("renderTokenHUD", (hud, element) => {
    if (!getSetting("enableTokenFeatures", true)) return;
    const root = normalizeElement(element);
    const token = hud.object ?? hud.token ?? globalThis.canvas?.tokens?.hud?.object;
    if (!root || !token?.actor || root.querySelector?.(".aig-token-hud-button")) return;
    const button = document.createElement("button");
    button.type = "button";
    button.className = "control-icon aig-token-hud-button";
    button.dataset.tooltip = localize("quick.open");
    button.setAttribute("aria-label", localize("quick.open"));
    button.innerHTML = '<i class="fa-solid fa-images" aria-hidden="true"></i>';
    button.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      void runtime().openQuickSwitch(token, { anchor: button });
    });
    const column = root.querySelector?.(".col.right") ?? root;
    column.append(button);
  });

  Hooks.on("getSceneControlButtons", (controls) => attachSceneControl(controls, runtime));

  Hooks.on("controlToken", (token, controlled) => {
    if (controlled && token.actor) void runtime().preloadActor(token.actor);
  });

  Hooks.on("canvasReady", (canvas) => {
    void runtime().preloadScene();
    const scene = canvas?.scene ?? globalThis.canvas?.scene;
    runtime().queueAutomationActors(sceneActors(scene), { trigger: { type: AUTOMATION_TRIGGER_TYPES.SCENE_ACTIVATED }, scene });
  });
  Hooks.on("updateActor", (actor, changes, options) => {
    void runtime().refreshActor(actor);
    if (isGalleryFlagOnly(changes)) return;
    const queue = () => runtime().queueAutomation(actor, { trigger: { type: AUTOMATION_TRIGGER_TYPES.ACTOR_UPDATE }, changes, options });
    if (!isModuleAuthored(options) && isActorAppearanceChange(changes) && runtime().isAutomationAuthority()) {
      void Promise.resolve(runtime().handleManualAppearance({ actor, source: "external-actor-update" }))
        .catch((error) => warnAutomationOverride(error))
        .finally(queue);
    } else queue();
  });
  Hooks.on("updateToken", (tokenDocument, changes, options) => {
    void runtime().refreshActor(tokenDocument.actor);
    const queue = () => runtime().queueAutomation(tokenDocument.actor, { trigger: { type: AUTOMATION_TRIGGER_TYPES.TOKEN_UPDATE }, token: tokenObject(tokenDocument), scene: tokenDocument.parent, changes, options });
    if (!isModuleAuthored(options) && isTokenAppearanceChange(changes) && runtime().isAutomationAuthority()) {
      void Promise.resolve(runtime().handleManualAppearance({ actor: tokenDocument.actor, source: "external-token-update" }))
        .catch((error) => warnAutomationOverride(error))
        .finally(queue);
    } else queue();
  });
  Hooks.on("createToken", (tokenDocument, options) => {
    runtime().queueAutomation(tokenDocument.actor, { trigger: { type: AUTOMATION_TRIGGER_TYPES.TOKEN_ENTER_SCENE }, token: tokenObject(tokenDocument), scene: tokenDocument.parent, options });
  });
  Hooks.on("createActiveEffect", (effect, options) => queueEffectAutomation(effect, null, options, runtime));
  Hooks.on("updateActiveEffect", (effect, changes, options) => queueEffectAutomation(effect, changes, options, runtime));
  Hooks.on("deleteActiveEffect", (effect, options) => queueEffectAutomation(effect, null, options, runtime));
  Hooks.on("updateCombat", (combat, changes, options) => {
    const type = combatTrigger(combat, changes);
    if (type) runtime().queueAutomationActors(combatActors(combat), { trigger: { type }, combat, changes, options });
  });
  Hooks.on("deleteCombat", (combat, options) => {
    runtime().queueAutomationActors(combatActors(combat), { trigger: { type: AUTOMATION_TRIGGER_TYPES.COMBAT_END }, combat, options });
  });

  Hooks.on("getActorDirectoryEntryContext", (_html, options) => {
    if (!Array.isArray(options)) return;
    options.push({
      name: localize("actions.gallery"),
      icon: '<i class="fa-solid fa-images"></i>',
      condition: (target) => Boolean(resolveDirectoryActor(target)),
      callback: (target) => {
        const actor = resolveDirectoryActor(target);
        if (actor) void runtime().openGallery(actor);
      }
    });
  });
}

function createSheetLaunch({ action, icon, label, onClick }) {
  const launch = document.createElement("button");
  launch.type = "button";
  launch.className = `aig-sheet-launch aig-sheet-launch--${action}`;
  launch.innerHTML = `<i class="fa-solid ${icon}" aria-hidden="true"></i><span>${label}</span>`;
  launch.addEventListener("click", onClick);
  return launch;
}

function attachPortraitQuickSwitch(application, element, runtime) {
  if (!getSetting("enablePortraitFeatures", true) || !getSetting("portraitClickQuickSwitch", true)) return;
  const actor = resolveActor(application);
  const root = normalizeElement(element);
  if (!actor || !root) return;
  const portrait = findActorPortrait(root, actor);
  if (!portrait || portrait.dataset.aigQuickSwitch === "true") return;
  portrait.dataset.aigQuickSwitch = "true";
  portrait.classList.add("aig-sheet-portrait-trigger");
  portrait.tabIndex = portrait.tabIndex >= 0 ? portrait.tabIndex : 0;
  portrait.setAttribute("aria-haspopup", "dialog");
  portrait.title = localize("quick.portraitClickHint");
  const host = portrait.parentElement;
  if (host && !host.querySelector(":scope > .aig-sheet-portrait-badge")) {
    host.classList.add("aig-sheet-portrait-host");
    const badge = document.createElement("span");
    badge.className = "aig-sheet-portrait-badge";
    badge.setAttribute("aria-hidden", "true");
    badge.innerHTML = '<i class="fa-solid fa-bolt"></i>';
    host.append(badge);
  }
  const open = (event) => {
    if (event.type === "click" && event.shiftKey) return;
    if (event.type === "keydown" && !["Enter", " "].includes(event.key)) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    void runtime().openQuickSwitch(actor, {
      anchor: portrait,
      origin: "sheet",
      token: application.token?.object ?? null
    });
  };
  portrait.addEventListener("click", open, true);
  portrait.addEventListener("keydown", open, true);
}

function findActorPortrait(root, actor) {
  const selectors = [
    'img[data-edit="img"]',
    'img[data-action="editImage"]',
    "img.profile-img",
    ".profile img",
    ".portrait img",
    "img.actor-image"
  ];
  const explicit = selectors.flatMap((selector) => Array.from(root.querySelectorAll?.(selector) ?? []));
  const candidates = explicit.length ? explicit : Array.from(root.querySelectorAll?.("img") ?? []);
  return candidates.find((image) => sameImageSource(image.getAttribute("src"), actor.img)) ?? explicit[0] ?? null;
}

function sameImageSource(left, right) {
  if (!left || !right) return false;
  try {
    return new URL(left, globalThis.location?.href).href === new URL(right, globalThis.location?.href).href;
  } catch {
    return String(left).replace(/^\.\//, "") === String(right).replace(/^\.\//, "");
  }
}

export function resolveActor(application) {
  const candidates = [
    application?.document,
    application?.object,
    application?.actor,
    application?.token?.actor,
    application?.object?.actor
  ];
  return candidates.find((candidate) => candidate?.documentName === "Actor" || candidate?.constructor?.metadata?.name === "Actor") ?? null;
}

function attachSceneControl(controls, runtime) {
  const callback = () => runtime().openSelected();
  if (Array.isArray(controls)) {
    const tokens = controls.find((control) => control.name === "token" || control.name === "tokens");
    if (!tokens?.tools || tokens.tools.some((tool) => tool.name === `${MODULE_ID}-open`)) return;
    tokens.tools.push({
      name: `${MODULE_ID}-open`,
      title: localize("actions.gallery"),
      icon: "fa-solid fa-images",
      button: true,
      visible: true,
      onClick: callback
    });
    return;
  }
  const tokens = controls?.tokens ?? controls?.token ?? Object.values(controls ?? {}).find((control) => control?.tools);
  if (!tokens?.tools) return;
  if (Array.isArray(tokens.tools)) return attachSceneControl([tokens], runtime);
  if (tokens.tools[`${MODULE_ID}-open`]) return;
  tokens.tools[`${MODULE_ID}-open`] = {
    name: `${MODULE_ID}-open`,
    title: localize("actions.gallery"),
    icon: "fa-solid fa-images",
    button: true,
    visible: true,
    order: Object.keys(tokens.tools).length + 100,
    onChange: callback
  };
}

function resolveDirectoryActor(target) {
  const element = normalizeElement(target);
  const id = element?.closest?.("[data-entry-id], [data-document-id]")?.dataset?.entryId
    ?? element?.closest?.("[data-entry-id], [data-document-id]")?.dataset?.documentId;
  return id ? globalThis.game?.actors?.get?.(id) : null;
}

function normalizeElement(value) {
  if (value instanceof globalThis.HTMLElement) return value;
  return value?.[0] instanceof globalThis.HTMLElement ? value[0] : null;
}

function getSetting(key, fallback) {
  try {
    return globalThis.game?.settings?.get?.(MODULE_ID, key) ?? fallback;
  } catch {
    return fallback;
  }
}

function tokenObject(document) {
  return document?.object
    ?? globalThis.canvas?.tokens?.get?.(document?.id)
    ?? (document ? { document, actor: document.actor } : null);
}

function sceneActors(scene) {
  return Array.from(scene?.tokens ?? []).map((token) => token.actor).filter(Boolean);
}

function combatActors(combat) {
  return Array.from(combat?.combatants ?? []).map((combatant) => combatant.actor ?? combatant.token?.actor).filter(Boolean);
}

function combatTrigger(combat, changes = {}) {
  if (Object.hasOwn(changes ?? {}, "started")) {
    return changes.started ? AUTOMATION_TRIGGER_TYPES.COMBAT_START : AUTOMATION_TRIGGER_TYPES.COMBAT_END;
  }
  if (Object.hasOwn(changes ?? {}, "round") || Object.hasOwn(changes ?? {}, "turn")) {
    const previousRound = Number(combat?.previous?.round ?? 0);
    if (combat?.started && previousRound <= 0 && Number(combat?.round ?? 0) > 0) return AUTOMATION_TRIGGER_TYPES.COMBAT_START;
    return AUTOMATION_TRIGGER_TYPES.COMBAT_TURN;
  }
  return null;
}

function queueEffectAutomation(effect, changes, options, runtime) {
  const actor = effect?.parent?.documentName === "Actor" ? effect.parent : effect?.parent?.actor;
  runtime().queueAutomation(actor, { trigger: { type: AUTOMATION_TRIGGER_TYPES.ACTIVE_EFFECT_CHANGE }, changes, options });
}

function isGalleryFlagOnly(changes) {
  const keys = Object.keys(changes ?? {});
  if (!keys.length) return false;
  return keys.every((key) => key === `flags.${MODULE_ID}`
    || key === `flags.${MODULE_ID}.gallery`
    || (key === "flags" && changes.flags && Object.keys(changes.flags).every((scope) => scope === MODULE_ID)));
}

function isModuleAuthored(options) {
  return Boolean(options?.[MODULE_ID]);
}

function isActorAppearanceChange(changes) {
  return Object.hasOwn(changes ?? {}, "img")
    || Object.hasOwn(changes ?? {}, "prototypeToken.texture.src")
    || Boolean(changes?.prototypeToken?.texture && Object.hasOwn(changes.prototypeToken.texture, "src"));
}

function isTokenAppearanceChange(changes) {
  return Object.hasOwn(changes ?? {}, "texture.src")
    || Boolean(changes?.texture && Object.hasOwn(changes.texture, "src"));
}

function warnAutomationOverride(error) {
  globalThis.console?.warn?.(`[${MODULE_ID}] Could not record an external manual appearance override.`, error);
}

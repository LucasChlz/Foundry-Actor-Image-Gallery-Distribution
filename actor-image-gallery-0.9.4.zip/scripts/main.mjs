import { APPLY_TARGETS, CAPABILITIES, HOOKS, MODULE_ID } from "./constants.mjs";
import { createFoundryEntitlementService } from "./entitlements.mjs";
import { registerIntegrations } from "./integration.mjs";
import { createPublicApi } from "./public-api.mjs";
import { registerKeybindings, registerSettings } from "./settings.mjs";
import { TemporaryAppearanceService } from "./temporary-appearance-service.mjs";
import { BackupService } from "./backup-service.mjs";
import { AppearanceProfileService } from "./appearance-profile-service.mjs";
import { AppearanceSequenceService } from "./appearance-sequence-service.mjs";
import { AutomationRuleService } from "./automation-service.mjs";
import { AutomationCoordinator } from "./automation-coordinator.mjs";
import { FactProviderRegistry, registerCoreFacts } from "./automation/fact-registry.mjs";
import { createDefaultSystemAdapterRegistry } from "./automation/system-adapters.mjs";
import { ActorGalleryRepository } from "./foundry/gallery-repository.mjs";
import { GlobalGalleryRepository } from "./foundry/global-gallery-repository.mjs";
import { ActorImageApplicator, ThumbnailService } from "./foundry/image-application.mjs";
import { GalleryPreloader } from "./foundry/preloader.mjs";
import { GlobalGalleryService } from "./global-gallery-service.mjs";
import { ActorGalleryApplication } from "./ui/gallery-app.mjs";
import { GlobalGalleryApplication } from "./ui/global-gallery-app.mjs";
import { AutomationRulesApplication } from "./ui/automation-app.mjs";
import { QuickSwitch, resolveQuickTarget } from "./ui/quick-switch.mjs";
import { confirmAction, escapeHtml, getActiveTokenForActor, localize, notify, warn } from "./utils.mjs";
import { applyPalette, DEFAULT_PALETTE } from "./palette.mjs";

let runtime = null;

Hooks.once("init", () => {
  registerSettings({
    globalGalleryChanged: () => void runtime?.refreshGlobalGallery()
  });
  registerKeybindings({
    quickSlot: (slot) => {
      if (!runtime) return false;
      void runtime.applyQuickSlot(slot);
      return true;
    },
    previous: () => {
      if (!runtime) return false;
      void runtime.applyPrevious();
      return true;
    },
    open: () => {
      if (!runtime) return false;
      void runtime.openSelected();
      return true;
    },
    wheel: () => {
      if (!runtime) return false;
      void runtime.openSelectWheel();
      return true;
    },
    sequenceNext: () => {
      if (!runtime) return false;
      void runtime.navigateActiveSequence("next");
      return true;
    },
    sequencePrevious: () => {
      if (!runtime) return false;
      void runtime.navigateActiveSequence("previous");
      return true;
    },
    sequenceReset: () => {
      if (!runtime) return false;
      void runtime.navigateActiveSequence("reset");
      return true;
    }
  });
});

Hooks.once("ready", () => {
  applyPalette(globalThis.document?.documentElement, getSetting("customPalette", DEFAULT_PALETTE));
  const repository = new ActorGalleryRepository();
  const globalRepository = new GlobalGalleryRepository();
  const preloader = new GalleryPreloader();
  const thumbnails = new ThumbnailService();
  const applicator = new ActorImageApplicator({ repository });
  const entitlements = createFoundryEntitlementService();
  const profileService = new AppearanceProfileService({ repository, entitlements });
  const sequenceService = new AppearanceSequenceService({ repository, applicator, profileService, entitlements });
  const temporaryService = new TemporaryAppearanceService({ repository, applicator });
  const factRegistry = registerCoreFacts(new FactProviderRegistry());
  const adapterRegistry = createDefaultSystemAdapterRegistry();
  adapterRegistry.activate(globalThis.game?.system?.id, factRegistry);
  const automationService = new AutomationRuleService({
    repository,
    applicator,
    profileService,
    sequenceService,
    temporaryService,
    entitlements,
    factRegistry,
    manualOverrideDuration: () => getSetting("automationManualOverrideDuration", "until-cleared"),
    confirmOverride: ({ rule }) => confirmAction({
      title: localize("automation.overrideAskTitle"),
      content: `<p>${escapeHtml(localize("automation.overrideAskContent", { name: rule.name }))}</p>`
    })
  });
  const automationCoordinator = new AutomationCoordinator({
    service: automationService,
    hasCapability: (capability) => entitlements.has(capability),
    debugEnabled: () => getSetting("automationDebug", false)
  });
  const backupService = new BackupService({ actorRepository: repository, globalRepository });
  const globalService = new GlobalGalleryService({ globalRepository, actorRepository: repository });
  const quickSwitch = new QuickSwitch({ repository, applicator, preloader, sequenceService, hasCapability: (capability) => entitlements.has(capability) });
  runtime = new ActorImageGalleryRuntime({ repository, globalRepository, globalService, temporaryService, backupService, profileService, sequenceService, automationService, automationCoordinator, factRegistry, adapterRegistry, applicator, preloader, thumbnails, quickSwitch, entitlements });
  registerIntegrations(() => runtime);
  Hooks.on(HOOKS.APPEARANCE_CHANGED, (payload) => void runtime?.handleManualAppearance(payload));
  Hooks.on(HOOKS.TEMPORARY_REVERTED, (payload) => void runtime?.handleManualAppearance(payload));
  exposeApi(runtime);
  void runtime.refreshEntitlements();
  void runtime.preloadScene();
});

Hooks.on("hotReload", () => runtime?.destroy());

export class ActorImageGalleryRuntime {
  #repository;
  #globalRepository;
  #globalService;
  #temporaryService;
  #backupService;
  #profileService;
  #sequenceService;
  #automationService;
  #automationCoordinator;
  #factRegistry;
  #adapterRegistry;
  #applicator;
  #preloader;
  #thumbnails;
  #quickSwitch;
  #entitlements;
  #applications = new Map();
  #automationApplications = new Map();
  #globalApplication = null;

  constructor({ repository, globalRepository, globalService, temporaryService, backupService, profileService, sequenceService, automationService, automationCoordinator, factRegistry, adapterRegistry, applicator, preloader, thumbnails, quickSwitch, entitlements }) {
    this.#repository = repository;
    this.#globalRepository = globalRepository;
    this.#globalService = globalService;
    this.#temporaryService = temporaryService;
    this.#backupService = backupService;
    this.#profileService = profileService;
    this.#sequenceService = sequenceService;
    this.#automationService = automationService;
    this.#automationCoordinator = automationCoordinator;
    this.#factRegistry = factRegistry;
    this.#adapterRegistry = adapterRegistry;
    this.#applicator = applicator;
    this.#preloader = preloader;
    this.#thumbnails = thumbnails;
    this.#quickSwitch = quickSwitch;
    this.#entitlements = entitlements;
  }

  async openGallery(actorInput, { token = null } = {}) {
    const { actor, resolvedToken } = resolveActorInput(actorInput, token);
    if (!actor) {
      notify("warn", "errors.actorRequired");
      return null;
    }
    const key = actor.uuid ?? actor.id;
    let application = this.#applications.get(key);
    if (!application) {
      application = new ActorGalleryApplication({
        actor,
        token: resolvedToken,
        repository: this.#repository,
        applicator: this.#applicator,
        preloader: this.#preloader,
        thumbnails: this.#thumbnails,
        temporaryService: this.#temporaryService,
        backupService: this.#backupService,
        profileService: this.#profileService,
        sequenceService: this.#sequenceService,
        hasCapability: (capability) => this.hasCapability(capability),
        openGlobalGallery: () => this.openGlobalGallery({ actor }),
        openAutomationManager: () => this.openAutomationManager(actor)
      });
      application.addEventListener("close", () => this.#applications.delete(key));
      this.#applications.set(key, application);
    }
    if (application.rendered) application.bringToFront();
    else await application.render({ force: true });
    return application;
  }

  async openAutomationManager(actorInput) {
    const { actor } = resolveActorInput(actorInput);
    if (!actor) {
      notify("warn", "errors.actorRequired");
      return null;
    }
    const key = actor.uuid ?? actor.id;
    let application = this.#automationApplications.get(key);
    if (!application) {
      application = new AutomationRulesApplication({
        actor,
        repository: this.#repository,
        service: this.#automationService,
        hasCapability: (capability) => this.hasCapability(capability)
      });
      application.addEventListener("close", () => this.#automationApplications.delete(key));
      this.#automationApplications.set(key, application);
    }
    if (application.rendered) application.bringToFront();
    else await application.render({ force: true });
    return application;
  }

  async openGlobalGallery(options = {}) {
    const actorInput = options?.actor ?? (options?.documentName === "Actor" ? options : null);
    const { actor } = resolveActorInput(actorInput);
    if (!this.#globalApplication) {
      this.#globalApplication = new GlobalGalleryApplication({
        repository: this.#globalRepository,
        service: this.#globalService,
        backupService: this.#backupService,
        thumbnails: this.#thumbnails,
        actor
      });
      this.#globalApplication.addEventListener("close", () => { this.#globalApplication = null; });
    } else if (actor) this.#globalApplication.setTargetActor(actor);
    if (this.#globalApplication.rendered) this.#globalApplication.bringToFront();
    else await this.#globalApplication.render({ force: true });
    return this.#globalApplication;
  }

  async openQuickSwitch(actorOrToken, options = {}) {
    if (options.mode === "wheel" && !this.hasCapability(CAPABILITIES.RADIAL_WHEEL)) {
      notify("warn", "errors.proRequired", { feature: localizeFeature("radialWheel") });
      return null;
    }
    const { actor, resolvedToken } = resolveActorInput(actorOrToken, options.token ?? null);
    if (!actor) {
      notify("warn", "errors.actorRequired");
      return null;
    }
    return this.#quickSwitch.open(resolvedToken ?? actor, { ...options, token: options.token ?? resolvedToken });
  }

  async openSelected() {
    const token = selectedToken();
    if (token) return this.openGallery(token.actor, { token });
    const actor = globalThis.game?.user?.character;
    if (actor) return this.openGallery(actor);
    notify("warn", "errors.selectToken");
    return null;
  }

  async openSelectWheel() {
    if (this.#quickSwitch.openState && this.#quickSwitch.mode === "wheel") {
      this.#quickSwitch.close();
      return null;
    }
    const token = selectedToken();
    const actor = token?.actor ?? globalThis.game?.user?.character;
    if (!actor) {
      notify("warn", "errors.selectToken");
      return null;
    }
    return this.openQuickSwitch(token ?? actor, {
      mode: "wheel",
      origin: token ? "token" : "sheet",
      token
    });
  }

  async applyQuickSlot(slot) {
    const token = selectedToken();
    const actor = token?.actor ?? globalThis.game?.user?.character;
    if (!actor) {
      notify("warn", "errors.selectToken");
      return false;
    }
    const gallery = this.#repository.read(actor);
    const entry = gallery.entries.find((candidate) => candidate.quickSlot === slot);
    if (!entry) {
      notify("warn", "errors.slotEmpty", { slot });
      return false;
    }
    try {
      const target = quickTarget(token, gallery);
      if (!target) throw Object.assign(new Error("featureDisabled"), { code: "featureDisabled" });
      const result = await this.#applicator.apply(actor, entry, target, { token });
      notify("info", result.temporaryCleared ? "notifications.temporaryCommitted" : "notifications.applied");
      return true;
    } catch (error) {
      handleRuntimeError(error);
      return false;
    }
  }

  async applyPrevious() {
    const token = selectedToken();
    const actor = token?.actor ?? globalThis.game?.user?.character;
    if (!actor) {
      notify("warn", "errors.selectToken");
      return false;
    }
    const gallery = this.#repository.read(actor);
    const currentSource = getSetting("enableTokenFeatures", true) && token && !gallery.ignoreTokenChanges
      ? token.document?.texture?.src
      : actor.img;
    const byId = new Map(gallery.entries.map((entry) => [entry.id, entry]));
    const history = gallery.history.map((id) => byId.get(id)).filter(Boolean);
    const entry = history.find((candidate) => ![candidate.source, candidate.derived?.token?.source, candidate.derived?.portrait?.source].includes(currentSource));
    if (!entry) {
      notify("warn", "errors.noPrevious");
      return false;
    }
    try {
      const target = quickTarget(token, gallery);
      if (!target) throw Object.assign(new Error("featureDisabled"), { code: "featureDisabled" });
      const result = await this.#applicator.apply(actor, entry, target, { token });
      notify("info", result.temporaryCleared ? "notifications.temporaryCommitted" : "notifications.applied");
      return true;
    } catch (error) {
      handleRuntimeError(error);
      return false;
    }
  }

  async preloadActor(actor) {
    if (!getSetting("preloadFavorites", true) || !actor) return;
    return this.#preloader.preload(this.#repository.read(actor).entries, { favoritesOnly: true });
  }

  async preloadScene() {
    if (!getSetting("preloadFavorites", true)) return;
    const actors = new Map();
    for (const token of globalThis.canvas?.tokens?.placeables ?? []) {
      if (token.actor) actors.set(token.actor.uuid ?? token.actor.id, token.actor);
    }
    await Promise.allSettled(Array.from(actors.values()).map((actor) => this.preloadActor(actor)));
  }

  async refreshActor(actor) {
    if (!actor) return;
    const app = this.#applications.get(actor.uuid ?? actor.id);
    if (app?.rendered) await app.refresh();
    const automation = this.#automationApplications.get(actor.uuid ?? actor.id);
    if (automation?.rendered) await automation.refresh();
  }

  async apply(actor, entryId, target, options = {}) {
    const { actor: resolvedActor, resolvedToken } = resolveActorInput(actor, options.token ?? null);
    if (!resolvedActor) throw Object.assign(new Error("actorRequired"), { code: "actorRequired" });
    return this.#applicator.apply(resolvedActor, entryId, target, { ...options, token: options.token ?? resolvedToken });
  }

  async applyTemporary(actorInput, entryId, options = {}) {
    const { actor, resolvedToken } = resolveActorInput(actorInput, options.token ?? null);
    if (!actor) throw Object.assign(new Error("actorRequired"), { code: "actorRequired" });
    const target = options.target ?? quickTarget(resolvedToken, this.#repository.read(actor));
    if (!target) throw Object.assign(new Error("featureDisabled"), { code: "featureDisabled" });
    const result = await this.#temporaryService.apply(actor, entryId, target, { token: options.token ?? resolvedToken });
    await this.refreshActor(actor);
    return result;
  }

  async revertTemporary(actorInput) {
    const { actor } = resolveActorInput(actorInput);
    if (!actor) throw Object.assign(new Error("actorRequired"), { code: "actorRequired" });
    const result = await this.#temporaryService.revert(actor);
    await this.refreshActor(actor);
    return result;
  }

  getAppearanceProfiles(actorInput) {
    const { actor } = resolveActorInput(actorInput);
    if (!actor) throw Object.assign(new Error("actorRequired"), { code: "actorRequired" });
    return this.#profileService.list(actor);
  }

  async createAppearanceProfile(actorInput, input) {
    const { actor } = resolveActorInput(actorInput);
    if (!actor) throw Object.assign(new Error("actorRequired"), { code: "actorRequired" });
    const profile = await this.#profileService.create(actor, input);
    await this.refreshActor(actor);
    return profile;
  }

  async updateAppearanceProfile(actorInput, profileId, patch) {
    const { actor } = resolveActorInput(actorInput);
    if (!actor) throw Object.assign(new Error("actorRequired"), { code: "actorRequired" });
    const profile = await this.#profileService.update(actor, profileId, patch);
    await this.refreshActor(actor);
    return profile;
  }

  async removeAppearanceProfile(actorInput, profileId) {
    const { actor } = resolveActorInput(actorInput);
    if (!actor) throw Object.assign(new Error("actorRequired"), { code: "actorRequired" });
    const profile = await this.#profileService.remove(actor, profileId);
    await this.refreshActor(actor);
    return profile;
  }

  async applyAppearanceProfile(actorInput, profileId) {
    const { actor } = resolveActorInput(actorInput);
    if (!actor) throw Object.assign(new Error("actorRequired"), { code: "actorRequired" });
    const result = await this.#profileService.apply(actor, profileId);
    await this.refreshActor(actor);
    return result;
  }

  getAppearanceSequences(actorInput) {
    const { actor } = resolveActorInput(actorInput);
    if (!actor) throw Object.assign(new Error("actorRequired"), { code: "actorRequired" });
    return this.#sequenceService.list(actor);
  }

  getAppearanceSequenceProgress(actorInput, sequenceId = null) {
    const { actor } = resolveActorInput(actorInput);
    if (!actor) throw Object.assign(new Error("actorRequired"), { code: "actorRequired" });
    return this.#sequenceService.getProgress(actor, sequenceId);
  }

  async createAppearanceSequence(actorInput, input) {
    const { actor } = resolveActorInput(actorInput);
    if (!actor) throw Object.assign(new Error("actorRequired"), { code: "actorRequired" });
    const sequence = await this.#sequenceService.create(actor, input);
    await this.refreshActor(actor);
    return sequence;
  }

  async updateAppearanceSequence(actorInput, sequenceId, patch) {
    const { actor } = resolveActorInput(actorInput);
    if (!actor) throw Object.assign(new Error("actorRequired"), { code: "actorRequired" });
    const sequence = await this.#sequenceService.update(actor, sequenceId, patch);
    await this.refreshActor(actor);
    return sequence;
  }

  async duplicateAppearanceSequence(actorInput, sequenceId, options = {}) {
    const { actor } = resolveActorInput(actorInput);
    if (!actor) throw Object.assign(new Error("actorRequired"), { code: "actorRequired" });
    const sequence = await this.#sequenceService.duplicate(actor, sequenceId, options);
    await this.refreshActor(actor);
    return sequence;
  }

  async reorderAppearanceSequences(actorInput, orderedIds) {
    const { actor } = resolveActorInput(actorInput);
    if (!actor) throw Object.assign(new Error("actorRequired"), { code: "actorRequired" });
    const sequences = await this.#sequenceService.reorder(actor, orderedIds);
    await this.refreshActor(actor);
    return sequences;
  }

  async removeAppearanceSequence(actorInput, sequenceId) {
    const { actor } = resolveActorInput(actorInput);
    if (!actor) throw Object.assign(new Error("actorRequired"), { code: "actorRequired" });
    const sequence = await this.#sequenceService.remove(actor, sequenceId);
    await this.refreshActor(actor);
    return sequence;
  }

  async navigateAppearanceSequence(actorInput, sequenceId, action, options = {}) {
    const { actor, resolvedToken } = resolveActorInput(actorInput, options.token ?? null);
    if (!actor) throw Object.assign(new Error("actorRequired"), { code: "actorRequired" });
    const gallery = this.#repository.read(actor);
    const token = options.token ?? resolvedToken;
    const target = options.target ?? quickTarget(token, gallery);
    const result = await this.#sequenceService.navigate(actor, sequenceId, action, { ...options, token, target });
    await this.refreshActor(actor);
    return result;
  }

  nextAppearanceSequence(actorInput, sequenceId = null, options = {}) {
    return this.navigateAppearanceSequence(actorInput, sequenceId, "next", options);
  }

  previousAppearanceSequence(actorInput, sequenceId = null, options = {}) {
    return this.navigateAppearanceSequence(actorInput, sequenceId, "previous", options);
  }

  resetAppearanceSequence(actorInput, sequenceId = null, options = {}) {
    return this.navigateAppearanceSequence(actorInput, sequenceId, "reset", options);
  }

  applyAppearanceSequenceStep(actorInput, sequenceId, stepIndex, options = {}) {
    return this.navigateAppearanceSequence(actorInput, sequenceId, "step", { ...options, stepIndex });
  }

  getAutomationRules(actorInput) {
    const { actor } = resolveActorInput(actorInput);
    if (!actor) throw Object.assign(new Error("actorRequired"), { code: "actorRequired" });
    return this.#automationService.list(actor);
  }

  getAutomationDiagnostics(actorInput) {
    const { actor } = resolveActorInput(actorInput);
    if (!actor) throw Object.assign(new Error("actorRequired"), { code: "actorRequired" });
    return this.#automationService.getDiagnostics(actor);
  }

  getAutomationFacts() {
    return this.#automationService.availableFacts();
  }

  async createAutomationRule(actorInput, input) {
    const { actor } = resolveActorInput(actorInput);
    if (!actor) throw Object.assign(new Error("actorRequired"), { code: "actorRequired" });
    const rule = await this.#automationService.create(actor, input);
    await this.refreshActor(actor);
    return rule;
  }

  async updateAutomationRule(actorInput, ruleId, patch) {
    const { actor } = resolveActorInput(actorInput);
    if (!actor) throw Object.assign(new Error("actorRequired"), { code: "actorRequired" });
    const rule = await this.#automationService.update(actor, ruleId, patch);
    await this.refreshActor(actor);
    return rule;
  }

  async duplicateAutomationRule(actorInput, ruleId, options = {}) {
    const { actor } = resolveActorInput(actorInput);
    if (!actor) throw Object.assign(new Error("actorRequired"), { code: "actorRequired" });
    const rule = await this.#automationService.duplicate(actor, ruleId, options);
    await this.refreshActor(actor);
    return rule;
  }

  async reorderAutomationRules(actorInput, orderedIds) {
    const { actor } = resolveActorInput(actorInput);
    if (!actor) throw Object.assign(new Error("actorRequired"), { code: "actorRequired" });
    const rules = await this.#automationService.reorder(actor, orderedIds);
    await this.refreshActor(actor);
    return rules;
  }

  async removeAutomationRule(actorInput, ruleId) {
    const { actor } = resolveActorInput(actorInput);
    if (!actor) throw Object.assign(new Error("actorRequired"), { code: "actorRequired" });
    const rule = await this.#automationService.remove(actor, ruleId);
    await this.refreshActor(actor);
    return rule;
  }

  async triggerAutomation(actorInput, eventName = "", options = {}) {
    const { actor, resolvedToken } = resolveActorInput(actorInput, options.token ?? null);
    if (!actor) throw Object.assign(new Error("actorRequired"), { code: "actorRequired" });
    const result = await this.#automationService.evaluate(actor, {
      ...options,
      token: options.token ?? resolvedToken,
      trigger: { type: "manual", eventName: String(eventName ?? "") },
      force: options.force ?? true
    });
    await this.refreshActor(actor);
    return result;
  }

  async clearAutomationManualOverride(actorInput) {
    const { actor } = resolveActorInput(actorInput);
    if (!actor) throw Object.assign(new Error("actorRequired"), { code: "actorRequired" });
    const result = await this.#automationService.clearManualOverride(actor);
    await this.refreshActor(actor);
    return result;
  }

  registerAutomationFact(key, provider, metadata = {}) {
    return this.#factRegistry.register(key, provider, metadata);
  }

  registerAutomationAdapter(adapter) {
    const unregister = this.#adapterRegistry.register(adapter);
    if (adapter.supports?.(globalThis.game?.system?.id)) adapter.registerFacts(this.#factRegistry);
    return unregister;
  }

  queueAutomation(actor, context = {}) {
    return this.#automationCoordinator.queue(actor, context);
  }

  isAutomationAuthority() {
    return this.#automationCoordinator.isAuthority();
  }

  queueAutomationActors(actors, context = {}) {
    return this.#automationCoordinator.queueMany(actors, () => context);
  }

  async handleManualAppearance(payload) {
    if (!payload?.actor || payload.origin === "automation" || payload.applicationContext?.origin === "automation") return false;
    await this.#automationService.markManualOverride(payload.actor, { source: payload.source ?? "manual" });
    await this.refreshActor(payload.actor);
    return true;
  }

  async navigateActiveSequence(action) {
    const token = selectedToken();
    const actor = token?.actor ?? globalThis.game?.user?.character;
    if (!actor) {
      notify("warn", "errors.selectToken");
      return false;
    }
    if (!this.hasCapability(CAPABILITIES.APPEARANCE_SEQUENCES)) {
      notify("warn", "errors.sequenceProRequired");
      return false;
    }
    const gallery = this.#repository.read(actor);
    const sequenceId = gallery.activeSequenceId ?? gallery.sequences[0]?.id;
    if (!sequenceId) {
      notify("warn", "errors.sequenceNotFound");
      return false;
    }
    try {
      const target = quickTarget(token, gallery);
      const result = await this.#sequenceService.navigate(actor, sequenceId, action, { token, target });
      notify("info", result.atBoundary ? "notifications.sequenceBoundary" : "notifications.sequenceApplied", {
        position: result.position,
        total: result.total,
        label: result.label ?? ""
      });
      await this.refreshActor(actor);
      return true;
    } catch (error) {
      handleRuntimeError(error);
      return false;
    }
  }

  exportActorMetadata(actorInput) {
    const { actor } = resolveActorInput(actorInput);
    if (!actor) throw Object.assign(new Error("actorRequired"), { code: "actorRequired" });
    return this.#backupService.exportActor(actor);
  }

  exportGlobalMetadata() {
    return this.#backupService.exportGlobal();
  }

  exportWorldMetadata() {
    return this.#backupService.exportWorld();
  }

  async importActorMetadata(actorInput, envelope, options = {}) {
    const { actor } = resolveActorInput(actorInput);
    if (!actor) throw Object.assign(new Error("actorRequired"), { code: "actorRequired" });
    const result = await this.#backupService.importActor(actor, envelope, options);
    await this.refreshActor(actor);
    return result;
  }

  async importGlobalMetadata(envelope, options = {}) {
    const result = await this.#backupService.importGlobal(envelope, options);
    await this.refreshGlobalGallery();
    return result;
  }

  async importWorldMetadata(envelope, options = {}) {
    const result = await this.#backupService.importWorld(envelope, options);
    await this.refreshGlobalGallery();
    await Promise.allSettled(Array.from(this.#applications.values()).map((application) => application.refresh()));
    return result;
  }

  getGallery(actorInput) {
    const { actor } = resolveActorInput(actorInput);
    if (!actor) throw Object.assign(new Error("actorRequired"), { code: "actorRequired" });
    return this.#repository.read(actor);
  }

  getGlobalGallery() {
    return this.#globalService.getGallery();
  }

  async refreshGlobalGallery() {
    if (this.#globalApplication?.rendered) await this.#globalApplication.refresh();
  }

  async addGlobalEntryToActor(entryIds, actorInput) {
    const { actor } = resolveActorInput(actorInput);
    if (!actor) throw Object.assign(new Error("actorRequired"), { code: "actorRequired" });
    const result = await this.#globalService.addToActor(actor, entryIds);
    await this.refreshActor(actor);
    return result;
  }

  hasCapability(capability) {
    return this.#entitlements.has(capability);
  }

  getCapabilities() {
    return this.#entitlements.capabilities();
  }

  getEntitlementStatus() {
    return this.#entitlements.status();
  }

  async refreshEntitlements() {
    const previous = this.#entitlements.status();
    const status = await this.#entitlements.refresh();
    if (!this.hasCapability(CAPABILITIES.RADIAL_WHEEL) && this.#quickSwitch.mode === "wheel") this.#quickSwitch.close();
    if (!sameEntitlement(previous, status)) globalThis.Hooks?.callAll?.(HOOKS.ENTITLEMENT_CHANGED, status);
    if (!sameEntitlement(previous, status)) await Promise.allSettled([
      ...Array.from(this.#applications.values()).map((application) => application.refresh()),
      ...Array.from(this.#automationApplications.values()).map((application) => application.refresh())
    ]);
    return status;
  }

  async destroy() {
    this.#quickSwitch.close();
    this.#automationCoordinator.destroy();
    const applications = Array.from(this.#applications.values());
    this.#applications.clear();
    applications.push(...this.#automationApplications.values());
    this.#automationApplications.clear();
    if (this.#globalApplication) applications.push(this.#globalApplication);
    this.#globalApplication = null;
    await Promise.allSettled(applications.map((application) => application.close({ animate: false })));
  }
}

function exposeApi(instance) {
  const module = globalThis.game?.modules?.get?.(MODULE_ID);
  if (!module) return;
  module.api = createPublicApi(instance);
}

function resolveActorInput(value, token = null) {
  if (value?.documentName === "Actor") return { actor: value, resolvedToken: token };
  if (value?.actor) return { actor: value.actor, resolvedToken: value.object ?? value };
  if (typeof value === "string") {
    const actor = globalThis.game?.actors?.get?.(value)
      ?? globalThis.game?.actors?.get?.(value.split(".").at(-1));
    return { actor, resolvedToken: token ?? getActiveTokenForActor(actor) };
  }
  return { actor: null, resolvedToken: token };
}

function localizeFeature(capability) {
  return globalThis.game?.i18n?.localize?.(`AIG.features.${capability}`) ?? capability;
}

function sameEntitlement(left, right) {
  return ["tier", "state", "source", "error"]
    .every((key) => left?.[key] === right?.[key]);
}

function selectedToken() {
  return globalThis.canvas?.tokens?.controlled?.[0] ?? null;
}

function getSetting(key, fallback) {
  try {
    return globalThis.game?.settings?.get?.(MODULE_ID, key) ?? fallback;
  } catch {
    return fallback;
  }
}

function quickTarget(token, gallery = null) {
  return resolveQuickTarget({
    origin: token ? "token" : "sheet",
    hasToken: Boolean(token),
    configuredTarget: getSetting("quickApplyTarget", APPLY_TARGETS.PORTRAIT_CURRENT),
    portraitEnabled: getSetting("enablePortraitFeatures", true),
    tokenEnabled: getSetting("enableTokenFeatures", true),
    ignoreTokenChanges: Boolean(gallery?.ignoreTokenChanges)
  });
}

function handleRuntimeError(error) {
  warn("Runtime action failed.", error);
  const key = error?.code === "tokenRequired"
    ? "errors.tokenRequired"
      : error?.code === "featureDisabled" ? "errors.featureDisabled"
      : error?.code === "tokenDisabledForGallery" ? "errors.tokenDisabledForGallery"
        : error?.code === "sequenceNotFound" ? "errors.sequenceNotFound"
          : error?.code === "sequenceTargetMissing" ? "errors.sequenceTargetMissing"
            : error?.code === "capabilityRequired" ? "errors.sequenceProRequired" : "errors.actionFailed";
  notify("error", key);
}

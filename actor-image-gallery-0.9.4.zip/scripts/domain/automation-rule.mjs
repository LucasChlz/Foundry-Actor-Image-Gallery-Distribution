import {
  APPLY_TARGETS,
  AUTOMATION_ACTION_TYPES,
  AUTOMATION_RULE_SCHEMA_VERSION,
  AUTOMATION_TRIGGER_TYPES,
  CONDITION_GROUP_OPERATORS,
  CONDITION_OPERATORS,
  MANUAL_OVERRIDE_DURATIONS,
  MANUAL_OVERRIDE_POLICIES
} from "../constants.mjs";
import { clamp, deepClone, randomId } from "../utils.mjs";

const VALID_TRIGGERS = new Set(Object.values(AUTOMATION_TRIGGER_TYPES));
const VALID_ACTIONS = new Set(Object.values(AUTOMATION_ACTION_TYPES));
const VALID_CONDITION_OPERATORS = new Set(Object.values(CONDITION_OPERATORS));
const VALID_GROUP_OPERATORS = new Set(Object.values(CONDITION_GROUP_OPERATORS));
const VALID_OVERRIDE_POLICIES = new Set(Object.values(MANUAL_OVERRIDE_POLICIES));
const VALID_OVERRIDE_DURATIONS = new Set(Object.values(MANUAL_OVERRIDE_DURATIONS));
const VALID_TARGETS = new Set(Object.values(APPLY_TARGETS).filter((target) => target !== APPLY_TARGETS.ASK));
const FACT_KEY = /^[a-z][a-zA-Z0-9_.-]{0,119}$/;
const MAX_TREE_DEPTH = 6;
const MAX_GROUP_CHILDREN = 50;
const MAX_DIAGNOSTIC_ITEMS = 30;

export function createAutomationRule(input = {}, { now = new Date().toISOString(), id = randomId() } = {}) {
  const source = record(input);
  const createdAt = validDate(source.createdAt) ?? now;
  const stableId = String(source.id ?? id).trim() || String(id);
  return {
    ...deepClone(source),
    schemaVersion: AUTOMATION_RULE_SCHEMA_VERSION,
    id: stableId,
    name: String(source.name ?? "").trim(),
    description: String(source.description ?? "").trim(),
    enabled: source.enabled !== false,
    priority: Math.round(clamp(source.priority ?? 0, -1000, 1000)),
    trigger: normalizeTrigger(source.trigger),
    conditionTree: normalizeConditionTree(source.conditionTree),
    action: normalizeAutomationAction(source.action),
    cooldownMs: Math.round(clamp(source.cooldownMs ?? 0, 0, 86_400_000)),
    manualOverridePolicy: VALID_OVERRIDE_POLICIES.has(source.manualOverridePolicy)
      ? source.manualOverridePolicy
      : MANUAL_OVERRIDE_POLICIES.RESPECT,
    createdAt,
    updatedAt: validDate(source.updatedAt) ?? createdAt
  };
}

export function addAutomationRule(galleryInput, ruleInput, options = {}) {
  const gallery = normalizeAutomationGallery(galleryInput);
  validateAutomationRuleInput(ruleInput);
  const rule = createAutomationRule(ruleInput, options);
  validateAutomationRule(rule);
  if (gallery.automationRules.some((candidate) => candidate.id === rule.id)) throw new AutomationRuleError("automationRuleIdConflict");
  gallery.automationRules.push(rule);
  return { gallery, rule };
}

export function updateAutomationRule(galleryInput, ruleId, patch, { now = new Date().toISOString() } = {}) {
  const gallery = normalizeAutomationGallery(galleryInput);
  const index = gallery.automationRules.findIndex((candidate) => candidate.id === String(ruleId));
  if (index < 0) throw new AutomationRuleError("automationRuleNotFound");
  const current = gallery.automationRules[index];
  const edits = record(patch);
  const candidate = {
    ...current,
    ...deepClone(edits),
    id: current.id,
    createdAt: current.createdAt,
    updatedAt: now,
    trigger: Object.hasOwn(edits, "trigger") ? edits.trigger : current.trigger,
    conditionTree: Object.hasOwn(edits, "conditionTree") ? edits.conditionTree : current.conditionTree,
    action: Object.hasOwn(edits, "action") ? edits.action : current.action
  };
  validateAutomationRuleInput(candidate);
  const rule = createAutomationRule(candidate, { now, id: current.id });
  validateAutomationRule(rule);
  gallery.automationRules[index] = rule;
  return { gallery, rule };
}

export function duplicateAutomationRule(galleryInput, ruleId, { suffix = " copy", now = new Date().toISOString(), id } = {}) {
  const gallery = normalizeAutomationGallery(galleryInput);
  const source = gallery.automationRules.find((candidate) => candidate.id === String(ruleId));
  if (!source) throw new AutomationRuleError("automationRuleNotFound");
  return addAutomationRule(gallery, {
    ...deepClone(source),
    id: undefined,
    name: `${source.name}${suffix}`,
    enabled: false,
    createdAt: now,
    updatedAt: now
  }, { now, id });
}

export function removeAutomationRule(galleryInput, ruleId) {
  const gallery = normalizeAutomationGallery(galleryInput);
  const index = gallery.automationRules.findIndex((candidate) => candidate.id === String(ruleId));
  if (index < 0) throw new AutomationRuleError("automationRuleNotFound");
  const [rule] = gallery.automationRules.splice(index, 1);
  delete gallery.automationState.cooldowns[rule.id];
  gallery.automationState.matchedRuleIds = gallery.automationState.matchedRuleIds.filter((id) => id !== rule.id);
  if (gallery.automationState.lastAppliedRuleId === rule.id) gallery.automationState.lastAppliedRuleId = null;
  return { gallery, rule };
}

export function reorderAutomationRules(galleryInput, orderedIds) {
  const gallery = normalizeAutomationGallery(galleryInput);
  const allIds = gallery.automationRules.map((rule) => rule.id);
  const normalized = Array.from(new Set((Array.isArray(orderedIds) ? orderedIds : []).map(String)));
  if (normalized.length !== allIds.length || allIds.some((id) => !normalized.includes(id))) {
    throw new AutomationRuleError("automationRuleOrderInvalid");
  }
  const byId = new Map(gallery.automationRules.map((rule) => [rule.id, rule]));
  gallery.automationRules = normalized.map((id) => byId.get(id));
  return gallery;
}

export function normalizeAutomationRules(value) {
  const result = [];
  const ids = new Set();
  for (const item of Array.isArray(value) ? value : []) {
    if (!item || typeof item !== "object" || Array.isArray(item)) continue;
    const stableId = String(item.id ?? "").trim();
    if (!stableId || ids.has(stableId)) continue;
    const rule = createAutomationRule(item, { id: stableId });
    ids.add(rule.id);
    result.push(rule);
  }
  return result;
}

export function validateAutomationRule(ruleInput) {
  validateAutomationRuleInput(ruleInput);
  const rule = createAutomationRule(ruleInput);
  if (!rule.name) throw new AutomationRuleError("automationRuleNameRequired");
  if (!VALID_TRIGGERS.has(rule.trigger.type)) throw new AutomationRuleError("automationTriggerInvalid");
  if (rule.trigger.type === AUTOMATION_TRIGGER_TYPES.MANUAL && rule.trigger.event.length > 120) {
    throw new AutomationRuleError("automationTriggerInvalid");
  }
  validateConditionNode(rule.conditionTree, 0);
  validateAction(rule.action);
  return rule;
}

function validateAutomationRuleInput(ruleInput) {
  const source = record(ruleInput);
  if (source.trigger?.type && !VALID_TRIGGERS.has(source.trigger.type)) throw new AutomationRuleError("automationTriggerInvalid");
  if (source.action?.type && !VALID_ACTIONS.has(source.action.type)) throw new AutomationRuleError("automationActionInvalid");
  if (source.action?.target && !VALID_TARGETS.has(source.action.target)) throw new AutomationRuleError("automationActionInvalid");
  if (source.manualOverridePolicy && !VALID_OVERRIDE_POLICIES.has(source.manualOverridePolicy)) throw new AutomationRuleError("automationOverridePolicyInvalid");
  validateConditionInput(source.conditionTree, 0);
}

export function normalizeTrigger(input) {
  const source = record(input);
  return {
    ...deepClone(source),
    type: VALID_TRIGGERS.has(source.type) ? source.type : AUTOMATION_TRIGGER_TYPES.ACTOR_UPDATE,
    event: String(source.event ?? "").trim()
  };
}

export function normalizeConditionTree(input, depth = 0) {
  if (depth > MAX_TREE_DEPTH) return { operator: CONDITION_GROUP_OPERATORS.AND, children: [] };
  const source = record(input);
  if (!Object.keys(source).length) return { operator: CONDITION_GROUP_OPERATORS.AND, children: [] };
  if (Array.isArray(source.children) || VALID_GROUP_OPERATORS.has(source.operator)) {
    const children = (Array.isArray(source.children) ? source.children : [])
      .slice(0, MAX_GROUP_CHILDREN)
      .map((child) => normalizeConditionTree(child, depth + 1));
    return {
      operator: VALID_GROUP_OPERATORS.has(source.operator) ? source.operator : CONDITION_GROUP_OPERATORS.AND,
      children
    };
  }
  return {
    fact: String(source.fact ?? "").trim(),
    operator: VALID_CONDITION_OPERATORS.has(source.operator) ? source.operator : CONDITION_OPERATORS.EQ,
    ...(Object.hasOwn(source, "value") ? { value: deepClone(source.value) } : {})
  };
}

export function normalizeAutomationAction(input) {
  const source = record(input);
  const type = VALID_ACTIONS.has(source.type) ? source.type : AUTOMATION_ACTION_TYPES.APPLY_ENTRY;
  const action = { ...deepClone(source), type };
  if ([AUTOMATION_ACTION_TYPES.APPLY_ENTRY, AUTOMATION_ACTION_TYPES.APPLY_TEMPORARY].includes(type)) {
    action.entryId = String(source.entryId ?? source.targetId ?? "").trim();
    action.target = VALID_TARGETS.has(source.target) ? source.target : APPLY_TARGETS.PORTRAIT_CURRENT;
  }
  if (type === AUTOMATION_ACTION_TYPES.APPLY_PROFILE) action.profileId = String(source.profileId ?? source.targetId ?? "").trim();
  if ([AUTOMATION_ACTION_TYPES.SEQUENCE_NEXT, AUTOMATION_ACTION_TYPES.SEQUENCE_PREVIOUS, AUTOMATION_ACTION_TYPES.SEQUENCE_RESET, AUTOMATION_ACTION_TYPES.SEQUENCE_STEP].includes(type)) {
    action.sequenceId = String(source.sequenceId ?? source.targetId ?? "").trim();
    if (type === AUTOMATION_ACTION_TYPES.SEQUENCE_STEP) action.stepIndex = Math.max(0, Number.parseInt(source.stepIndex ?? 0, 10) || 0);
    action.target = VALID_TARGETS.has(source.target) ? source.target : APPLY_TARGETS.PORTRAIT_CURRENT;
  }
  return action;
}

export function normalizeAutomationState(value, rules = []) {
  const source = record(value);
  const ruleIds = new Set(rules.map((rule) => rule.id));
  const cooldowns = {};
  for (const [ruleId, timestamp] of Object.entries(record(source.cooldowns))) {
    const number = Number(timestamp);
    if (ruleIds.has(ruleId) && Number.isFinite(number) && number >= 0) cooldowns[ruleId] = number;
  }
  return {
    manualOverride: normalizeManualOverride(source.manualOverride),
    cooldowns,
    matchedRuleIds: Array.from(new Set((Array.isArray(source.matchedRuleIds) ? source.matchedRuleIds : []).map(String)))
      .filter((id) => ruleIds.has(id)),
    lastAppliedRuleId: source.lastAppliedRuleId && ruleIds.has(String(source.lastAppliedRuleId))
      ? String(source.lastAppliedRuleId)
      : null,
    lastAppliedAt: finiteNumber(source.lastAppliedAt),
    lastEvaluation: normalizeDiagnostic(source.lastEvaluation, ruleIds)
  };
}

export function normalizeManualOverride(value) {
  if (!value || typeof value !== "object" || Array.isArray(value) || value.active === false) return null;
  return {
    active: true,
    source: String(value.source ?? "manual"),
    startedAt: finiteNumber(value.startedAt) ?? Date.now(),
    duration: VALID_OVERRIDE_DURATIONS.has(value.duration) ? value.duration : MANUAL_OVERRIDE_DURATIONS.UNTIL_CLEARED,
    sceneId: value.sceneId ? String(value.sceneId) : null,
    combatId: value.combatId ? String(value.combatId) : null
  };
}

export function normalizeDiagnostic(value, ruleIds = new Set()) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  const allowed = ruleIds instanceof Set ? ruleIds : new Set(ruleIds);
  const winnerRuleId = value.winnerRuleId && allowed.has(String(value.winnerRuleId)) ? String(value.winnerRuleId) : null;
  return {
    evaluatedAt: finiteNumber(value.evaluatedAt) ?? Date.now(),
    triggerType: String(value.triggerType ?? ""),
    eventName: String(value.eventName ?? ""),
    outcome: String(value.outcome ?? "none"),
    winnerRuleId,
    winnerName: winnerRuleId ? String(value.winnerName ?? "") : null,
    errorCode: value.errorCode ? String(value.errorCode) : null,
    suppressed: (Array.isArray(value.suppressed) ? value.suppressed : []).slice(0, MAX_DIAGNOSTIC_ITEMS).map((item) => ({
      ruleId: String(item?.ruleId ?? ""),
      name: String(item?.name ?? ""),
      reason: String(item?.reason ?? "")
    })),
    conditions: (Array.isArray(value.conditions) ? value.conditions : []).slice(0, MAX_DIAGNOSTIC_ITEMS).map((item) => ({
      fact: String(item?.fact ?? ""),
      operator: String(item?.operator ?? ""),
      matched: Boolean(item?.matched),
      actual: diagnosticValue(item?.actual),
      expected: diagnosticValue(item?.expected)
    }))
  };
}

export class AutomationRuleError extends Error {
  constructor(code) {
    super(code);
    this.name = "AutomationRuleError";
    this.code = code;
  }
}

function normalizeAutomationGallery(input) {
  const gallery = deepClone(input && typeof input === "object" ? input : {});
  gallery.automationRules = normalizeAutomationRules(gallery.automationRules);
  gallery.automationState = normalizeAutomationState(gallery.automationState, gallery.automationRules);
  return gallery;
}

function validateConditionNode(node, depth) {
  if (depth > MAX_TREE_DEPTH) throw new AutomationRuleError("automationConditionTooDeep");
  if (Array.isArray(node?.children)) {
    if (!VALID_GROUP_OPERATORS.has(node.operator) || node.children.length > MAX_GROUP_CHILDREN) {
      throw new AutomationRuleError("automationConditionInvalid");
    }
    for (const child of node.children) validateConditionNode(child, depth + 1);
    return;
  }
  if (!FACT_KEY.test(String(node?.fact ?? "")) || !VALID_CONDITION_OPERATORS.has(node?.operator)) {
    throw new AutomationRuleError("automationConditionInvalid");
  }
}

function validateConditionInput(input, depth) {
  const source = record(input);
  if (!Object.keys(source).length) return;
  if (depth > MAX_TREE_DEPTH) throw new AutomationRuleError("automationConditionTooDeep");
  if (Array.isArray(source.children) || VALID_GROUP_OPERATORS.has(source.operator)) {
    if (!VALID_GROUP_OPERATORS.has(source.operator) || !Array.isArray(source.children) || source.children.length > MAX_GROUP_CHILDREN) {
      throw new AutomationRuleError("automationConditionInvalid");
    }
    for (const child of source.children) validateConditionInput(child, depth + 1);
    return;
  }
  if (!FACT_KEY.test(String(source.fact ?? "")) || !VALID_CONDITION_OPERATORS.has(source.operator)) {
    throw new AutomationRuleError("automationConditionInvalid");
  }
}

function validateAction(action) {
  if (!VALID_ACTIONS.has(action.type)) throw new AutomationRuleError("automationActionInvalid");
  if ([AUTOMATION_ACTION_TYPES.APPLY_ENTRY, AUTOMATION_ACTION_TYPES.APPLY_TEMPORARY].includes(action.type) && !action.entryId) {
    throw new AutomationRuleError("automationActionTargetRequired");
  }
  if (action.type === AUTOMATION_ACTION_TYPES.APPLY_PROFILE && !action.profileId) {
    throw new AutomationRuleError("automationActionTargetRequired");
  }
  if ([AUTOMATION_ACTION_TYPES.SEQUENCE_NEXT, AUTOMATION_ACTION_TYPES.SEQUENCE_PREVIOUS, AUTOMATION_ACTION_TYPES.SEQUENCE_RESET, AUTOMATION_ACTION_TYPES.SEQUENCE_STEP].includes(action.type) && !action.sequenceId) {
    throw new AutomationRuleError("automationActionTargetRequired");
  }
}

function record(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}

function validDate(value) {
  if (!value) return null;
  const time = Date.parse(value);
  return Number.isFinite(time) ? new Date(time).toISOString() : null;
}

function finiteNumber(value) {
  const number = Number(value);
  return Number.isFinite(number) ? number : null;
}

function diagnosticValue(value) {
  if (value === undefined) return null;
  if (value === null || ["string", "number", "boolean"].includes(typeof value)) return value;
  try {
    const serialized = JSON.stringify(value);
    return serialized.length > 240 ? `${serialized.slice(0, 237)}...` : serialized;
  } catch {
    return String(value).slice(0, 240);
  }
}

import { HOOKS, MODULE_ID } from "./constants.mjs";
import {
  createBackupEnvelope,
  IMPORT_STRATEGIES,
  mergeActorGallery,
  mergeGlobalGallery,
  parseBackupEnvelope
} from "./domain/backup.mjs";
import { actorCanUpdate, deepClone, warn } from "./utils.mjs";

export class BackupService {
  #actorRepository;
  #globalRepository;

  constructor({ actorRepository, globalRepository }) {
    this.#actorRepository = actorRepository;
    this.#globalRepository = globalRepository;
  }

  exportActor(actor) {
    if (!actor) throw new BackupServiceError("actorRequired");
    return createBackupEnvelope({
      scope: "actor",
      moduleVersion: moduleVersion(),
      payload: {
        actor: { id: actor.id, uuid: actor.uuid ?? `Actor.${actor.id}`, name: actor.name },
        gallery: this.#actorRepository.read(actor)
      }
    });
  }

  exportGlobal() {
    return createBackupEnvelope({
      scope: "global",
      moduleVersion: moduleVersion(),
      payload: { gallery: this.#globalRepository.read() }
    });
  }

  exportWorld() {
    assertGM();
    return createBackupEnvelope({
      scope: "world",
      moduleVersion: moduleVersion(),
      payload: {
        globalGallery: this.#globalRepository.read(),
        actors: worldActors().map((actor) => ({
          actor: { id: actor.id, uuid: actor.uuid ?? `Actor.${actor.id}`, name: actor.name },
          gallery: this.#actorRepository.read(actor)
        }))
      }
    });
  }

  async importActor(actor, input, { strategy = IMPORT_STRATEGIES.SKIP } = {}) {
    if (!actor) throw new BackupServiceError("actorRequired");
    if (!actorCanUpdate(actor)) throw new BackupServiceError("permissionDenied");
    const envelope = parseBackupEnvelope(input, { scopes: ["actor"] });
    assertGalleryPayload(envelope.payload);
    const sameActor = envelope.payload.actor?.uuid === actor.uuid || envelope.payload.actor?.id === actor.id;
    const planned = mergeActorGallery(
      this.#actorRepository.read(actor),
      envelope.payload.gallery,
      strategy,
      { importTemporaryState: sameActor }
    );
    const persisted = await this.#actorRepository.write(actor, planned.gallery);
    const result = { scope: "actor", actor, strategy, report: planned.report, gallery: persisted };
    callHook(HOOKS.BACKUP_IMPORTED, copyResult(result));
    return result;
  }

  async importGlobal(input, { strategy = IMPORT_STRATEGIES.SKIP } = {}) {
    const envelope = parseBackupEnvelope(input, { scopes: ["global"] });
    assertGalleryPayload(envelope.payload);
    const planned = mergeGlobalGallery(this.#globalRepository.read(), envelope.payload.gallery, strategy);
    const persisted = await this.#globalRepository.write(planned.gallery);
    const result = { scope: "global", strategy, report: planned.report, gallery: persisted };
    callHook(HOOKS.BACKUP_IMPORTED, copyResult(result));
    return result;
  }

  async importWorld(input, { strategy = IMPORT_STRATEGIES.SKIP } = {}) {
    assertGM();
    const envelope = parseBackupEnvelope(input, { scopes: ["world"] });
    const payload = envelope.payload;
    if (!payload.globalGallery || !Array.isArray(payload.actors)) throw new BackupServiceError("backupPayloadInvalid");
    const globalPlan = mergeGlobalGallery(this.#globalRepository.read(), payload.globalGallery, strategy);
    const actorPlans = [];
    for (const item of payload.actors) {
      assertGalleryPayload(item);
      const actor = resolveWorldActor(item.actor);
      if (!actor) {
        actorPlans.push({ actor: null, source: item, skipped: "actorMissing" });
        continue;
      }
      actorPlans.push({
        actor,
        plan: mergeActorGallery(this.#actorRepository.read(actor), item.gallery, strategy, { importTemporaryState: true })
      });
    }

    await this.#globalRepository.write(globalPlan.gallery);
    const actors = [];
    for (const item of actorPlans) {
      if (!item.actor) {
        actors.push({ actorId: item.source.actor?.id ?? null, actorUuid: item.source.actor?.uuid ?? null, status: item.skipped });
        continue;
      }
      await this.#actorRepository.write(item.actor, item.plan.gallery);
      actors.push({ actorId: item.actor.id, actorUuid: item.actor.uuid, status: "imported", report: item.plan.report });
    }
    const result = { scope: "world", strategy, global: globalPlan.report, actors };
    callHook(HOOKS.BACKUP_IMPORTED, copyResult(result));
    return result;
  }
}

function assertGalleryPayload(payload) {
  if (!payload || typeof payload !== "object" || !payload.gallery || typeof payload.gallery !== "object") {
    throw new BackupServiceError("backupPayloadInvalid");
  }
}

function assertGM() {
  if (!globalThis.game?.user?.isGM) throw new BackupServiceError("globalPermissionDenied");
}

function moduleVersion() {
  return globalThis.game?.modules?.get?.(MODULE_ID)?.version ?? "0.0.0";
}

function worldActors() {
  const collection = globalThis.game?.actors;
  return collection?.contents ?? Array.from(collection?.values?.() ?? []);
}

function resolveWorldActor(reference = {}) {
  return worldActors().find((actor) => actor.uuid === reference.uuid || actor.id === reference.id) ?? null;
}

function copyResult(result) {
  const copy = { ...result };
  if (copy.actor) copy.actor = { id: copy.actor.id, uuid: copy.actor.uuid, name: copy.actor.name };
  if (copy.gallery) copy.gallery = deepClone(copy.gallery);
  return deepClone(copy);
}

function callHook(name, ...args) {
  try {
    globalThis.Hooks?.callAll?.(name, ...args);
  } catch (error) {
    warn(`Integration hook ${name} failed.`, error);
  }
}

export class BackupServiceError extends Error {
  constructor(code) {
    super(code);
    this.name = "BackupServiceError";
    this.code = code;
  }
}

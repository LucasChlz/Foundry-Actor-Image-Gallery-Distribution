import { GLOBAL_GALLERY_SCHEMA_VERSION, SORT_MODES } from "../constants.mjs";
import { normalizeTags } from "./gallery.mjs";
import { deepClone, randomId, sourceName } from "../utils.mjs";

export function createGlobalEntry(input = {}, { id = randomId(), now = new Date().toISOString() } = {}) {
  const source = String(input.source ?? "").trim();
  return {
    id: String(input.id ?? id),
    source,
    name: String(input.name ?? "").trim() || sourceName(source),
    tags: normalizeTags(input.tags),
    description: String(input.description ?? "").trim(),
    category: String(input.category ?? input.collection ?? "").trim(),
    favorite: Boolean(input.favorite),
    manualOrder: Number.isFinite(Number(input.manualOrder)) ? Number(input.manualOrder) : 0,
    createdAt: validDate(input.createdAt) ?? now,
    updatedAt: validDate(input.updatedAt) ?? now
  };
}

export function createGlobalGallery(input = {}) {
  const source = input && typeof input === "object" && !Array.isArray(input) ? input : {};
  const entries = (Array.isArray(source.entries) ? source.entries : [])
    .map((entry, index) => createGlobalEntry({ ...entry, manualOrder: entry.manualOrder ?? index }));
  compactOrder(entries);
  return { schemaVersion: GLOBAL_GALLERY_SCHEMA_VERSION, entries };
}

export function addGlobalEntry(galleryInput, entryInput, options = {}) {
  const gallery = createGlobalGallery(galleryInput);
  const entry = createGlobalEntry({ ...entryInput, manualOrder: gallery.entries.length }, options);
  if (!entry.source) throw new GlobalGalleryError("sourceRequired");
  gallery.entries.push(entry);
  return { gallery, entry };
}

export function updateGlobalEntry(galleryInput, entryId, patch, { now = new Date().toISOString() } = {}) {
  const gallery = createGlobalGallery(galleryInput);
  const index = gallery.entries.findIndex((entry) => entry.id === entryId);
  if (index < 0) throw new GlobalGalleryError("entryNotFound");
  const current = gallery.entries[index];
  const entry = createGlobalEntry({
    ...current,
    ...deepClone(patch),
    id: current.id,
    createdAt: current.createdAt,
    updatedAt: now,
    manualOrder: current.manualOrder
  }, { id: current.id, now });
  if (!entry.source) throw new GlobalGalleryError("sourceRequired");
  gallery.entries[index] = entry;
  return { gallery, entry };
}

export function removeGlobalEntry(galleryInput, entryId) {
  const gallery = createGlobalGallery(galleryInput);
  const index = gallery.entries.findIndex((entry) => entry.id === entryId);
  if (index < 0) throw new GlobalGalleryError("entryNotFound");
  const [entry] = gallery.entries.splice(index, 1);
  compactOrder(gallery.entries);
  return { gallery, entry };
}

export function toggleGlobalFavorite(galleryInput, entryId) {
  const gallery = createGlobalGallery(galleryInput);
  const entry = gallery.entries.find((candidate) => candidate.id === entryId);
  if (!entry) throw new GlobalGalleryError("entryNotFound");
  entry.favorite = !entry.favorite;
  entry.updatedAt = new Date().toISOString();
  return { gallery, entry };
}

export function queryGlobalEntries(galleryInput, {
  query = "",
  category = "",
  favoritesOnly = false,
  sort = SORT_MODES.MANUAL
} = {}) {
  const entries = createGlobalGallery(galleryInput).entries;
  const needle = normalizeSearch(query);
  const normalizedCategory = normalizeSearch(category);
  return entries.filter((entry) => {
    if (favoritesOnly && !entry.favorite) return false;
    if (normalizedCategory && normalizeSearch(entry.category) !== normalizedCategory) return false;
    if (!needle) return true;
    return normalizeSearch([entry.name, entry.description, entry.category, ...entry.tags].join(" ")).includes(needle);
  }).sort(globalSorter(sort));
}

export function getGlobalCategories(galleryInput) {
  return Array.from(new Set(createGlobalGallery(galleryInput).entries.map((entry) => entry.category).filter(Boolean)))
    .sort((left, right) => left.localeCompare(right));
}

export class GlobalGalleryError extends Error {
  constructor(code) {
    super(code);
    this.name = "GlobalGalleryError";
    this.code = code;
  }
}

function compactOrder(entries) {
  entries.sort((left, right) => left.manualOrder - right.manualOrder);
  entries.forEach((entry, index) => { entry.manualOrder = index; });
}

function normalizeSearch(value) {
  return String(value ?? "").normalize("NFKD").replace(/[\u0300-\u036f]/g, "").toLocaleLowerCase();
}

function globalSorter(mode) {
  const name = (left, right) => left.name.localeCompare(right.name, undefined, { sensitivity: "base" });
  if (mode === SORT_MODES.NAME) return name;
  if (mode === SORT_MODES.RECENT) return (left, right) => Date.parse(right.createdAt) - Date.parse(left.createdAt) || name(left, right);
  if (mode === SORT_MODES.FAVORITES) return (left, right) => Number(right.favorite) - Number(left.favorite) || name(left, right);
  return (left, right) => left.manualOrder - right.manualOrder || name(left, right);
}

function validDate(value) {
  if (!value) return null;
  const time = Date.parse(value);
  return Number.isFinite(time) ? new Date(time).toISOString() : null;
}

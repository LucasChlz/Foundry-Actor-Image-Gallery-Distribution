import { deepClone } from "../utils.mjs";

const FACT_KEY = /^[a-z][a-zA-Z0-9_.-]{0,119}$/;

export class FactProviderRegistry {
  #providers = new Map();

  register(key, provider, metadata = {}) {
    const normalized = String(key ?? "").trim();
    if (!FACT_KEY.test(normalized)) throw new FactRegistryError("automationFactKeyInvalid");
    if (typeof provider !== "function") throw new FactRegistryError("automationFactProviderInvalid");
    const definition = {
      provider,
      metadata: {
        key: normalized,
        label: String(metadata.label ?? normalized),
        type: String(metadata.type ?? "unknown"),
        source: String(metadata.source ?? "external"),
        description: String(metadata.description ?? "")
      }
    };
    this.#providers.set(normalized, definition);
    return () => this.#providers.get(normalized) === definition && this.#providers.delete(normalized);
  }

  has(key) {
    return this.#providers.has(String(key));
  }

  list() {
    return Array.from(this.#providers.values(), ({ metadata }) => deepClone(metadata))
      .sort((left, right) => left.key.localeCompare(right.key));
  }

  async resolve(context = {}) {
    const facts = {};
    const errors = [];
    for (const [key, definition] of this.#providers) {
      try {
        facts[key] = await definition.provider(context);
      } catch (error) {
        facts[key] = undefined;
        errors.push({ key, error: String(error?.message ?? error) });
      }
    }
    return { facts, errors };
  }
}

export function registerCoreFacts(registry) {
  const core = (key, provider, type = "string") => registry.register(key, provider, { label: `AIG.automation.facts.${key}`, type, source: "core" });
  core("event.trigger", ({ trigger }) => trigger?.type ?? "", "string");
  core("event.name", ({ trigger }) => trigger?.eventName ?? "", "string");
  core("actor.id", ({ actor }) => actor?.id ?? null, "string");
  core("actor.uuid", ({ actor }) => actor?.uuid ?? null, "string");
  core("actor.type", ({ actor }) => actor?.type ?? null, "string");
  core("token.id", ({ token }) => token?.document?.id ?? token?.id ?? null, "string");
  core("token.uuid", ({ token }) => token?.document?.uuid ?? token?.uuid ?? null, "string");
  core("token.linked", ({ token }) => Boolean(token?.document?.actorLink ?? token?.actorLink), "boolean");
  core("token.placed", ({ token }) => Boolean(token?.document?.parent ?? token?.parent), "boolean");
  core("token.selected", ({ token }) => Boolean(token?.controlled), "boolean");
  core("scene.id", ({ scene }) => scene?.id ?? null, "string");
  core("scene.uuid", ({ scene }) => scene?.uuid ?? null, "string");
  core("scene.active", ({ scene }) => Boolean(scene?.active ?? scene?.isView), "boolean");
  core("combat.id", ({ combat }) => combat?.id ?? null, "string");
  core("combat.active", ({ combat }) => Boolean(combat?.started ?? combat?.active), "boolean");
  core("combat.round", ({ combat }) => finite(combat?.round), "number");
  core("combat.turn", ({ combat }) => finite(combat?.turn), "number");
  core("combat.currentActorUuid", ({ combat }) => combat?.combatant?.actor?.uuid ?? combat?.combatant?.actorUuid ?? null, "string");
  core("module.temporaryActive", ({ gallery }) => Boolean(gallery?.temporaryState), "boolean");
  core("module.activeProfileId", ({ gallery }) => gallery?.activeProfileId ?? null, "string");
  core("module.activeSequenceId", ({ gallery }) => gallery?.activeSequenceId ?? null, "string");
  core("module.manualOverrideActive", ({ gallery }) => Boolean(gallery?.automationState?.manualOverride), "boolean");
  core("system.id", () => globalThis.game?.system?.id ?? null, "string");
  return registry;
}

export class FactRegistryError extends Error {
  constructor(code) {
    super(code);
    this.name = "FactRegistryError";
    this.code = code;
  }
}

function finite(value) {
  const number = Number(value);
  return Number.isFinite(number) ? number : null;
}

export class GalleryPreloader {
  #loaded = new Set();

  async preload(entries, { favoritesOnly = false } = {}) {
    const sources = Array.from(new Set(entries
      .filter((entry) => !favoritesOnly || entry.favorite)
      .flatMap((entry) => [entry.source, entry.derived?.portrait?.source, entry.derived?.token?.source])
      .filter((source) => source && !this.#loaded.has(source))));
    if (!sources.length) return;
    const loader = globalThis.foundry?.canvas?.TextureLoader?.loader;
    if (loader?.load) {
      await loader.load(sources, { displayProgress: false, maxConcurrent: 4, expireCache: false });
    } else if (globalThis.Image) {
      await Promise.allSettled(sources.map((source) => new Promise((resolve, reject) => {
        const image = new Image();
        image.onload = resolve;
        image.onerror = reject;
        image.src = source;
      })));
    }
    for (const source of sources) this.#loaded.add(source);
  }
}

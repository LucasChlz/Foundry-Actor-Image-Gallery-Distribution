export const ApplicationV2Class = globalThis.foundry?.applications?.api?.ApplicationV2;

export function getFilePickerClass() {
  return globalThis.foundry?.applications?.apps?.FilePicker?.implementation
    ?? globalThis.foundry?.applications?.apps?.FilePicker
    ?? globalThis.FilePicker
    ?? null;
}

export function getImageHelperApi() {
  return globalThis.foundry?.helpers?.media?.ImageHelper
    ?? globalThis.ImageHelper
    ?? null;
}

export function getDialogV2Class() {
  return globalThis.foundry?.applications?.api?.DialogV2 ?? null;
}

import { APPLY_TARGETS, HOOKS, IMAGE_FITS, MODULE_ID } from "../constants.mjs";
import { createPreset, isIdentityPreset, presetSignature, recordUsage, updateEntry } from "../domain/gallery.mjs";
import { clamp, deepClone, getActiveTokenForActor, notify, slugifyFilename, warn } from "../utils.mjs";
import { getFilePickerClass, getImageHelperApi } from "./compatibility.mjs";

export class ActorImageApplicator {
  #repository;
  #renderer;

  constructor({ repository, renderer = new DerivedImageRenderer() }) {
    this.#repository = repository;
    this.#renderer = renderer;
  }

  async apply(actor, entryOrId, target, { token = null, recordUsage: shouldRecordUsage = true, preserveTemporary = false, preserveActiveProfile = false, preserveActiveSequence = false, applicationContext = null } = {}) {
    let gallery = this.#repository.read(actor);
    const entry = typeof entryOrId === "string"
      ? gallery.entries.find((candidate) => candidate.id === entryOrId)
      : entryOrId;
    if (!entry) throw new ImageApplicationError("entryNotFound");
    if (!entry.source) throw new ImageApplicationError("sourceRequired");

    const configuredTarget = target === APPLY_TARGETS.ASK ? APPLY_TARGETS.PORTRAIT_CURRENT : target;
    const resolvedTarget = resolveGalleryTarget(configuredTarget, { ignoreTokenChanges: gallery.ignoreTokenChanges });
    const plan = buildApplyPlan(resolvedTarget);
    const activeToken = getActiveTokenForActor(actor, token);
    const sceneTokens = getSceneActorTokens(actor);
    if (plan.currentToken && !activeToken) throw new ImageApplicationError("tokenRequired");
    if (plan.sceneTokens && sceneTokens.length === 0) throw new ImageApplicationError("sceneTokensRequired");

    const portraitResult = plan.portrait
      ? await this.#renderer.resolve(actor, entry, "portrait")
      : null;
    const tokenResult = plan.prototype || plan.currentToken || plan.sceneTokens
      ? await this.#renderer.resolve(actor, entry, "token")
      : null;
    if (portraitResult?.fallback || tokenResult?.fallback) notify("warn", "notifications.derivativeFallback");

    const actorUpdate = {};
    if (plan.portrait) actorUpdate.img = portraitResult.source;
    if (plan.prototype) actorUpdate["prototypeToken.texture.src"] = tokenResult.source;
    const updateOptions = { [MODULE_ID]: applicationContext ?? { origin: "manual", source: "gallery-entry" } };
    if (Object.keys(actorUpdate).length) await actor.update(actorUpdate, updateOptions);

    if (plan.currentToken) await activeToken.document.update({ "texture.src": tokenResult.source }, updateOptions);
    if (plan.sceneTokens) {
      const updates = sceneTokens
        .filter((candidate) => candidate.id !== activeToken?.document?.id || !plan.currentToken)
        .map((candidate) => ({ _id: candidate.id, "texture.src": tokenResult.source }));
      if (updates.length) await globalThis.canvas.scene.updateEmbeddedDocuments("Token", updates, updateOptions);
    }

    const temporaryState = gallery.temporaryState ? deepClone(gallery.temporaryState) : null;
    const mutation = await this.#repository.mutate(actor, (current) => {
      let next = current;
      const cached = {};
      if (portraitResult?.derived) cached.portrait = portraitResult.derived;
      if (tokenResult?.derived) cached.token = tokenResult.derived;
      if (Object.keys(cached).length) {
        const currentEntry = next.entries.find((candidate) => candidate.id === entry.id);
        const updated = updateEntry(next, entry.id, { derived: { ...currentEntry?.derived, ...cached } });
        next = updated.gallery;
      }
      next = shouldRecordUsage ? recordUsage(next, entry.id).gallery : next;
      if (!preserveTemporary && next.temporaryState) next = { ...next, temporaryState: null };
      if (!preserveActiveProfile && next.activeProfileId) next = { ...next, activeProfileId: null };
      if (!preserveActiveSequence && next.activeSequenceId) next = { ...next, activeSequenceId: null };
      return next;
    }, applicationContext ? { context: applicationContext } : {});
    gallery = mutation.gallery;
    const appliedEntry = gallery.entries.find((candidate) => candidate.id === entry.id);
    callHook(HOOKS.APPEARANCE_CHANGED, {
      actor,
      token: activeToken ?? null,
      entry: appliedEntry ? deepClone(appliedEntry) : null,
      target: resolvedTarget,
      recordedUsage: shouldRecordUsage,
      origin: applicationContext?.origin ?? "manual",
      applicationContext: applicationContext ? deepClone(applicationContext) : null
    });
    const temporaryCleared = Boolean(temporaryState && !preserveTemporary);
    if (temporaryCleared) callHook(HOOKS.TEMPORARY_CLEARED, { actor, state: temporaryState, reason: "permanent-apply" });
    return { actor, entry: appliedEntry, target: resolvedTarget, temporaryCleared };
  }
}

export function buildApplyPlan(target) {
  const plans = {
    [APPLY_TARGETS.PORTRAIT]: { portrait: true, prototype: false, currentToken: false, sceneTokens: false },
    [APPLY_TARGETS.PROTOTYPE]: { portrait: false, prototype: true, currentToken: false, sceneTokens: false },
    [APPLY_TARGETS.CURRENT_TOKEN]: { portrait: false, prototype: false, currentToken: true, sceneTokens: false },
    [APPLY_TARGETS.SCENE_TOKENS]: { portrait: false, prototype: false, currentToken: false, sceneTokens: true },
    [APPLY_TARGETS.PORTRAIT_PROTOTYPE]: { portrait: true, prototype: true, currentToken: false, sceneTokens: false },
    [APPLY_TARGETS.PORTRAIT_CURRENT]: { portrait: true, prototype: false, currentToken: true, sceneTokens: false },
    [APPLY_TARGETS.EVERYTHING]: { portrait: true, prototype: true, currentToken: false, sceneTokens: true }
  };
  const plan = plans[target];
  if (!plan) throw new ImageApplicationError("invalidTarget");
  return plan;
}

export function resolveGalleryTarget(target, { ignoreTokenChanges = false } = {}) {
  if (!ignoreTokenChanges) return target;
  const plan = buildApplyPlan(target);
  if (plan.portrait) return APPLY_TARGETS.PORTRAIT;
  throw new ImageApplicationError("tokenDisabledForGallery");
}

export class DerivedImageRenderer {
  #memoryCache = new Map();

  async resolve(actor, entry, kind) {
    const preset = createPreset(entry[kind]);
    if (isIdentityPreset(preset)) return { source: entry.source, derived: null };
    const signature = presetSignature(preset);
    if (entry.derived?.[kind]?.signature === signature) {
      return { source: entry.derived[kind].source, derived: entry.derived[kind] };
    }
    const cacheKey = `${actor.id}:${entry.id}:${kind}:${signature}`;
    if (this.#memoryCache.has(cacheKey)) return this.#memoryCache.get(cacheKey);

    try {
      const source = await this.#renderAndUpload(actor, entry, kind, preset, signature);
      const result = { source, derived: { source, signature } };
      this.#memoryCache.set(cacheKey, result);
      return result;
    } catch (error) {
      warn(`Could not generate the ${kind} derivative; the original source will be used.`, error);
      return { source: entry.source, derived: null, fallback: true };
    }
  }

  async #renderAndUpload(actor, entry, kind, preset, signature) {
    if (!globalThis.document || !globalThis.Image || !globalThis.File) throw new Error("Canvas APIs unavailable");
    const image = await loadImage(entry.source);
    const size = kind === "token" ? 512 : 768;
    const canvas = document.createElement("canvas");
    canvas.width = size;
    canvas.height = size;
    const context = canvas.getContext("2d", { alpha: true });
    if (!context) throw new Error("2D canvas context unavailable");

    const baseScale = calculateImageScale({
      frameWidth: size,
      frameHeight: size,
      imageWidth: image.naturalWidth,
      imageHeight: image.naturalHeight,
      fit: preset.fit,
      zoom: preset.zoom
    });
    const width = image.naturalWidth * baseScale;
    const height = image.naturalHeight * baseScale;
    const translateX = preset.positionX / 100 * size;
    const translateY = preset.positionY / 100 * size;
    context.save();
    context.translate(size / 2 + translateX, size / 2 + translateY);
    context.rotate(preset.rotation * Math.PI / 180);
    context.scale(preset.flipX ? -1 : 1, preset.flipY ? -1 : 1);
    context.filter = canvasFilter(preset);
    context.drawImage(image, -width / 2, -height / 2, width, height);
    context.restore();

    const blob = await canvasToBlob(canvas, "image/webp", 0.9);
    const shortSignature = await hashText(signature);
    const filename = `${slugifyFilename(actor.name)}-${entry.id}-${kind}-${shortSignature}.webp`;
    const file = new File([blob], filename, { type: "image/webp" });
    const FilePicker = getFilePickerClass();
    if (!FilePicker) throw new Error("FilePicker unavailable");

    // Uploads go to a folder (the file keeps its own name), and Foundry does not create folders
    // while uploading, so derived/<actor> is created first inside the module's storage.
    let response;
    if (typeof FilePicker.uploadPersistent === "function") {
      // Foundry does not always create storage/ itself (it didn't in a fresh install in testing).
      await ensureDirectories(FilePicker, `modules/${MODULE_ID}`, ["storage", "storage/derived", `storage/derived/${actor.id}`]);
      response = await FilePicker.uploadPersistent(MODULE_ID, `derived/${actor.id}`, file, {}, { notify: false });
    } else if (typeof FilePicker.upload === "function") {
      await ensureDirectories(FilePicker, "", [MODULE_ID, `${MODULE_ID}/derived`, `${MODULE_ID}/derived/${actor.id}`]);
      response = await FilePicker.upload("data", `${MODULE_ID}/derived/${actor.id}`, file, {}, { notify: false });
    } else throw new Error("No supported upload API");
    const path = response?.path ?? response?.src ?? response?.url;
    if (!path) throw new Error("Upload did not return a path");
    return path;
  }
}

export function calculateImageScale({ frameWidth, frameHeight, imageWidth, imageHeight, fit = IMAGE_FITS.CONTAIN, zoom = 1 }) {
  const ratios = [Number(frameWidth) / Number(imageWidth), Number(frameHeight) / Number(imageHeight)];
  const baseScale = fit === IMAGE_FITS.COVER ? Math.max(...ratios) : Math.min(...ratios);
  return baseScale * Number(zoom);
}

export class ThumbnailService {
  #cache = new Map();
  #ready = new Map();

  async get(source) {
    if (!source) return "";
    if (this.#cache.has(source)) return this.#cache.get(source);
    const task = this.#create(source).catch(() => source).then((thumbnail) => {
      this.#ready.set(source, thumbnail);
      return thumbnail;
    });
    this.#cache.set(source, task);
    return task;
  }

  // A thumbnail that is already done, so a re-rendered card shows it at once instead of flashing.
  peek(source) {
    return this.#ready.get(source) ?? null;
  }

  async #create(source) {
    const ImageHelper = getImageHelperApi();
    if (!ImageHelper?.createThumbnail) return source;
    // Keep the image's own proportions: a centered square would cut tall art at the belly.
    // The cards crop it with CSS, toward the top where the face is.
    const size = await loadImageSize(source);
    const { width, height } = thumbnailSize(size);
    const result = await ImageHelper.createThumbnail(source, {
      width,
      height,
      center: true,
      format: "image/webp",
      quality: 0.76
    });
    return result?.thumb ?? result?.src ?? result;
  }
}

// Shorter side 320 px, longer side at most 960 px, same proportions as the image.
export function thumbnailSize(size, shortSide = 320, longSide = 960) {
  const ratio = Number(size?.height) / Number(size?.width);
  if (!Number.isFinite(ratio) || ratio <= 0) return { width: shortSide, height: shortSide };
  if (ratio >= 1) return { width: shortSide, height: Math.min(longSide, Math.round(shortSide * ratio)) };
  return { width: Math.min(longSide, Math.round(shortSide / ratio)), height: shortSide };
}

export class ImageApplicationError extends Error {
  constructor(code) {
    super(code);
    this.name = "ImageApplicationError";
    this.code = code;
  }
}

function getSceneActorTokens(actor) {
  return Array.from(globalThis.canvas?.scene?.tokens ?? [])
    .filter((document) => document.actorId === actor.id || document.actor?.id === actor.id);
}

function callHook(name, ...args) {
  try {
    globalThis.Hooks?.callAll?.(name, ...args);
  } catch (error) {
    warn(`Integration hook ${name} failed.`, error);
  }
}

function canvasFilter(preset) {
  const adjustment = preset.adjustments;
  const brightness = clamp(adjustment.brightness + adjustment.exposure * 0.45 + adjustment.highlights * 0.15, 0, 250);
  const contrast = clamp(adjustment.contrast - adjustment.shadows * 0.2 + adjustment.highlights * 0.1, 0, 250);
  const sepia = Math.abs(adjustment.temperature) * 0.35;
  const hue = adjustment.temperature < 0 ? 185 : adjustment.temperature > 0 ? -12 : 0;
  return [
    `brightness(${brightness}%)`,
    `contrast(${contrast}%)`,
    `saturate(${adjustment.saturation}%)`,
    `sepia(${sepia}%)`,
    `hue-rotate(${hue}deg)`,
    `grayscale(${adjustment.grayscale}%)`,
    `blur(${adjustment.blur}px)`
  ].join(" ");
}

// Creates each folder in order; one that already exists is not an error. A folder that truly
// cannot be created makes the upload fail next, and the caller falls back to the original file.
export async function ensureDirectories(FilePicker, base, folders) {
  if (typeof FilePicker?.createDirectory !== "function") return;
  for (const folder of folders) {
    const target = base ? `${base}/${folder}` : folder;
    try {
      await FilePicker.createDirectory("data", target, {});
    } catch {
      // Already exists, or not allowed; the upload reports the real problem.
    }
  }
}

// Natural size of an image, or null when it can't load in time (never blocks adding it).
export async function loadImageSize(source, timeoutMs = 8000) {
  if (!source || !globalThis.Image) return null;
  const timeout = new Promise((resolve) => setTimeout(() => resolve(null), timeoutMs));
  const image = await Promise.race([loadImage(source).catch(() => null), timeout]);
  return image?.naturalWidth ? { width: image.naturalWidth, height: image.naturalHeight } : null;
}

function loadImage(source) {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.decoding = "async";
    try {
      const url = new URL(source, globalThis.location?.href);
      if (url.origin !== globalThis.location?.origin) image.crossOrigin = "anonymous";
    } catch {
      // Foundry virtual file paths can be valid without being URL-parseable.
    }
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error(`Could not load image: ${source}`));
    image.src = source;
  });
}

function canvasToBlob(canvas, type, quality) {
  return new Promise((resolve, reject) => canvas.toBlob(
    (blob) => blob ? resolve(blob) : reject(new Error("Canvas conversion failed")),
    type,
    quality
  ));
}

async function hashText(value) {
  if (globalThis.crypto?.subtle) {
    const bytes = new TextEncoder().encode(value);
    const hash = await crypto.subtle.digest("SHA-256", bytes);
    return Array.from(new Uint8Array(hash)).slice(0, 6).map((byte) => byte.toString(16).padStart(2, "0")).join("");
  }
  let hash = 0;
  for (const character of value) hash = ((hash << 5) - hash + character.charCodeAt(0)) | 0;
  return Math.abs(hash).toString(36);
}

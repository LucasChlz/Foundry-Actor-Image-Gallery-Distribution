export const MODULE_ID = "actor-image-gallery";
export const FLAG_KEY = "gallery";
export const SCHEMA_VERSION = 6;
export const GLOBAL_GALLERY_SCHEMA_VERSION = 1;
export const HISTORY_LIMIT = 12;
export const PUBLIC_API_VERSION = 1;
export const EXTENSION_API_VERSION = 1;
export const BACKUP_SCHEMA_VERSION = 1;

export const HOOKS = Object.freeze({
  ENTRY_ADDED: "actorImageGallery.entryAdded",
  ENTRY_REMOVED: "actorImageGallery.entryRemoved",
  GLOBAL_ENTRY_ADDED: "actorImageGallery.globalEntryAdded",
  GLOBAL_ENTRY_UPDATED: "actorImageGallery.globalEntryUpdated",
  GLOBAL_ENTRY_REMOVED: "actorImageGallery.globalEntryRemoved",
  APPEARANCE_CHANGED: "actorImageGallery.appearanceChanged",
  TEMPORARY_STARTED: "actorImageGallery.temporaryStarted",
  TEMPORARY_REVERTED: "actorImageGallery.temporaryReverted",
  TEMPORARY_CLEARED: "actorImageGallery.temporaryCleared",
  BACKUP_IMPORTED: "actorImageGallery.backupImported",
  REGISTER_EXTENSIONS: "actorImageGallery.registerExtensions",
  EXTENSIONS_READY: "actorImageGallery.extensionsReady"
});

export const CAPABILITIES = Object.freeze({
  GLOBAL_GALLERY: "globalGallery",
  PUBLIC_API: "publicApi",
  METADATA_BACKUP: "metadataBackup",
  MANUAL_TEMPORARY_APPEARANCE: "manualTemporaryAppearance"
});

export const FEATURE_REGISTRY = Object.freeze({
  [CAPABILITIES.GLOBAL_GALLERY]: Object.freeze({ tier: "free" }),
  [CAPABILITIES.PUBLIC_API]: Object.freeze({ tier: "free" }),
  [CAPABILITIES.METADATA_BACKUP]: Object.freeze({ tier: "free" }),
  [CAPABILITIES.MANUAL_TEMPORARY_APPEARANCE]: Object.freeze({ tier: "free" })
});

// Capabilities that only an installed companion module may provide. The Free
// module knows their names so it can validate registrations, not their code.
export const EXTENSION_CAPABILITIES = Object.freeze([
  "appearanceProfiles",
  "appearanceSequences",
  "automationRules",
  "radialWheel",
  "sharedCollections",
  "partyManager",
  "smartBulkImport",
  "sceneAppearances",
  "advancedRandomization",
  "advancedImagePipeline"
]);

export const APPLY_TARGETS = Object.freeze({
  PORTRAIT: "portrait",
  PROTOTYPE: "prototype",
  CURRENT_TOKEN: "current-token",
  SCENE_TOKENS: "scene-tokens",
  PORTRAIT_PROTOTYPE: "portrait-prototype",
  PORTRAIT_CURRENT: "portrait-current",
  EVERYTHING: "everything",
  ASK: "ask"
});

export const SORT_MODES = Object.freeze({
  MANUAL: "manual",
  NAME: "name",
  RECENT: "recent",
  USED: "used",
  FAVORITES: "favorites"
});

export const PRESET_KINDS = Object.freeze({ PORTRAIT: "portrait", TOKEN: "token" });
export const IMAGE_FITS = Object.freeze({ CONTAIN: "contain", COVER: "cover" });

export const DEFAULT_ADJUSTMENTS = Object.freeze({
  brightness: 100,
  contrast: 100,
  saturation: 100,
  temperature: 0,
  exposure: 0,
  shadows: 0,
  highlights: 0,
  grayscale: 0,
  blur: 0
});

export const DEFAULT_PRESET = Object.freeze({
  fit: IMAGE_FITS.CONTAIN,
  zoom: 1,
  positionX: 0,
  positionY: 0,
  rotation: 0,
  flipX: false,
  flipY: false,
  adjustments: DEFAULT_ADJUSTMENTS
});

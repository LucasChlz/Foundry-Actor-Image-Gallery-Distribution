export const DEFAULT_PALETTE = Object.freeze({
  ink: "#0c0c12",
  inkSoft: "#191922",
  paper: "#f4efe5",
  paperMuted: "#c9c3b8",
  signal: "#ff4d7d",
  information: "#3ed6c2",
  danger: "#ff7043"
});

export const PALETTE_FIELDS = Object.freeze([
  "ink",
  "inkSoft",
  "paper",
  "paperMuted",
  "signal",
  "information",
  "danger"
]);

const CSS_VARIABLES = Object.freeze({
  ink: "--aig-color-ink",
  inkSoft: "--aig-color-ink-soft",
  paper: "--aig-color-paper",
  paperMuted: "--aig-color-paper-muted",
  signal: "--aig-color-signal",
  information: "--aig-color-information",
  danger: "--aig-color-danger"
});

export function normalizePalette(input = {}) {
  let source = input;
  if (typeof input === "string") {
    try {
      source = JSON.parse(input);
    } catch {
      source = {};
    }
  }
  return Object.fromEntries(PALETTE_FIELDS.map((key) => [key, normalizeHex(source?.[key], DEFAULT_PALETTE[key])]));
}

export function serializePalette(input) {
  return JSON.stringify(normalizePalette(input));
}

export function applyPalette(element, input) {
  if (!element?.style) return normalizePalette(input);
  const palette = normalizePalette(input);
  for (const key of PALETTE_FIELDS) element.style.setProperty(CSS_VARIABLES[key], palette[key]);
  element.style.setProperty("--aig-border", `color-mix(in srgb, ${palette.paper} 20%, transparent)`);
  return palette;
}

function normalizeHex(value, fallback) {
  const color = String(value ?? "").trim();
  if (/^#[0-9a-f]{6}$/i.test(color)) return color.toLowerCase();
  if (/^#[0-9a-f]{3}$/i.test(color)) return `#${color.slice(1).split("").map((part) => part + part).join("")}`.toLowerCase();
  return fallback;
}

import { IMPORT_STRATEGIES } from "../domain/backup.mjs";
import { escapeAttribute, escapeHtml, localize, slugifyFilename } from "../utils.mjs";

const MAX_BACKUP_BYTES = 10 * 1024 * 1024;

export function downloadBackup(envelope, baseName) {
  if (!globalThis.document || !globalThis.Blob || !globalThis.URL) throw backupError("backupDownloadUnavailable");
  const content = `${JSON.stringify(envelope, null, 2)}\n`;
  const blob = new Blob([content], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = `${slugifyFilename(baseName)}.json`;
  anchor.hidden = true;
  document.body.append(anchor);
  anchor.click();
  anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 0);
}

export async function readBackupFile(file) {
  if (!file || typeof file.text !== "function") throw backupError("backupFileInvalid");
  if (Number(file.size) > MAX_BACKUP_BYTES) throw backupError("backupFileTooLarge");
  return file.text();
}

export function importStrategyOptions(selected = IMPORT_STRATEGIES.SKIP) {
  return Object.values(IMPORT_STRATEGIES).map((strategy) => `<option value="${escapeAttribute(strategy)}" ${strategy === selected ? "selected" : ""}>${escapeHtml(localize(`backup.strategy.${strategy}`))}</option>`).join("");
}

export function importStrategyLabel(strategy) {
  return localize(`backup.strategy.${strategy}`);
}

function backupError(code) {
  return Object.assign(new Error(code), { code });
}

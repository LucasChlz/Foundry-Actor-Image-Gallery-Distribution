import { addEntry } from "./domain/gallery.mjs";

export class GlobalGalleryService {
  #globalRepository;
  #actorRepository;

  constructor({ globalRepository, actorRepository }) {
    this.#globalRepository = globalRepository;
    this.#actorRepository = actorRepository;
  }

  getGallery() {
    return this.#globalRepository.read();
  }

  async addToActor(actor, entryIds) {
    if (!actor) throw new GlobalGalleryServiceError("actorRequired");
    const requestedIds = Array.from(new Set((Array.isArray(entryIds) ? entryIds : [entryIds]).map(String).filter(Boolean)));
    if (!requestedIds.length) throw new GlobalGalleryServiceError("globalSelectionRequired");
    const globalGallery = this.#globalRepository.read();
    const entriesById = new Map(globalGallery.entries.map((entry) => [entry.id, entry]));
    const selected = requestedIds.map((id) => entriesById.get(id));
    if (selected.some((entry) => !entry)) throw new GlobalGalleryServiceError("globalEntryNotFound");

    const mutation = await this.#actorRepository.mutate(actor, (current) => {
      let gallery = current;
      const added = [];
      for (const globalEntry of selected) {
        const result = addEntry(gallery, {
          globalEntryId: globalEntry.id,
          source: globalEntry.source,
          name: globalEntry.name,
          tags: globalEntry.tags,
          description: globalEntry.description,
          collection: globalEntry.category,
          favorite: globalEntry.favorite
        });
        gallery = result.gallery;
        added.push(result.entry);
      }
      return { gallery, value: added };
    });
    return { gallery: mutation.gallery, entries: mutation.value };
  }
}

export class GlobalGalleryServiceError extends Error {
  constructor(code) {
    super(code);
    this.name = "GlobalGalleryServiceError";
    this.code = code;
  }
}

import { escapeAttribute, escapeHtml, localize } from "../utils.mjs";

// The Lontra the Wizard community on Discord (support, news, suggestions). The invite never expires.
export const DISCORD_URL = "https://discord.gg/BtCGmbGEWR";

// Unlike the Patreon card, everyone who opens the gallery sees it, companion or not.
export function discordButtonHtml() {
  return `<a class="aig-button aig-discord-button" href="${escapeAttribute(DISCORD_URL)}" target="_blank" rel="noopener noreferrer">
    <i class="fa-brands fa-discord" aria-hidden="true"></i><span>${escapeHtml(localize("discord.label"))}</span>
  </a>`;
}

export function openDiscord() {
  globalThis.window?.open?.(DISCORD_URL, "_blank", "noopener,noreferrer");
}

// A "Discord" button in the module settings. Foundry opens a menu by rendering its class, so rendering opens the invite.
export function registerDiscordMenu(moduleId) {
  const ApplicationV2 = globalThis.foundry?.applications?.api?.ApplicationV2;
  if (!ApplicationV2 || !globalThis.game?.settings?.registerMenu) return false;
  const DiscordMenu = class AigDiscordMenu extends ApplicationV2 {
    render() {
      openDiscord();
      return this;
    }
  };
  globalThis.game.settings.registerMenu(moduleId, "discord", {
    name: "AIG.discord.label",
    label: "AIG.discord.label",
    icon: "fa-brands fa-discord",
    type: DiscordMenu,
    restricted: false
  });
  return true;
}

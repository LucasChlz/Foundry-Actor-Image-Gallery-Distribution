import { BACKUP_SCHEMA_VERSION } from "../constants.mjs";
import { createGallery } from "./gallery.mjs";
import { createGlobalGallery } from "./global-gallery.mjs";
import { deepClone, randomId } from "../utils.mjs";

export const BACKUP_FORMAT = "actor-image-gallery-backup";

export const IMPORT_STRATEGIES = Object.freeze({
  SKIP: "skip",
  CREATE: "create",
  MERGE: "merge"
});

const SCOPES = new Set(["actor", "global", "world"]);
const PREMIUM_ARRAY_FIELDS = ["profiles", "sequences", "automationRules", "sceneMappings", "sharedSubscriptions"];

export function createBackupEnvelope({ scope, payload, moduleVersion = "0.0.0", now = new Date().toISOString() }) {
  if (!SCOPES.has(scope)) throw new BackupValidationError("backupScopeInvalid");
  return {
    format: BACKUP_FORMAT,
    schemaVersion: BACKUP_SCHEMA_VERSION,
    moduleVersion: String(moduleVersion),
    exportedAt: new Date(now).toISOString(),
    scope,
    metadataOnly: true,
    payload: deepClone(payload)
  };
}

export function parseBackupEnvelope(input, { scopes = SCOPES } = {}) {
  let envelope = input;
  if (typeof input === "string") {
    try {
      envelope = JSON.parse(input);
    } catch {
      throw new BackupValidationError("backupJsonInvalid");
    }
  }
  if (!envelope || typeof envelope !== "object" || Array.isArray(envelope)) throw new BackupValidationError("backupInvalid");
  if (envelope.format !== BACKUP_FORMAT) throw new BackupValidationError("backupFormatInvalid");
  const version = Number(envelope.schemaVersion);
  if (!Number.isInteger(version) || version < 1 || version > BACKUP_SCHEMA_VERSION) throw new BackupValidationError("backupVersionUnsupported");
  if (!SCOPES.has(envelope.scope) || !new Set(scopes).has(envelope.scope)) throw new BackupValidationError("backupScopeInvalid");
  if (!envelope.payload || typeof envelope.payload !== "object" || Array.isArray(envelope.payload)) throw new BackupValidationError("backupPayloadInvalid");
  if (!Number.isFinite(Date.parse(envelope.exportedAt))) throw new BackupValidationError("backupInvalid");
  return createBackupEnvelope({
    scope: envelope.scope,
    payload: envelope.payload,
    moduleVersion: envelope.moduleVersion,
    now: envelope.exportedAt
  });
}

export function mergeActorGallery(currentInput, importedInput, strategyInput, { idFactory = randomId, importTemporaryState = false } = {}) {
  const strategy = normalizeStrategy(strategyInput);
  const current = createGallery(currentInput);
  const imported = createGallery(importedInput);
  const entries = deepClone(current.entries);
  const used = new Set(entries.map((entry) => entry.id));
  const idMap = new Map();
  const report = { added: 0, merged: 0, skipped: 0, remapped: 0 };

  for (const source of imported.entries) {
    const index = entries.findIndex((entry) => entry.id === source.id);
    if (index < 0) {
      entries.push(deepClone(source));
      used.add(source.id);
      idMap.set(source.id, source.id);
      report.added += 1;
    } else if (strategy === IMPORT_STRATEGIES.SKIP) {
      idMap.set(source.id, source.id);
      report.skipped += 1;
    } else if (strategy === IMPORT_STRATEGIES.MERGE) {
      entries[index] = deepClone(source);
      idMap.set(source.id, source.id);
      report.merged += 1;
    } else {
      const id = uniqueId(used, idFactory);
      entries.push({ ...deepClone(source), id });
      used.add(id);
      idMap.set(source.id, id);
      report.added += 1;
      report.remapped += 1;
    }
  }
  entries.forEach((entry, index) => { entry.manualOrder = index; });

  const root = {
    ...current,
    entries,
    history: mergeHistory(current.history, imported.history, idMap)
  };
  if (strategy === IMPORT_STRATEGIES.MERGE) root.ignoreTokenChanges = imported.ignoreTokenChanges;
  for (const field of PREMIUM_ARRAY_FIELDS) {
    root[field] = mergeOpaqueArrays(current[field], imported[field], strategy, idFactory, idMap);
  }
  root.temporaryState = importTemporaryState
    ? remapReferences(imported.temporaryState ?? current.temporaryState, idMap)
    : current.temporaryState;
  root.radialWheelConfig = mergeOptionalRecord(current.radialWheelConfig, imported.radialWheelConfig, strategy, idMap);
  return { gallery: createGallery(root), report };
}

export function mergeGlobalGallery(currentInput, importedInput, strategyInput, { idFactory = randomId } = {}) {
  const strategy = normalizeStrategy(strategyInput);
  const current = createGlobalGallery(currentInput);
  const imported = createGlobalGallery(importedInput);
  const entries = deepClone(current.entries);
  const used = new Set(entries.map((entry) => entry.id));
  const report = { added: 0, merged: 0, skipped: 0, remapped: 0 };
  for (const source of imported.entries) {
    const index = entries.findIndex((entry) => entry.id === source.id);
    if (index < 0) {
      entries.push(deepClone(source));
      used.add(source.id);
      report.added += 1;
    } else if (strategy === IMPORT_STRATEGIES.SKIP) report.skipped += 1;
    else if (strategy === IMPORT_STRATEGIES.MERGE) {
      entries[index] = deepClone(source);
      report.merged += 1;
    } else {
      const id = uniqueId(used, idFactory);
      entries.push({ ...deepClone(source), id });
      used.add(id);
      report.added += 1;
      report.remapped += 1;
    }
  }
  entries.forEach((entry, index) => { entry.manualOrder = index; });
  return { gallery: createGlobalGallery({ entries }), report };
}

export function normalizeStrategy(strategy) {
  if (Object.values(IMPORT_STRATEGIES).includes(strategy)) return strategy;
  throw new BackupValidationError("backupStrategyInvalid");
}

function mergeHistory(current, imported, idMap) {
  return Array.from(new Set([
    ...(current ?? []),
    ...(imported ?? []).map((id) => idMap.get(id) ?? id)
  ]));
}

function mergeOptionalRecord(current, imported, strategy, idMap) {
  if (!imported) return deepClone(current);
  if (!current || strategy === IMPORT_STRATEGIES.MERGE) return remapReferences(imported, idMap);
  return deepClone(current);
}

function mergeOpaqueArrays(currentInput, importedInput, strategy, idFactory, sharedIdMap) {
  const result = Array.isArray(currentInput) ? deepClone(currentInput) : [];
  const imported = Array.isArray(importedInput) ? deepClone(importedInput) : [];
  const used = new Set(result.map((item) => String(item?.id ?? "")).filter(Boolean));
  const replacements = new Map();
  if (strategy === IMPORT_STRATEGIES.CREATE) for (const item of imported) {
    const id = item?.id ? String(item.id) : "";
    if (!id || !used.has(id)) continue;
    const replacement = uniqueId(used, idFactory);
    used.add(replacement);
    replacements.set(id, replacement);
    sharedIdMap.set(id, replacement);
  }
  const references = new Map([...sharedIdMap, ...replacements]);
  for (const item of imported) {
    const id = item?.id ? String(item.id) : "";
    const index = id ? result.findIndex((candidate) => String(candidate?.id ?? "") === id) : -1;
    const importedItem = remapReferences(
      replacements.has(id) ? { ...item, id: replacements.get(id) } : item,
      references
    );
    if (index < 0 || strategy === IMPORT_STRATEGIES.CREATE) result.push(importedItem);
    else if (strategy === IMPORT_STRATEGIES.MERGE) result[index] = importedItem;
  }
  return result;
}

const REFERENCE_KEYS = new Set([
  "entryId",
  "entryIds",
  "profileId",
  "profileIds",
  "sequenceId",
  "sequenceIds",
  "targetId",
  "targetIds",
  "activeEntryId",
  "activeProfileId",
  "activeSequenceId"
]);

function remapReferences(value, idMap, key = null) {
  if (typeof value === "string") return REFERENCE_KEYS.has(key) ? idMap.get(value) ?? value : value;
  if (Array.isArray(value)) return value.map((item) => remapReferences(item, idMap, key));
  if (!value || typeof value !== "object") return value;
  return Object.fromEntries(Object.entries(value).map(([childKey, item]) => [childKey, remapReferences(item, idMap, childKey)]));
}

function uniqueId(used, idFactory) {
  let id = String(idFactory());
  while (!id || used.has(id)) id = String(idFactory());
  return id;
}

export class BackupValidationError extends Error {
  constructor(code) {
    super(code);
    this.name = "BackupValidationError";
    this.code = code;
  }
}

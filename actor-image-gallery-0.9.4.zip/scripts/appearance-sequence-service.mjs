import { APPLY_TARGETS, CAPABILITIES, HOOKS, SEQUENCE_TARGET_TYPES } from "./constants.mjs";
import {
  addAppearanceSequence,
  AppearanceSequenceError,
  computeSequenceNavigation,
  duplicateAppearanceSequence,
  removeAppearanceSequence,
  reorderAppearanceSequences,
  updateAppearanceSequence
} from "./domain/appearance-sequence.mjs";
import { assertCapability } from "./entitlements.mjs";
import { deepClone, warn } from "./utils.mjs";

export class AppearanceSequenceService {
  #repository;
  #applicator;
  #profileService;
  #entitlements;

  constructor({ repository, applicator, profileService, entitlements }) {
    this.#repository = repository;
    this.#applicator = applicator;
    this.#profileService = profileService;
    this.#entitlements = entitlements;
  }

  list(actor) {
    this.#assertAccess();
    return deepClone(this.#repository.read(actor).sequences);
  }

  getProgress(actor, sequenceId = null) {
    this.#assertAccess();
    const gallery = this.#repository.read(actor);
    const sequence = findSequence(gallery, sequenceId ?? gallery.activeSequenceId ?? gallery.sequences[0]?.id);
    return progressFor(gallery, sequence);
  }

  async create(actor, input) {
    this.#assertAccess();
    const mutation = await this.#repository.mutate(actor, (gallery) => {
      const result = addAppearanceSequence(gallery, input);
      return { gallery: result.gallery, value: result.sequence };
    });
    const sequence = mutation.gallery.sequences.find((candidate) => candidate.id === mutation.value?.id) ?? mutation.value;
    callHook(HOOKS.SEQUENCE_ADDED, actor, deepClone(sequence));
    return sequence;
  }

  async update(actor, sequenceId, patch) {
    this.#assertAccess();
    const mutation = await this.#repository.mutate(actor, (gallery) => {
      const result = updateAppearanceSequence(gallery, sequenceId, patch);
      return { gallery: result.gallery, value: result.sequence };
    });
    const sequence = mutation.gallery.sequences.find((candidate) => candidate.id === String(sequenceId));
    callHook(HOOKS.SEQUENCE_UPDATED, actor, deepClone(sequence));
    return sequence;
  }

  async duplicate(actor, sequenceId, { suffix } = {}) {
    this.#assertAccess();
    const mutation = await this.#repository.mutate(actor, (gallery) => {
      const result = duplicateAppearanceSequence(gallery, sequenceId, { suffix });
      return { gallery: result.gallery, value: result.sequence };
    });
    const sequence = mutation.gallery.sequences.find((candidate) => candidate.id === mutation.value?.id) ?? mutation.value;
    callHook(HOOKS.SEQUENCE_ADDED, actor, deepClone(sequence));
    return sequence;
  }

  async remove(actor, sequenceId) {
    this.#assertAccess();
    const mutation = await this.#repository.mutate(actor, (gallery) => {
      const result = removeAppearanceSequence(gallery, sequenceId);
      return { gallery: result.gallery, value: result.sequence };
    });
    callHook(HOOKS.SEQUENCE_REMOVED, actor, deepClone(mutation.value));
    return mutation.value;
  }

  async reorder(actor, orderedIds) {
    this.#assertAccess();
    const mutation = await this.#repository.mutate(actor, (gallery) => reorderAppearanceSequences(gallery, orderedIds));
    const sequences = deepClone(mutation.gallery.sequences);
    callHook(HOOKS.SEQUENCE_REORDERED, actor, sequences);
    return sequences;
  }

  next(actor, sequenceId = null, options = {}) {
    return this.navigate(actor, sequenceId, "next", options);
  }

  previous(actor, sequenceId = null, options = {}) {
    return this.navigate(actor, sequenceId, "previous", options);
  }

  reset(actor, sequenceId = null, options = {}) {
    return this.navigate(actor, sequenceId, "reset", options);
  }

  applyStep(actor, sequenceId, stepIndex, options = {}) {
    return this.navigate(actor, sequenceId, "step", { ...options, stepIndex });
  }

  async navigate(actor, sequenceId, action, { token = null, target = undefined, stepIndex = null, applicationContext = null } = {}) {
    this.#assertAccess();
    const gallery = this.#repository.read(actor);
    const sequence = findSequence(gallery, sequenceId ?? gallery.activeSequenceId ?? gallery.sequences[0]?.id);
    const navigation = computeSequenceNavigation(sequence, gallery.sequenceState?.[sequence.id], action, { stepIndex });
    if (navigation.atBoundary) return { ...progressFor(gallery, sequence), applied: false, atBoundary: true };

    const step = resolveStep(gallery, navigation.step);
    const applyTarget = target === undefined ? (token ? APPLY_TARGETS.PORTRAIT_CURRENT : APPLY_TARGETS.PORTRAIT) : target;
    let application;
    if (step.targetType === SEQUENCE_TARGET_TYPES.ENTRY) {
      if (!applyTarget) throw Object.assign(new Error("featureDisabled"), { code: "featureDisabled" });
      application = await this.#applicator.apply(actor, step.targetId, applyTarget, {
        token,
        preserveActiveSequence: true,
        applicationContext
      });
    } else {
      application = await this.#profileService.apply(actor, step.targetId, { preserveActiveSequence: true, applicationContext });
    }

    const updatedAt = new Date().toISOString();
    const mutation = await this.#repository.mutate(actor, (current) => ({
      ...current,
      activeSequenceId: sequence.id,
      sequenceState: {
        ...current.sequenceState,
        [sequence.id]: {
          index: navigation.index,
          cursor: navigation.cursor,
          currentStepId: step.id,
          updatedAt
        }
      }
    }), applicationContext ? { context: applicationContext } : {});
    const currentSequence = mutation.gallery.sequences.find((candidate) => candidate.id === sequence.id) ?? sequence;
    const result = {
      ...progressFor(mutation.gallery, currentSequence),
      actor,
      application,
      applied: true,
      atBoundary: false
    };
    callHook(HOOKS.SEQUENCE_NAVIGATED, result);
    return result;
  }

  #assertAccess() {
    assertCapability(this.#entitlements, CAPABILITIES.APPEARANCE_SEQUENCES);
  }
}

export function progressFor(gallery, sequence) {
  if (!sequence) return null;
  const state = gallery.sequenceState?.[sequence.id] ?? null;
  const index = state?.index ?? -1;
  const step = index >= 0 ? sequence.steps[index] ?? null : null;
  return {
    sequence: deepClone(sequence),
    sequenceId: sequence.id,
    index,
    position: index >= 0 ? index + 1 : 0,
    total: sequence.steps.length,
    step: step ? deepClone(step) : null,
    label: step ? step.label || targetLabel(gallery, step) : null,
    active: gallery.activeSequenceId === sequence.id
  };
}

export class AppearanceSequenceApplicationError extends Error {
  constructor(code) {
    super(code);
    this.name = "AppearanceSequenceApplicationError";
    this.code = code;
  }
}

function findSequence(gallery, sequenceId) {
  if (!sequenceId) throw new AppearanceSequenceError("sequenceNotFound");
  const sequence = gallery.sequences.find((candidate) => candidate.id === String(sequenceId));
  if (!sequence) throw new AppearanceSequenceError("sequenceNotFound");
  return sequence;
}

function resolveStep(gallery, step) {
  const found = step.targetType === SEQUENCE_TARGET_TYPES.ENTRY
    ? gallery.entries.some((entry) => entry.id === step.targetId)
    : gallery.profiles.some((profile) => profile.id === step.targetId);
  if (!found) throw new AppearanceSequenceApplicationError("sequenceTargetMissing");
  return step;
}

function targetLabel(gallery, step) {
  const collection = step.targetType === SEQUENCE_TARGET_TYPES.ENTRY ? gallery.entries : gallery.profiles;
  return collection.find((item) => item.id === step.targetId)?.name ?? step.targetId;
}

function callHook(name, ...args) {
  try {
    globalThis.Hooks?.callAll?.(name, ...args);
  } catch (error) {
    warn(`Integration hook ${name} failed.`, error);
  }
}

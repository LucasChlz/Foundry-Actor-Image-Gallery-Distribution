import { APPEARANCE_PROFILE_SCHEMA_VERSION } from "../constants.mjs";
import { createPreset, normalizeTags } from "./gallery.mjs";
import { clamp, deepClone, randomId } from "../utils.mjs";

export function createAppearanceProfile(input = {}, { now = new Date().toISOString(), id = randomId() } = {}) {
  const source = input && typeof input === "object" && !Array.isArray(input) ? deepClone(input) : {};
  const createdAt = validDate(source.createdAt) ?? now;
  const stableId = String(source.id ?? id).trim() || String(id);
  return {
    ...source,
    schemaVersion: APPEARANCE_PROFILE_SCHEMA_VERSION,
    id: stableId,
    name: String(source.name ?? "").trim(),
    description: String(source.description ?? "").trim(),
    tags: normalizeTags(source.tags),
    category: String(source.category ?? "").trim(),
    thumbnail: String(source.thumbnail ?? "").trim(),
    portrait: normalizeSourceReference(source.portrait, "portrait"),
    token: normalizeSourceReference(source.token, "token"),
    prototypeToken: source.prototypeToken !== false,
    sceneTokens: Boolean(source.sceneTokens),
    tokenVisual: normalizeTokenVisual(source.tokenVisual),
    createdAt,
    updatedAt: validDate(source.updatedAt) ?? createdAt
  };
}

export function addAppearanceProfile(galleryInput, profileInput, options = {}) {
  const gallery = normalizeProfileGallery(galleryInput);
  const profile = createAppearanceProfile(profileInput, options);
  validateProfile(profile);
  if (gallery.profiles.some((candidate) => candidate.id === profile.id)) throw new AppearanceProfileError("profileIdConflict");
  gallery.profiles.push(profile);
  return { gallery, profile };
}

export function updateAppearanceProfile(galleryInput, profileId, patch, { now = new Date().toISOString() } = {}) {
  const gallery = normalizeProfileGallery(galleryInput);
  const edits = patch && typeof patch === "object" && !Array.isArray(patch) ? patch : {};
  const index = gallery.profiles.findIndex((candidate) => candidate.id === String(profileId));
  if (index < 0) throw new AppearanceProfileError("profileNotFound");
  const current = gallery.profiles[index];
  const profile = createAppearanceProfile({
    ...current,
    ...deepClone(edits),
    id: current.id,
    createdAt: current.createdAt,
    updatedAt: now,
    portrait: Object.hasOwn(edits, "portrait") ? edits.portrait : current.portrait,
    token: Object.hasOwn(edits, "token") ? edits.token : current.token,
    tokenVisual: Object.hasOwn(edits, "tokenVisual") ? edits.tokenVisual : current.tokenVisual
  }, { now, id: current.id });
  validateProfile(profile);
  gallery.profiles[index] = profile;
  return { gallery, profile };
}

export function duplicateAppearanceProfile(galleryInput, profileId, { suffix = " copy", now = new Date().toISOString(), id } = {}) {
  const gallery = normalizeProfileGallery(galleryInput);
  const source = gallery.profiles.find((candidate) => candidate.id === String(profileId));
  if (!source) throw new AppearanceProfileError("profileNotFound");
  return addAppearanceProfile(gallery, {
    ...deepClone(source),
    id: undefined,
    name: `${source.name}${suffix}`,
    createdAt: now,
    updatedAt: now
  }, { now, id });
}

export function removeAppearanceProfile(galleryInput, profileId) {
  const gallery = normalizeProfileGallery(galleryInput);
  const index = gallery.profiles.findIndex((candidate) => candidate.id === String(profileId));
  if (index < 0) throw new AppearanceProfileError("profileNotFound");
  const [profile] = gallery.profiles.splice(index, 1);
  if (gallery.activeProfileId === profile.id) gallery.activeProfileId = null;
  return { gallery, profile };
}

export function normalizeAppearanceProfiles(value) {
  const ids = new Set();
  const profiles = [];
  for (const item of Array.isArray(value) ? value : []) {
    const profile = createAppearanceProfile(item);
    if (!profile.id || ids.has(profile.id)) continue;
    ids.add(profile.id);
    profiles.push(profile);
  }
  return profiles;
}

export function normalizeSourceReference(value, kind = "portrait") {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  const entryId = String(value.entryId ?? "").trim();
  const source = String(value.source ?? "").trim();
  if (!entryId && !source) return null;
  const result = {};
  if (entryId) result.entryId = entryId;
  if (source) result.source = source;
  if (value.preset && typeof value.preset === "object" && !Array.isArray(value.preset)) result.preset = createPreset(value.preset);
  result.kind = kind === "token" ? "token" : "portrait";
  return result;
}

export function normalizeTokenVisual(value) {
  const source = value && typeof value === "object" && !Array.isArray(value) ? value : {};
  const result = {};
  if (finite(source.scale)) result.scale = clamp(Number(source.scale), 0.1, 4);
  if (finite(source.width)) result.width = clamp(Number(source.width), 0.1, 20);
  if (finite(source.height)) result.height = clamp(Number(source.height), 0.1, 20);
  if (finite(source.alpha)) result.alpha = clamp(Number(source.alpha), 0, 1);
  if (typeof source.tint === "string" && /^#[0-9a-f]{6}$/i.test(source.tint)) result.tint = source.tint.toUpperCase();
  const ring = normalizeRing(source.ring);
  if (ring) result.ring = ring;
  return result;
}

export class AppearanceProfileError extends Error {
  constructor(code) {
    super(code);
    this.name = "AppearanceProfileError";
    this.code = code;
  }
}

function normalizeProfileGallery(input) {
  const gallery = deepClone(input && typeof input === "object" ? input : {});
  gallery.profiles = normalizeAppearanceProfiles(gallery.profiles);
  gallery.activeProfileId = gallery.activeProfileId ? String(gallery.activeProfileId) : null;
  return gallery;
}

function validateProfile(profile) {
  if (!profile.name) throw new AppearanceProfileError("profileNameRequired");
  if (!profile.portrait && !profile.token) throw new AppearanceProfileError("profileSourceRequired");
}

function normalizeRing(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  const result = {};
  if (typeof value.enabled === "boolean") result.enabled = value.enabled;
  if (Number.isInteger(Number(value.effects))) result.effects = Number(value.effects);
  const colors = {};
  for (const key of ["ring", "background"]) {
    if (typeof value.colors?.[key] === "string" && /^#[0-9a-f]{6}$/i.test(value.colors[key])) colors[key] = value.colors[key].toUpperCase();
  }
  if (Object.keys(colors).length) result.colors = colors;
  return Object.keys(result).length ? result : null;
}

function finite(value) {
  return value !== "" && value !== null && value !== undefined && Number.isFinite(Number(value));
}

function validDate(value) {
  if (!value) return null;
  const time = Date.parse(value);
  return Number.isFinite(time) ? new Date(time).toISOString() : null;
}
